<form name="frmpayu" method="post" action="<?php echo $PAYU_BASE_URL;?>">
<input type="hidden" name="key" value="<?php echo $MERCHANT_KEY ?>" />
      <input type="hidden" name="hash" value="<?php echo $hash ?>"/>
      <input type="hidden" name="txnid" value="<?php echo $txnid ?>" />
      <input type="hidden" name="amount" value="<?php echo $final_amount; ?>" />
	  <input type="hidden" name="productinfo" value="patanjali" />
	  <input type="hidden" name="firstname" id="name" value="<?php echo $name; ?>" />
	  <input type="hidden" name="email" id="email" value="<?php echo $email;?>" />
	  <input type="hidden" name="udf1" id="udf1" value="<?php echo $customer_id;?>" />
	   <input type="hidden" name="surl" value="<?php echo base_url('checkout/payusuccess'); ?>"/> <!-- Success notification -->
	  <input type="hidden" name="furl" value="<?php echo base_url('checkout/payufailure'); ?>"/> <!-- Failure notification -->

</form>
<script>document.frmpayu.submit();</script>