<section>
    <div class="block color-scheme-white-90">
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                </div>
                <div class="col-md-4"> 
                    <form method="post" id="ssc_otp_from" name="ssc_otp_from" action="javascript:void(0);">
                        <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
                        <div class="block-form box-border wow fadeInLeft text-center">
                            <p>&nbsp;</p>
                            <div class="row">
                                <div class="col-md-12">
                                    <h3>Swadeshi Samridhi Card Number</h3>								                
                                    <div class="alert" id="otp-msg" style="display:none"></div>
                                    <input type="text" class="form-control onlynumber" id="card_no" name="card_no" maxlength="16" minlength="16"  required="" value="" placeholder="Enter Card Number">                                   
                                    <input type="hidden" id="transactionid" name="transactionid"  required="" value="">                                   
                                </div>
                                <div id="send_otp" class="col-md-12">
                                    <button type="button" class="btn-default-1" id="ssc_send_otp" >Send OTP</button>
                                </div>
                                <div id="otp" style="display:none;">
                                <div class="col-md-12">
                                    <input type="password"  class="form-control" id="ssc_code" name="ssc_code" maxlength="4" minlength="4"  required="" placeholder="Enter OTP..">
                                </div>
                                <div class="">
                                    <div class="col-md-4"><a href="javascript:void(0);"  id="ssc_resend_otp">Resend OTP</a></div>	
                                </div>
                                <div class="col-md-12">
                                    <button type="submit" class="btn-default-1" >Submit</button>
                                </div>
                                </div>
                            </div> </div>                    
                    </form>
                </div>
                <div class="col-md-4">
                </div>                      
            </div>
        </div></div></section>
