<table width="100%">
    <tr>
        <td align="center" valign="middle">Do Not Refresh or Press Back <br/> Redirecting to Zaakpay</td>
    </tr>
    <tr>
        <td align="center" valign="middle">
            <form action="<?php echo $BASE_URL; ?>" method="post">
                <input type="hidden" name="merchantIdentifier" value="<?php echo $MERCHANT_ID; ?>" />
<input type="hidden" name="orderId" value="<?php echo $order_id; ?>" />
<input type="hidden" name="returnUrl" value="<?php echo $url; ?>" />
<input type="hidden" name="buyerEmail" value="<?php echo $email; ?>" />
<input type="hidden" name="buyerFirstName" value="<?php echo $name; ?>" />
<input type="hidden" name="buyerLastName" value="<?php echo $lastname; ?>" />
<input type="hidden" name="buyerAddress" value="" />
<input type="hidden" name="buyerCity" value="" />
<input type="hidden" name="buyerState" value="" />
<input type="hidden" name="buyerCountry" value="" />
<input type="hidden" name="buyerPincode" value="" />
<input type="hidden" name="buyerPhoneNumber" value="<?php echo $phoneno; ?>" />
<input type="hidden" name="txnType" value="1" />
<input type="hidden" name="zpPayOption" value="1" />
<input type="hidden" name="mode" value="1" />
<input type="hidden" name="currency" value="INR" />
<input type="hidden" name="amount" value="<?php echo $final_amount*100; ?>" />
<input type="hidden" name="merchantIpAddress" value="<?php echo isset($_SERVER['HTTP_X_FORWARDED_FOR']) ? $_SERVER['HTTP_X_FORWARDED_FOR'] : $_SERVER['REMOTE_ADDR'];?>" />
<input type="hidden" name="purpose" value="1" />
<input type="hidden" name="productDescription" value="Patanjali Products" />
<input type="hidden" name="txnDate" value="<?php echo $txtdate; ?>" />
<input type="hidden" name="checksum" value="<?php echo $checksum; ?>" />
            </form>
        </td>
    </tr>
</table>
<script type="text/javascript">
    var form = document.forms[0];
    form.submit();
</script>
