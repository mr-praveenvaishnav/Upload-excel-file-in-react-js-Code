<?php

defined('BASEPATH') OR exit('No direct script access allowed');

// This can be removed if you use __autoload() in config.php OR use Modular Extensions
require APPPATH . '/libraries/REST_Controller.php';

/**
 * This is an example of a few basic user interaction methods you could use
 * all done with a hardcoded array
 *
 * @package         CodeIgniter
 * @subpackage      Rest Server
 * @category        Controller
 * @author          Phil Sturgeon, Chris Kacerguis
 * @license         MIT
 * @link            https://github.com/chriskacerguis/codeigniter-restserver
 */
class Api extends REST_Controller {

    // var $cartimage = 'https://s3-ap-southeast-1.amazonaws.com/patanjaliayurved.net/product_images/70x56/';
    // var $mainimage = 'https://s3-ap-southeast-1.amazonaws.com/patanjaliayurved.net/product_images/400x500/';
    // var $detailimage = 'https://s3-ap-southeast-1.amazonaws.com/patanjaliayurved.net/product_images/400x300/';
    var $cartimage = 'https://www.patanjaliayurved.net/assets/product_images/70x56/';
    var $mainimage = 'https://www.patanjaliayurved.net/assets/product_images/400x500/';
    var $detailimage = 'https://www.patanjaliayurved.net/assets/product_images/400x300/';

    function __construct() {
        // Construct the parent class
        parent::__construct();
        $this->load->model('Customer_model');
        $this->load->model('Categories_model');
        $this->load->model('App_model');
        $this->load->model('Cart_model');
        $this->load->model('Products_model');
        $this->load->model('Location_model');
        $this->load->model('Orders_model');
        $this->load->model('Statistics_model');
        $this->load->model('Transactions_model');
        $this->load->model('Ui_model');
        $this->load->library('Logger');
        $this->load->library('sms');
        $data = @$_SERVER['HTTP_APIKEY'];
        if ($data == "TmF0aXZlNWVjcmV0UEBzc3cwcmQx" or $this->router->fetch_method() == "getAppSettings") {
            
        } else {
            $response = array('status' => 0, "success" => false, "message" => "unauthorized access");
            echo json_encode($response);
            die;
        }
    }

    public function index_get() {
        echo "test";
    }

    public function login_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $userarray = array();
        $email = $data['email'];
        $password = $data['password'];
        $user = $this->Customer_model->login($email, $password);
        $response = array();
        if ($user) {
            if($user->is_block == 1){
		$response = array('status' => 0, 'error' => 'Your account has been disabled');
		}else{
            //$token='9UAacXGYyG2wIkEeVaXTBFyQqOhfdqcN';
            $token=token();
            $customerinfo = array(
            'token' => $token          
            );
            $this->Customer_model->updatecustomerinfo($user->id, $customerinfo);                                   
            if ($user->status == 1 and $user->is_otp_verified == 1) {
                array_push($userarray, array('customer_id' => $user->id, 'firstname' => $user->firstname, 'lastname' => $user->lastname, 'email' => $user->email, 'mobile' => $user->mobile, 'token' => $token));
                $response = array('status' => 1, 'data' => $userarray, "message" => "You have successfully logged in.");
            } else {
                array_push($userarray, array('customer_id' => $user->id, 'firstname' => $user->firstname, 'lastname' => $user->lastname, 'email' => $user->email, 'mobile' => $user->mobile, 'token' => $token));
                $otp = rand(123456, 989878);
                //$message = 'Hello sir/madam , Your one time password is ' . $otp;
                //$subject = "OTP";
                //$to = $data['email'];
                //sendEmail($to, $subject, $message);
                $sms_message = 'Your one time password for Patanjali is ' . $otp . '. Treat this as confidential and do not share with anyone.';
                $this->sms->send_sms($user->mobile, $sms_message);
                $response = array('status' => 0, 'otp' => $otp, 'data' => $userarray, "message" => "Otp has been sent to your mobile , verify your account first.");
                                }}
        } else {
            $response = array('status' => 0, 'error' => 'Invalid Email or Password');
        }
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function verifyEmailOtp_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $email = $data['email'];
        $verifyaccount = array('status' => 1, 'is_otp_verified' => 1);
        $update = $this->App_model->verifyAccount($email, $verifyaccount);
        $response = array('status' => 1, 'message' => 'Your account has been successfully verified . Please login to continue.');
        $this->response($response, REST_Controller::HTTP_OK);
    }
    public function verifyOtp_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $user_id = $data['user_id'];
        $token = $data['token'];
        $checkToken = $this->App_model->getUserToken($user_id);
        if($checkToken->token==$token && $token){
        $updatearray = array('is_otp_verified' => 1, 'status' => 1);
        $updateinfo = $this->Customer_model->updatecustomerinfo($user_id, $updatearray);
        $response = array('status' => 1, 'message' => 'Your account has been successfully verified . Please login to continue.');
        }else
        {
        $response = array('status' => 0, 'message' => 'Logout', 'logout' => 0); 
        }
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function resendEmailOtp_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $digits_needed = 6;
        $otp = ''; // set up a blank string
        $count = 0;
        while ($count < $digits_needed) {
            $random_digit = mt_rand(0, 9);

            $otp .= $random_digit;
            $count++;
        }
        //$otp = mt_rand(123456, 989878);
        //$message = 'Hello sir/madam , Your one time password is ' . $otp;
        //$subject = "OTP";
        //$to = $data['email'];
        $mobile = $data['mobile'];
        //sendEmail($to, $subject, $message);
        $sms_message = 'Your one time password for Patanjali is ' . $otp . '. Treat this as confidential and do not share with anyone.';
        $this->sms->send_sms($mobile, $sms_message);
        //if ($to == '') {
        $successmsg = 'OTP has been sent to your mobile number.';
        //} else {
        //    $successmsg = 'OTP has been sent to your email address and your mobile number.';
        //}
        $response = array('status' => 1, 'otp' => $otp, 'message' => $successmsg);
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function register_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $userarray = array();
        $title = $data['title'];
        $firstname = $data['firstname'];
        $lastname = $data['lastname'];
        $email = $data['email'];
        $password = $data['password'];
        $mobile = $data['mobile'];
        $checkuser = $this->App_model->checkEmail($email);
        if (!$checkuser) {
            $mobilestatus = $this->Customer_model->checkmobile($mobile);
        if($mobilestatus){
            //$token='9UAacXGYyG2wIkEeVaXTBFyQqOhfdqcN';
            $token=token();
            $customerinfo = array(
                'title' => $title,
                'firstname' => $firstname,
                'lastname' => $lastname,
                'email' => $email,
                'password' => sha1($password),
                'is_app_registered' => 1,
                'created_dt' => time(),
                'mobile' => $mobile,
                'status' => 1,
                'token' => $token);
            $customer_id = $this->Customer_model->register($customerinfo);
            if($customer_id){
            $user = $this->Customer_model->getCustomerDetails($customer_id);
            $digits_needed = 6;
            $otp = ''; // set up a blank string
            $count = 0;
            while ($count < $digits_needed) {
                $random_digit = mt_rand(0, 9);
                $otp .= $random_digit;
                $count++;
            }
            $otparray = array('otp' => sha1($otp));
            $updateotp = $this->Customer_model->updatecustomerinfo($user->id, $otparray);
            $mobilenumber = $user->mobile;
            $sms_message = 'Your one time password for Patanjali is ' . $otp . '. Treat this as confidential and do not share with anyone.';
            $this->sms->send_sms($mobilenumber, $sms_message);         
            array_push($userarray, array('customer_id' => $user->id, 'firstname' => $user->firstname, 'lastname' => $user->lastname, 'email' => $user->email, 'mobile' => $user->mobile, 'otp' => $otp, 'token' => $token));
            $response = array('status' => 1, 'data' => $userarray, "message" => "You are registered successfully");
         }else{
             $response = array('status' => 0, 'message' => 'Error in processing your request.');
        }       
         }else{
             $response = array('status' => 0, 'message' => 'Mobile No. already exists.');
        }
        } else {
            $response = array('status' => 0, "message" => "Email id already exist");
        }
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function forgotPassword_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $email = $data['email'];
        $checkemail = $this->App_model->checkEmail($email);
        if ($checkemail) {
            $digits_needed = 6;
            $otp = ''; // set up a blank string
            $count = 0;
            while ($count < $digits_needed) {
                $random_digit = mt_rand(0, 9);

                $otp .= $random_digit;
                $count++;
            }
            $message = 'Hello sir/madam , Your temporary password is ' . $otp;
            $subject = "Temporary password";
            $to = $email;
            sendEmail($to, $subject, $message);
            $updatepassword = array('password' => sha1($otp));
            $update = $this->App_model->forgotPassword($email, $updatepassword);
            $response = array('status' => 1, "message" => "New password has been sent to your mail , You can change this password from your profile.");
            $this->response($response, REST_Controller::HTTP_OK);
        } else {
            $response = array('status' => 1, "message" => "This email is not registered with us.");
            $this->response($response, REST_Controller::HTTP_OK);
        }
    }

    public function userProfile_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $user_id = $data['user_id'];
        $token = $data['token'];
        $checkToken = $this->App_model->getUserToken($user_id);
        if($checkToken->token==$token && $token){
        $details = $this->App_model->getUserDetails($user_id);
        $response = array('status' => 1, "data" => $details);        
        }else
        {
        $response = array('status' => 0, 'message' => 'Logout', 'logout' => 0); 
        }
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function editProfile_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $userarray = array();
        $user_id = $data['user_id'];
        $token = $data['token'];
        $checkToken = $this->App_model->getUserToken($user_id);
        if($checkToken->token==$token && $token){
        $firstname = $data['firstname'];
        $lastname = $data['lastname'];       
        $customerinfo = array(
            'firstname' => $firstname,
            'lastname' => $lastname
            );
        $customer = $this->Customer_model->updatecustomerinfo($user_id, $customerinfo);
        $user = $this->Customer_model->getCustomerDetails($user_id);

        array_push($userarray, array('customer_id' => $user->id, 'firstname' => $user->firstname, 'lastname' => $user->lastname, 'email' => $user->email, 'mobile' => $user->mobile));
        $response = array('status' => 1, 'data' => $userarray, "message" => "Profile updated successfully");
        }else
        {
        $response = array('status' => 0, 'message' => 'Logout', 'logout' => 0); 
        }
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function addAddress_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $newaddress = array();
        $user_id = $data['user_id'];
        $token = $data['token'];
        $checkToken = $this->App_model->getUserToken($user_id);
        if($checkToken->token==$token && $token){
        $address_name = $data['address_name'];
        $address = $data['address'];
        $address2 = $data['address2'];
        $city = $data['city'];
        $state = $data['state'];
        $country_id = 0;
        $mobile = $data['mobile'];
        $zip = $data['zipcode'];
        $addressdata = array('customer_id' => $user_id,
            'address_name' => $address_name,
            'address' => $address,
            'address2' => $address2,
            'city_name' => $city,
            'state_name' => $state,
            'country_id' => $country_id,
            'mobile' => $mobile,
            'zipcode' => $zip
        );

        $addressid = $this->Customer_model->addAddress($addressdata);
        if ($addressid) {
            $response = array('status' => 1, "message" => "Address has been added successfully");
        } else {
            $response = array('status' => 0, "message" => "Error in processing your request");
        }
        }else
        {
        $response = array('status' => 0, 'message' => 'Logout', 'logout' => 0); 
        }
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function editAddress_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $user_id = $data['user_id'];
        $token = $data['token'];
        $checkToken = $this->App_model->getUserToken($user_id);
        if($checkToken->token==$token && $token){
        $address_id = $data['address_id'];
        $address_name = $data['address_name'];
        $address = $data['address'];
        $address2 = $data['address2'];
        $city = $data['city'];
        $state = $data['state'];
        $country_id = 0;
        $mobile = $data['mobile'];
        $zip = $data['zipcode'];
        $addressdata = array(
            'address_name' => $address_name,
            'address' => $address,
            'address2' => $address2,
            'city_name' => $city,
            'state_name' => $state,
            'country_id' => $country_id,
            'mobile' => $mobile,
            'zipcode' => $zip
        );
        $addressid = $this->Customer_model->editCustomerAddress($addressdata, $address_id);
        $response = array('status' => 1, "message" => "Address has been updated successfully");
        }else
        {
        $response = array('status' => 0, 'message' => 'Logout', 'logout' => 0); 
        }
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function addDevice_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $user_id = $data['user_id'];
        $device_id = $data['device_id'];
        $register_id = $data['register_id'];
        // $token = $data['token'];
        $token = '';

        $checkdeviceid = $this->App_model->checkDevice($device_id);
        if (count($checkdeviceid) > 0) {
            $update_device = array('user_id' => $user_id, 'token' => $token, 'register_id' => $register_id, 'dt_modified' => time());
            //$insertvalues = $this->App_model->updateDevice($update_device, $device_id);
            $response = array('status' => 1, 'message' => 'User ID has been updated successfully');
        } else {
            $add_device = array('device_id' => $device_id, 'register_id' => $register_id, 'token' => $token, 'created_dt' => time());
            //$insertvalues = $this->App_model->addDevice($add_device);
            $response = array('status' => 1, 'message' => 'Device has been registered successfully');
        }
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function updateDevice_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $user_id = $data['user_id'];
        $register_id = $data['register_id'];
        $device_id = $data['device_id'];
        $token = $data['token'];
        $update_device = array('user_id' => $user_id, 'token' => $token, 'register_id' => $register_id, 'dt_modified' => time());
        //$insertvalues = $this->App_model->updateDevice($update_device, $device_id);
        $response = array('status' => 1, 'message' => 'User ID has been updated successfully');
        $this->response($response, REST_Controller::HTTP_OK);
    }
    public function userDetail_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $user_id = $data['user_id'];
        $token = $data['token'];
        if("TmF0aXZlNWVjcmV0UEBzc3cwcmQx123"==$token && $token){
        $details = $this->App_model->getUserDetails($user_id);
        $response = array('status' => 1, "data" => $details);        
        }else
        {
        $response = array('status' => 0, 'message' => 'Logout', 'logout' => 0); 
        }
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function getAppSettings_post() {
        $appsettings = $this->App_model->appSettings();
        $response = array('status' => $appsettings->status, 'data' => $appsettings);
        //$response = array('status' => $appsettings->status, 'data' => encrypt(json_encode($appsettings)));
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function categoryList_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $id = $data['id'];
        if (!$id) {
            $id = 0;
        }
        $categorylist = $this->Categories_model->getCategoryTreeAPI($id);
        $response = array('status' => 1, 'data' => $categorylist);
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function homeScreen_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        
        $home_screen = array();
        $categoriesarray = array();
        $ids[] = 0;
        $parentcategories = $this->Categories_model->getParentCategories();
        foreach ($parentcategories as $parent) {
            $products = $this->App_model->getAppProducts($parent->id);
            $productsarray = array();
            foreach ($products as $product) {
                $imagename = rawurlencode($product->main_image);
                array_push($productsarray, array('product_id' => $product->id, 'product_name' => $product->name, 'product_image' => $this->mainimage . $imagename, 'product_price' => $product->price, 'is_veg' => 0));
            } array_push($categoriesarray, array('category_id' => $parent->id, 'category_name' => $parent->name, 'icon' => base_url() . 'assets/app_icons/' . $parent->appicon, 'products' => $productsarray));
        } $response = array('status' => 1, 'data' => $categoriesarray);
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function categoryProducts_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $user_id = $data['user_id'];
        $wishlist = 'false';
        $totalratings = 0;
        $totalreviews = 0;
        $productarray = array();
        $category_id = $data['category_id'];
        $ids[] = $category_id;
        $selected_category = $this->Categories_model->getCategoryDetails($category_id);
        if ($this->Categories_model->hasSubcategories($category_id)) {
            $sub_categories = $this->Categories_model->getSubcategories($category_id);
            foreach ($sub_categories as $cat) {
                $ids[] = $cat->id;
            }
        }
        $products = $this->App_model->getCategoryProducts($ids);
        foreach ($products as $product) {
            $reviews = $this->App_model->getProductReview($product->id);
            if ($user_id > 0) {
                $wishlist = $this->App_model->checkWishlist($user_id, $product->id);
            } if ($reviews) {
                $totalratings = $reviews->rating;
                $totalreviews = $reviews->total;
            } 
            if($product->mrp and $product->mrp-$product->price>0){
 $offer_per = 'ON OFFER'; 
 $product_offer=1;
 $product_mrp=$product->mrp;
}else{
$product_offer=0;
$offer_per=0;
$product_mrp=0;
}
            array_push($productarray, array('product_id' => $product->id, 'product_name' => $product->name, 'product_image' => $this->detailimage . rawurlencode($product->detail_image), 'product_price' => $product->price, 'average_rating' => $totalratings, 'totalreviews' => $totalreviews, 'in_wishlist' => $wishlist, 'is_veg' => 0, 'product_offer' => $product_offer, 'product_mrp' => $product_mrp,'offer_per'=>$offer_per,'weight' => $product->weight, 'unit' => $product->unit, 'available_qty' => $product->available_qty));
        } $response = array('status' => 1, 'data' => $productarray);
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function productDetails_post() {
        $details_array = array();
        $data = json_decode(file_get_contents('php://input'), true);
        $user_id = $data['user_id'];
        $product_id = $data['product_id'];
        $product_details = $this->App_model->getProductDetails($product_id);
        $all_weights = $this->App_model->getProductVariants($product_details->name, $product_id);
        $reviews = $this->App_model->getProductReview($product_id);
        $totalratings = 0;
        $prreviews = array();
        $reviewcounters = array();
        $totalreviews = 0;
        $wishlist = 'false';
        if ($user_id > 0) {
		$wishlist = $this->App_model->checkWishlist($user_id, $product_id); }
            $reviewcounter = $this->App_model->getReviewsCounter($product_id);
            if ($reviewcounter) {
                foreach ($reviewcounter as $rev) {
                    $reviewcounters[] = array('counter' => $rev->counter, 'rating' => $rev->ratingstar);
                }
            }
        
        if ($reviews) {
            $totalratings = $reviews->rating;
            $totalreviews = $reviews->total;
            $reviewdetails = $this->App_model->getReviews($product_id);
            foreach ($reviewdetails as $review) {
                $prreviews[] = array('review_id' => $review->review_id, 'review_user_id' => $review->user_id, 'username' => $review->username, 'userreviewtitle' => $review->userreviewtitle, 'review' => $review->review, 'ratingstar' => $review->ratingstar);
            }
        }
        // social sharing
        $pro_categories = $this->Categories_model->getParents($product_details->category_id); // creating product url
        $producturl = getProductUrl($product_id, $product_details->name, $pro_categories);
        //$googleplus = 'https://plus.google.com/share?url='.$producturl;
        $veg=0;
        if ($product_details->top_category_id == 1 or $product_details->top_category_id == 2 or $product_details->top_category_id == 4) { $veg=1; }     
          if($product_details->mrp and $product_details->mrp-$product_details->price>0){
 $offer_per = 'ON OFFER'; 
 $product_offer=1;
 $product_mrp=$product_details->mrp;
}else{
$product_offer=0;
$offer_per=0;
$product_mrp=0;
}
array_push($details_array, array('category_id' => $product_details->category_id, 'product_id' => $product_details->id, 'product_name' => $product_details->name, 'product_description' => $product_details->description, 'weight' => $product_details->weight, 'unit' => $product_details->unit, 'product_image' => $this->detailimage . rawurlencode($product_details->detail_image), 'available_qty' => $product_details->available_qty, 'product_price' => $product_details->price, 'average_rating' => $totalratings, 'totalreviews' => $totalreviews, 'in_wishlist' => $wishlist, 'reviews' => $prreviews, 'reviewcounter' => $reviewcounters, 'sharingurl' => $producturl, 'product_varients' => $all_weights, 'is_veg' => $veg, 'product_offer' => $product_offer, 'product_mrp' => $product_mrp,'offer_per'=>$offer_per));
        $response = array('status' => 1, 'data' => $details_array);
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function addToCart_post() {
        $cartarray = array();
        $data = json_decode(file_get_contents('php://input'), true);
        $user_id = $data['user_id'];
        $token = $data['token'];
        $checkToken = $this->App_model->getUserToken($user_id);
        if($checkToken->token==$token && $token){
        $product_id = $data['product_id'];
        $quantity = $data['quantity'];
        //$price=$data['price'];
        $productdetails = $this->App_model->getProductDetails($product_id);
        $price = $productdetails->price;
        if ($user_id) {
            $addtocart = $this->Customer_model->addToCart($user_id, $product_id, $quantity, $price);
            if ($addtocart) {
                array_push($cartarray, array('cart_id' => $addtocart->id, 'cart_items' => $addtocart->cart_items, 'cart_qty' => $addtocart->cart_qty, 'cart_price' => $addtocart->cart_price));
                $response = array('status' => 1, 'data' => $cartarray, 'message' => 'Item has been added to your cart.');
            } else {
                $response = array('status' => 0, 'message' => 'Error.');
            }
        } else {
            $response = array('status' => 0, 'message' => 'Error in processing your request.');
        }
        }else
        {
        $response = array('status' => 0, 'message' => 'Logout', 'logout' => 0); 
        }
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function removeFromCart_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $user_id = $data['user_id'];
        $token = $data['token'];
        $checkToken = $this->App_model->getUserToken($user_id);
        if($checkToken->token==$token && $token){
        $product_id = $data['product_id'];
        $cart_id = $data['cart_id'];
        $removed = $this->App_model->removeCartItem($user_id, $cart_id, $product_id);
        $items = $this->Cart_model->getCartItems($cart_id);
        if (count($items) == 0) {
            $this->App_model->emptyCart($cart_id);
        }
        $items_array = array();
        if ($items) {
            foreach ($items as $item) {
                array_push($items_array, array('cart_id' => $item->cart_id, 'product_id' => $item->product_id, 'quantity' => $item->quantity, 'price' => $item->price));
            }
        }
        if ($removed) {
            $response = array('status' => 1, 'data' => $items_array);
        } else {
            $response = array('status' => 0, 'message' => 'Error in processing your request.');
        }
        }else
        {
        $response = array('status' => 0, 'message' => 'Logout', 'logout' => 0); 
        }
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function updateCart_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $user_id = $data['user_id'];
        $token = $data['token'];
        $checkToken = $this->App_model->getUserToken($user_id);
        if($checkToken->token==$token && $token){
        $product_id = $data['product_id'];
        $cart_id = $data['cart_id'];
        $quantity = $data['quantity'];
        //$price = $data['price'];
        $productdetails = $this->App_model->getProductDetails($product_id);
        $price = $productdetails->price;
        $updated = $this->Customer_model->updateCart($user_id, $cart_id, $product_id, $quantity, $price);
        $items = $this->Cart_model->getCartItems($cart_id);
        $items_array = array();
        if ($items) {
            foreach ($items as $item) {
                array_push($items_array, array('cart_id' => $item->cart_id, 'product_id' => $item->product_id, 'quantity' => $item->quantity, 'price' => $item->price));
            }
        }
        if ($updated) {
            $response = array('status' => 1, 'data' => $items_array);
        } else {
            $response = array('status' => 0, 'message' => 'Error in processing your request.');
        }
        }else
        {
        $response = array('status' => 0, 'message' => 'Logout', 'logout' => 0); 
        }
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function addWishlist_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $user_id = $data['user_id'];
        $token = $data['token'];
        $checkToken = $this->App_model->getUserToken($user_id);
        if($checkToken->token==$token && $token){
        $product_id = $data['product_id'];
        $product_name = $data['product_name'];
        $checkwishlistitem = $this->Customer_model->checkWishlistItem($product_id, $user_id);
        if ($checkwishlistitem && count($checkwishlistitem) > 0) {
            $response = array('status' => 1, 'message' => 'Product has already added in your wishlist.');
        } else {
            $this->Customer_model->addToWishlist($user_id, $product_id, $product_name);
            $response = array('status' => 1, 'message' => 'Product has been added to your wishlist.');
        }
//		$wish = array('user_id'=>$user_id,
//					 'product_id'=>$product_id,
//					 'product_name'=>$product_name,
//					 'created_dt'=>time());
//		$checkwishlist = $this->App_model->checkWishlist($user_id,$product_id);
//		// if($checkwishlist==false){
//			$wishlistdata = $this->Products_model->addToWishlist($wish);
//			$response = array('status'=>1,'message'=>'Product has been added to your wishlist.');
//		// }else{
//			// $response = array('status'=>1,'message'=>'Product has already added in your wishlist.');
//		// }
        }else
        {
        $response = array('status' => 0, 'message' => 'Logout', 'logout' => 0); 
        }
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function removeWishlist_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $user_id = $data['user_id'];
        $token = $data['token'];
        $checkToken = $this->App_model->getUserToken($user_id);
        if($checkToken->token==$token && $token){
        $product_id = $data['product_id'];
        $wishliststatus = $this->Products_model->removeFromWishlist($user_id, $product_id);
        if ($wishliststatus) {
            $response = array('status' => 1, 'message' => 'Product has been removed from your wishlist.');
        } else {
            $response = array('status' => 0, 'message' => 'Error in processing your request.');
        }
        }else
        {
        $response = array('status' => 0, 'message' => 'Logout', 'logout' => 0); 
        }
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function getCartItems_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $cartarray = array();
        $wishlist = 'false';
        $user_id = $data['user_id'];
        $token = $data['token'];
        $checkToken = $this->App_model->getUserToken($user_id);
        if($checkToken->token==$token && $token){
        $total_price=0;
        $customer_cart = $this->Cart_model->getCustomerCart($user_id);
        if ($customer_cart) {
            $cartitems = $this->Cart_model->getCartItems($customer_cart->id);
            if ($cartitems) {
                foreach ($cartitems as $item) {
                    $product = $this->Products_model->getProductDetails($item->product_id);
                    if ($product->price != ($item->price / $item->quantity)) {
                        $this->Customer_model->updateCart($user_id, $customer_cart->id, $item->product_id, $item->quantity, $product->price);
                        //$addtocart = $this->Customer_model->addToCart($user_id, $item->product_id, $item->quantity, $product->price);
                    }
                    if ($product->status == 0) {
                        $removed = $this->App_model->removeCartItem($user_id, $customer_cart->id, $item->product_id);
                    }
              $total_price=$total_price+$item->price;  }
            }
        }
        $customercartnew = $this->Cart_model->getCustomerCart($user_id);
       if($customercartnew){ if($total_price!=$customercartnew->cart_price){$this->App_model->emptyCart($customercartnew->id);}}
        $customercart = $this->Cart_model->getCustomerCart($user_id);
        if ($customercart) {
            $cart_items = $this->Cart_model->getCartItems($customercart->id);
            foreach ($cart_items as $items) {
                $wishlist = $this->App_model->checkWishlist($user_id, $items->product_id);
                $productdetails = $this->App_model->getProductDetails($items->product_id);
                if ($productdetails->available_qty > $productdetails->max_qty_sale) {
                    $available_qty = $productdetails->max_qty_sale;
                } else {
                    $available_qty = $productdetails->available_qty;
                }
                array_push($cartarray, array('cart_id' => $customercart->id, 'product_id' => $productdetails->id, 'product_name' => $productdetails->name, 'product_price' => $productdetails->price, 'product_quantity' => $items->quantity, 'available_qty' => $available_qty, 'weight' => $productdetails->weight, 'unit' => $productdetails->unit, 'total_price' => $items->price, 'max_qty' => $productdetails->max_qty_sale, 'product_image' => $this->detailimage . rawurlencode($productdetails->detail_image), 'in_wishlist' => $wishlist, 'is_veg' => 0));
            }
            $response = array('status' => 1, 'data' => $cartarray, 'cart_items' => $customercart->cart_items, 'total_cart_price' => $customercart->cart_price,'free_shipping_product'=>$this->config->item('free_shipping_product'));
        } else {
            $response = array('status' => 0, 'data' => 0);
        }
        }else
        {
        $response = array('status' => 0, 'message' => 'Logout', 'logout' => 0); 
        }
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function getWishlist_post() {
        $wishlistarray = array();
        $data = json_decode(file_get_contents('php://input'), true);
        $user_id = $data['user_id'];
        $token = $data['token'];
        $checkToken = $this->App_model->getUserToken($user_id);
        if($checkToken->token==$token && $token){
        $wishlist = $this->App_model->getWishlistItems($user_id);
        if ($wishlist) {
            foreach ($wishlist as $wish) {
                $productdetails = $this->App_model->getProductDetails($wish->product_id);
                if ($productdetails->status == 1) {
                    array_push($wishlistarray, array('product_id' => $productdetails->id, 'product_name' => $productdetails->name, 'product_image' => $this->detailimage . rawurlencode($productdetails->detail_image), 'product_price' => $productdetails->price, 'is_veg' => 0, 'weight' => $productdetails->weight, 'unit' => $productdetails->unit, 'available_qty' => $productdetails->available_qty));
                }
            }
            $response = array('status' => 1, 'data' => $wishlistarray);
        } else {
            $response = array('status' => 0, 'message' => 'There are no products in your wishlist.');
        }
        }else
        {
        $response = array('status' => 0, 'message' => 'Logout', 'logout' => 0); 
        }
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function searchProducts_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $searcharray = array();
        $searchkey = $data['searchkey'];
        $products = $this->App_model->searchProducts($searchkey);
        if ($products) {
            foreach ($products as $product) {
                if ($product->available_qty > 0) {
                    array_push($searcharray, array('product_id' => $product->id, 'product_name' => $product->name, 'product_image' => $this->detailimage . rawurlencode($product->detail_image), 'product_price' => $product->price, 'is_veg' => 0, 'weight' => $product->weight, 'unit' => $product->unit, 'available_qty' => $product->available_qty));
                }
                $response = array('status' => 1, 'data' => $searcharray);
            }
        } else {
            $response = array('status' => 0, 'message' => 'No matching results found.');
        }
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function getStates_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $statesarray = array();
        $states = $this->App_model->getState();
        foreach ($states as $state) {
            array_push($statesarray, array('id' => $state->id, 'state_name' => $state->state_name));
        }

        $response = array('status' => 1, 'data' => $statesarray);
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function getCities_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $citiesarray = array();
        $state_name = $data['state_name'];
        $cities = $this->App_model->getCities($state_name);
        foreach ($cities as $city) {
            array_push($citiesarray, array('city_name' => $city->city_name));
        }
        $response = array('status' => 1, 'data' => $citiesarray);
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function getAddresses_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $user_id = $data['user_id'];
        $token = $data['token'];
        $checkToken = $this->App_model->getUserToken($user_id);
        if($checkToken->token==$token && $token){
        $addressarray = array();
        $addresses = $this->App_model->getAddresses($user_id);
        if (count($addresses) > 0) {
            $response = array('status' => 1, 'data' => $addresses);
        } else {
            $response = array('status' => 0, 'message' => 'No address found. Please add your address.');
        }
        }else
        {
        $response = array('status' => 0, 'message' => 'Logout', 'logout' => 0); 
        }
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function processCod_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $cart_items = array();
        // $cod_charges = 70;
        $payment_mode = 1; // $data['payment_mode'];
        $final_amount = $data['final_amount'];
        $shipping_charges = $data['shipping_charges'];
        //$cod_charges		 = 	$data['cod_charges'];
        $shipping_address_id = $data['shipping_address_id'];
        $user_id = $data['user_id'];
        $token = $data['token'];
        $checkToken = $this->App_model->getUserToken($user_id);
        if($checkToken->token==$token && $token){
        $cart_id = $data['cart_id'];
        $user_info = $this->App_model->getUserDetails($user_id);
        $app_order = 1;
        $status = 10;
        // if($final_amount > 999){
        // $cod_charges = 0;
        // }
        // if($final_amount > 499){
        // $shipping_charges = 0;
        // }
        // $orderamount = $final_amount + $cod_charges + $shipping_charges;
        //$orderamount = number_format($final_amount, 0);
        $customercart = $this->Cart_model->getCustomerCart($user_id);
        // cart items
        $cartprice = $customercart->cart_price;
        $cartitems = $customercart->cart_items;
        $cartqty = $customercart->cart_qty;
        $cod_charges = $this->config->item('cod_charges');
        if ($cartprice > 999) {
            $cod_charges = 0;
        }
        $orderamount = number_format($cartprice + $cod_charges + $shipping_charges, 0, '.', '');
        // cart items
        $final_amount=number_format($final_amount, 0, '.', '');
		if($orderamount==$final_amount){
        $order = $this->App_model->addOrder($cart_id, $user_id, $payment_mode, $orderamount, $shipping_charges, $cod_charges, $shipping_address_id, $app_order, $status, $cartprice, $cartitems, $cartqty);
        if ($order) {
            $order_id = $order['order_id'];
            $order_no = $order['order_no'];
            $digits_needed = 6;
            $otp = ''; // set up a blank string
            $count = 0;
            while ($count < $digits_needed) {
                $random_digit = mt_rand(0, 9);
                $otp .= $random_digit;
                $count++;
            }
            //$verify_message = 'Your one time password for Patanjali is ' . $otp . '. Treat this as confidential and do not share with anyone.';
            //$this->sms->send_sms($user_info->mobile, $verify_message);
            $response = array('status' => 1, 'cart_id' => $cart_id, 'order_id' => $order_id, 'order_no' => $order_no, 'otp' => $otp, 'mobile_number' => $user_info->mobile, 'message' => 'Please enter the OTP sent on your mobile number');
        } else {
            $response = array('status' => 0, 'message' => 'Desired quantity is not available in stock.');
        }
		}else{
			$response = array('status' => 0, 'message' => 'Please try again.');
		}
        }else
        {
        $response = array('status' => 0, 'message' => 'Logout', 'logout' => 0); 
        }
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function confirmCod_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $order_id = $data['order_id'];
        $order_no = $data['order_no'];
        $cart_id = $data['cart_id'];
        $user_id = $data['user_id'];
        $token = $data['token'];
        $checkToken = $this->App_model->getUserToken($user_id);
        if($checkToken->token==$token && $token){
        $itemarray1 = array('status' => 0, 'is_confirmed' => 1, 'modified_dt' => time(), 'modified_by' => $user_id);
        $user = $this->App_model->getUserDetails($user_id);
        $value1 = $this->Orders_model->updateorder($order_id, $itemarray1);
        $cartitems = $this->Cart_model->getCartItems($cart_id);
        foreach ($cartitems as $item) {
            $this->Products_model->updateQuantity($item->product_id, $item->quantity);
            $this->Products_model->updatePackageQuantity($item->product_id, $item->quantity);
        }
        $this->Cart_model->removeCart($cart_id, $user_id);
        // $this->cart->destroy();
        $order_detail = $this->Orders_model->getOrderDetails($order_id);
        $fullorderdetails = $this->Orders_model->getFullorderDetails($order_id);
        $date = date("Y-m-d");
        $check = $this->Statistics_model->getStatisticsByDate($date);
        if (count($check) == 0) {
            $statarray = array('date' => $date, 'orders' => 1, 'amounts' => $order_detail->final_amount, 'items' => $order_detail->order_qty);
            $this->Statistics_model->addStatistics($statarray);
        } else {
            $statarray = array('orders' => $check->orders + 1, 'amounts' => $check->amounts + $order_detail->final_amount, 'items' => $check->items + $order_detail->order_qty);
            $this->Statistics_model->updateStatistics($date, $statarray);
        }
        //$final_amount = $this->session->userdata('final_amount');
        $message = '';
        $subject = 'Order Confirmation - Your Order with "patanjaliayurved.net" ' . $order_no . ' has been successfully placed!';
        $to = $user->email;
        $custom = array('type' => 'order', 'details' => array('name' => $user->firstname, 'orderno' => $order_no, 'order_detail' => $order_detail, 'fullorderdetails' => $fullorderdetails));
        sendEmail($to, $subject, $message, $custom);

        $sms_message = 'Your Order at Patanjali has been placed successfully. Your order number is ' . $order_no . '. and order amount is Rs. ' . $order_detail->final_amount . '. Thanks you for choosing Patanjali.';
        $this->sms->send_sms($user->mobile, $sms_message);
        $response = array('status' => 1, 'message' => 'Order has been placed successfully.');
        }else
        {
        $response = array('status' => 0, 'message' => 'Logout', 'logout' => 0); 
        }
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function processPayment_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $cart_items = array();
        $cod_charges = 0;
        $payment_mode = $data['payment_mode'];
        $final_amount = $data['final_amount'];
        $shipping_charges = $data['shipping_charges'];
        //$cod_charges = 	$data['cod_charges'];
        $shipping_address_id = $data['shipping_address_id'];
        $user_id = $data['user_id'];
        $token = $data['token'];
        $checkToken = $this->App_model->getUserToken($user_id);
        if($checkToken->token==$token && $token){
        $cart_id = $data['cart_id'];
        $user_info = $this->App_model->getUserDetails($user_id);
        $app_order = 1;
        $status = 10;
        // if($final_amount > 999){
        // $cod_charges = 0;
        // }
        // if($final_amount > 499){
        // $shipping_charges = 0;
        // }
        //$orderamount = number_format($final_amount,0);
        $customercart = $this->Cart_model->getCustomerCart($user_id);
        // cart items
        $cartprice = $customercart->cart_price;
        $cartitems = $customercart->cart_items;
        $cartqty = $customercart->cart_qty;

        $cod_charges = 0;
        if ($payment_mode == 1) {
            if ($cartprice <= 999) {
                $cod_charges = $this->config->item('cod_charges');
            }
        }
        $orderamount = number_format($cartprice + $cod_charges + $shipping_charges, 0, '.', '');
        // cart items

        $order = $this->App_model->addOrder($cart_id, $user_id, $payment_mode, $orderamount, $shipping_charges, $cod_charges, $shipping_address_id, $app_order, $status, $cartprice, $cartitems, $cartqty);
        if ($order) {
            $order_id = $order['order_id'];
            $order_no = $order['order_no'];
            if ($payment_mode == 2) {
                $user = $this->Customer_model->getCustomerDetails($user_id);
                $merchantid = $this->config->item('merchantid');
                $order_no = $order_no;   // NEED to replace this with unique order number in order table
                $totalbill = $orderamount;
                $secureid = $this->config->item('secureid');
                $unit_id = $user_id;
                $last_id_cod = $order_id;
                $cmp_phone = $user->mobile;
                $cmp_email = $user->email;
                $returnurl = $this->config->item('mobilereturnurl');
                $str = '' . $merchantid . '|' . $order_no . '|NA|' . $totalbill . '|NA|NA|NA|INR|NA|R|' . $secureid . '|NA|NA|F|' . $unit_id . '|' . $last_id_cod . '|' . $cmp_phone . '|' . $cmp_email . '|' . $cart_id . '|NA|NA|' . $returnurl . '';
                $checksum = hash_hmac('sha256', $str, 'ySQTiTyjXwWK', false);
                $checksum = strtoupper($checksum);
                $data['parameters'] = $hiddenvalue = $str . "|" . $checksum;
                $response = array('status' => 1, 'data' => $hiddenvalue, 'order_no' => $order_no, 'order_id' => $order_id);
            }
        } else {
            $response = array('status' => 0, 'message' => 'Desired quantity is not available in stock.');
        }
        }else
        {
        $response = array('status' => 0, 'message' => 'Logout', 'logout' => 0); 
        }
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function changePassword_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $user_id = $data['user_id'];
        $token = $data['token'];
        $checkToken = $this->App_model->getUserToken($user_id);
        if($checkToken->token==$token && $token){
        $password = $data['password'];
        $current_password = $data['current_password'];
        $checkuser = $this->App_model->getUserDetails($user_id);

        if ($checkuser) {
            $check = $this->App_model->checkPassword($current_password,$user_id);
            if ($check) {
                $changepasswordarray = array('password' => sha1($password));
                $updatepassword = $this->App_model->changePassword($user_id, $changepasswordarray);
                $response = array('status' => 1, 'message' => 'Your password has been changed successfully.');
            } else {
                $response = array('status' => 0, 'message' => 'Current password does not matched.');
            }
        } else {
            $response = array('status' => 0, 'message' => 'Error in processing your request.');
        }
         }else
        {
        $response = array('status' => 0, 'message' => 'Logout', 'logout' => 0); 
        }
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function orderList_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $user_id = $data['user_id'];
        $token = $data['token'];
        $checkToken = $this->App_model->getUserToken($user_id);
        if($checkToken->token==$token && $token){
        $orderlist = array();
        $userorders = $this->App_model->getOrderList($user_id);
        if (count($userorders) > 0) {
            foreach ($userorders as $order) {
                array_push($orderlist, array('order_id' => $order->id, 'order_number' => $order->order_no, 'final_amount' => $order->final_amount, 'order_date' => date('d-m-Y', $order->created_dt)));
            }
            $response = array('status' => 1, 'data' => $orderlist);
        } else {
            $response = array('status' => 0, 'message' => 'No order found.');
        }
        }else
        {
        $response = array('status' => 0, 'message' => 'Logout', 'logout' => 0); 
        }
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function orderDetails_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $user_id = $data['user_id'];
        $token = $data['token'];
        $checkToken = $this->App_model->getUserToken($user_id);
        if($checkToken->token==$token && $token){
        $order_no = $data['order_no'];
        $orderdetails = array();
        $products = array();
        $placed_status = 0;
        $process_status = 0;
        $dispatch_status = 0;
        $complete_status = 0;
        $cancelled_status = 0;

        $order = $this->App_model->getOrderDetailsByNumber($user_id, $order_no);

        if (count($order) > 0) {
            if ($order->status == 0) {
                $placed_status = 1;
            }
            if ($order->status > 0 and $order->status < 5) {
                $process_status = 1;
            }
            if ($order->status == 5) {
                $dispatch_status = 1;
            }
            if ($order->status == 6) {
                $dispatch_status = 1;
            }
            if ($order->status == 6 and $order->is_delivered==1) {
                $complete_status = 1;
            }
            if ($order->status > 6 or $order->is_confirmed == 0) {
                $cancelled_status = 1;
            }
            $orderitems = $this->App_model->getOrderItems($order->id);
            foreach ($orderitems as $item) {
                $product = $this->App_model->getProductDetails($item->product_id);
                array_push($products, array('product_name' => $product->name, 'product_weight' => $product->weight, 'unit' => $product->unit, 'quantity' => $item->quantity, 'product_price' => $item->price/$item->quantity, 'item_price' => $item->price, 'product_image' => $this->detailimage . rawurlencode($product->detail_image)));
            }
            array_push($orderdetails, array('order_id' => $order->id, 'order_number' => $order->order_no, 'order_items' => $order->order_items, 'order_qty' => $order->order_qty, 'order_price' => $order->order_price, 'cod_charges' => $order->cod_charges, 'shipping_charges' => $order->shipping_charges, 'final_amount' => $order->final_amount, 'order_date' => date('d-m-Y', $order->created_dt), 'courier_name' => $order->courier_name, 'awb_no' => $order->awb_no, 'placed_status' => $placed_status, 'process_status' => $process_status, 'dispatch_status' => $dispatch_status, 'complete_status' => $complete_status, 'cancelled_status' => $cancelled_status, 'products' => $products, 'is_confirmed' => $order->is_confirmed));
            $response = array('status' => 1, 'data' => $orderdetails);
        } else {
            $response = array('status' => 0, 'message' => 'Error in processing your request.');
        }
        }else
        {
        $response = array('status' => 0, 'message' => 'Logout', 'logout' => 0); 
        }
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function pushNotification_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $user_id = $data['user_id'];
        $register_id = $data['register_id'];
        $message = array("message" => "text message", "title" => "text title", "image" => "https://www.patanjaliayurved.net/assets/img/logo-big.png");
        $regArray = $register_id;
        $url = 'https://fcm.googleapis.com/fcm/send';
        $fields = array('registration_ids' => array($regArray), 'data' => $message);
        $headers = array('Authorization: key=AAAAHWb0IIA:APA91bGCPaIokrkL7k_g8x3bRmjDq1taTOdZHI88WyqGuEy5rMPj7VEXRZM_RWSsbxGO5WX29HHUEQp7kx-tv7Wz41GPyPH0hRF60QEcxuSQ6WubPwyM9r6fsNJXfBJWxR0ggOqV2FMM', 'Content-Type: application/json');
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
        $result = curl_exec($ch);
        if ($result == FALSE) {
            die('Curl Failed');
        }
        curl_close($ch);
        print_r($result);
        die;
    }

    public function addRating_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $user_id = $data['user_id'];
        $token = $data['token'];
        $checkToken = $this->App_model->getUserToken($user_id);
        if($checkToken->token==$token && $token){
        $product_id = $data['product_id'];
        $title = $data['title'];
        $description = $data['description'];
        $ratings = $data['rating'];
        $userdetails = $this->App_model->getUserDetails($user_id);
        if ($userdetails) {
            $reviewarray = array('user_id' => $user_id, 'product_id' => $product_id, 'username' => $userdetails->firstname, 'userreviewtitle' => $title, 'review' => $description, 'ratingstar' => $ratings, 'created_dt' => time());
            $reviewval = $this->App_model->addReview($reviewarray);
            $response = array('status' => 1, 'message' => 'Review has been added successfully');
        } else {
            $response = array('status' => 0, 'message' => 'Error in processing your request.');
        }
        }else
        {
        $response = array('status' => 0, 'message' => 'Logout', 'logout' => 0); 
        }
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function cancelOrder_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $user_id = $data['user_id'];
        $token = $data['token'];
        $checkToken = $this->App_model->getUserToken($user_id);
        if($checkToken->token==$token && $token){
        if (array_key_exists('reason', $data)) {
            $reason = $data['reason'];
        } else {
            $reason = '';
        }
        $order_no = $data['order_no'];
        $order = $this->Orders_model->getOrderNumber($order_no);
        if ($order->status < 5) {
            $order_id = $order->id;
            $user_id = $order->user_id;

            $itemvalue = $this->Orders_model->getFinalorderDetails($order_id);
            foreach ($itemvalue as $id) {
                $itemarray = array('status' => 10);
                $value1 = $this->Orders_model->updateorderitem($id->orderdetail_id, $itemarray);
                $getOrderItem = $this->Orders_model->getOrderItemsbyid($id->orderdetail_id);
                $this->Products_model->updateQuantity($getOrderItem->product_id, $getOrderItem->quantity, 'add');
                $this->Products_model->updatePackageQuantity($getOrderItem->product_id, $getOrderItem->quantity, 'add');
            }

            $user_detail = $this->Customer_model->getCustomerDetails($user_id);
            $dataarray = array('status' => 10,
                'refund_amount' => $order->final_amount, 'cancel_reason' => $reason, 'return_date' => time(), 'modified_by' => $user_id);
            $value = $this->Orders_model->updateorder($order_id, $dataarray);
            $mobile_number = $user_detail->mobile;
            $sms_message = 'Hello , your order ' . $order_no . ' is cancelled.';
            $this->sms->send_sms($mobile_number, $sms_message);

            $to = $user_detail->email;
            $subject = 'Order Cancelled';
            $message = 'Hello ' . $user_detail->firstname . ',<br><br> your order with reference to ' . $order_no . ' has been cancelled.';
            //send email
            sendEmail($to, $subject, $message);

            $date = date("Ymd");
            $billdesk = array();
            $paytm = array();
            $payu = array();
            $oxigen = array();
            $vpayqwik = array();
            $mobikwik = array();
            $phonepe = array();
            $ssc = array();
            $razorpay = array();
            $id = 0;
            if ($order->payment_mode == 2) {
                $billdesk_detail = $this->Orders_model->getBilldeskTxt($order->order_no);
                $billdesk[] = $billdesk_detail;
            }
            if ($order->payment_mode == 3) {
                $paytm_detail = $this->Orders_model->getPaytmTxt($order->order_no);
                $paytm[] = $paytm_detail;
            }
            if ($order->payment_mode == 4) {
                $payu_detail = $this->Orders_model->getPayuTxt($order->order_no);
                $payu[] = $payu_detail;
            }
            if ($order->payment_mode == 5) {
                $oxigen_detail = $this->Orders_model->getOxigenTxt($order->order_no);
                $oxigen[] = $oxigen_detail;
            }
            if ($order->payment_mode == 6) {
                $vpay_detail = $this->Orders_model->getVpayqwikTxt($order->order_no);
                $vpayqwik[] = $vpay_detail;
            }
            if ($order->payment_mode == 7) {
                $mobikwik_detail = $this->Orders_model->getMobikwikTxt($order->order_no);
                $mobikwik[] = $mobikwik_detail;
            }
            if ($order->payment_mode == 8) {
                $phonepe_detail = $this->Orders_model->getPhonepeTxt($order->order_no);
                $phonepe[] = $phonepe_detail;
            }
            if ($order->payment_mode == 9) {
                $ssc_detail = $this->Orders_model->getSSCTxt($order->order_no);
                $ssc = $ssc_detail;
            }
            if ($order->payment_mode == 10) {
            $razorpay_detail = $this->Orders_model->getRazorPayTxt($order->order_no);
            $razorpay[] = $razorpay_detail;
            }
            if (count($billdesk) > 0) {
                $item1 = array(
                    'rto_id' => $id,
                    'file_name' => "Refund_" . $date,
                    'order_no' => $order_no,
                    'payment_mode' => 2,
                    'refund_amount' => $order->final_amount,
                    'response_data' => serialize($billdesk)
                );
                $order_id = $this->Orders_model->add_refund_file($item1);
            }
            if (count($paytm) > 0) {
                $item2 = array(
                    'rto_id' => $id,
                    'file_name' => "Refund_" . $date,
                    'order_no' => $order_no,
                    'payment_mode' => 3,
                    'refund_amount' => $order->final_amount,
                    'response_data' => serialize($paytm)
                );
                $order_id = $this->Orders_model->add_refund_file($item2);
            }
            if (count($payu) > 0) {
                $item3 = array(
                    'rto_id' => $id,
                    'file_name' => "Refund_" . $date,
                    'order_no' => $order_no,
                    'payment_mode' => 4,
                    'refund_amount' => $order->final_amount,
                    'response_data' => serialize($payu)
                );
                $order_id = $this->Orders_model->add_refund_file($item3);
            }
            if (count($oxigen) > 0) {
                $item4 = array(
                    'rto_id' => $id,
                    'file_name' => "Refund_" . $date,
                    'order_no' => $order_no,
                    'payment_mode' => 5,
                    'refund_amount' => $order->final_amount,
                    'response_data' => serialize($oxigen)
                );
                $order_id = $this->Orders_model->add_refund_file($item4);
            }
            if (count($vpayqwik) > 0) {
                $item5 = array(
                    'rto_id' => $id,
                    'file_name' => "Refund_" . $date,
                    'order_no' => $order_no,
                    'payment_mode' => 6,
                    'refund_amount' => $order->final_amount,
                    'response_data' => serialize($vpayqwik)
                );
                $order_id = $this->Orders_model->add_refund_file($item5);
            }
			if (count($mobikwik) > 0) {
            $item7 = array(
                'rto_id' => $id,
                'file_name' => "Refund_" . $date,
                'order_no' => $order_no,
                'payment_mode' => 7,
                'refund_amount' => $order->final_amount,
                'response_data' => serialize($mobikwik)
            );
            $order_id = $this->Orders_model->add_refund_file($item7);
        }
		if (count($phonepe) > 0) {
            $item8 = array(
                'rto_id' => $id,
                'file_name' => "Refund_" . $date,
                'order_no' => $order_no,
                'payment_mode' => 8,
                'refund_amount' => $order->final_amount,
                'response_data' => serialize($phonepe)
            );
            $order_id = $this->Orders_model->add_refund_file($item8);
        }
		if (count($ssc) > 0) {
		if(date("d-m-Y",$order->created_dt)== date("d-m-Y")){
                    
               
$url=$this->config->item('ssc_url');
$merchant_name= $this->config->item('ssc_merchant_name');
$merchantId= $this->config->item('ssc_mid');
$terminalId= $this->config->item('ssc_tid');
$sourceID= $this->config->item('ssc_sourceid');
$token= getssctoken($url,$this->config->item('ssc_sourceid'),$this->config->item('ssc_password'),1);
                    $string = '{"TerminalId":"'.$terminalId.'",
"MerchantId":"'.$merchantId.'",
"MerchantName":"'.$merchant_name.'",
"Amount" : '.$ssc->amount.',
"TransactionId":"'.$ssc->transactionId.'",
"CardNo" :"'.$ssc->card_no.'",
"InvoiceNo":"'.$ssc->InvoiceNo.'"
	}';
$publicKey = file_get_contents('keys/dppublic.pem');
openssl_public_encrypt( $string, $encrypted, $publicKey );
$encrypted = base64_encode( $encrypted );
 $payload = '{
	"TranType": "Void",
	"RequestId": "1",
	"TxnDateTime": "'.date("YmdHis").'000",
	"SourceId": "'.$sourceID.'",
    "Msg": "'.$encrypted.'"}';
//echo $payload;
$curl = curl_init();
curl_setopt_array($curl, array(
  CURLOPT_URL => $url,
  CURLOPT_TIMEOUT => 60,
  CURLOPT_CUSTOMREQUEST => "POST",
  CURLOPT_SSL_VERIFYPEER => false,
  CURLOPT_SSL_VERIFYHOST => false,
  CURLOPT_FOLLOWLOCATION => false,
  CURLOPT_RETURNTRANSFER => TRUE,
  CURLOPT_POSTFIELDS => $payload,
  CURLOPT_HTTPHEADER => array(
    "Content-Type: application/json",
    "Authorization: ".$token
  ),
));
 $res = curl_exec($curl);

curl_close($curl);

$response =json_decode($res);
$msg =json_decode($response->Msg);
$response_encrypted =$msg->Description;
$privKey = file_get_contents('keys/private.pem');
openssl_private_decrypt( base64_decode( $response_encrypted ), $decrypted, $privKey );
//echo '<h1>Decrypted String</h1>';
//echo $decrypted;
                    }
                else{
					$ssc1[]=$ssc;
            $item9 = array(
                'rto_id' => $id,
                'file_name' => "Refund_" . $date,
                'order_no' => $order_no,
                'payment_mode' => 9,
                'refund_amount' => $order->final_amount,
                'response_data' => serialize($ssc1)
            );
            $order_id = $this->Orders_model->add_refund_file($item9);                  
                }
                }
                if (count($razorpay) > 0) {
            $item10 = array(
                'rto_id' => $id,
                'file_name' => "Refund_" . $date,
                'order_no' => $order_no,
                'payment_mode' => 10,
                'refund_amount' => $order->final_amount,
                'response_data' => serialize($razorpay)
            );
            $order_id = $this->Orders_model->add_refund_file($item10);
            }
            $response = array('status' => 1, 'message' => 'Order has been cancelled successfully');
        } else {
            if ($order->status == 10) {
                $response = array('status' => 1, 'message' => 'Order has been cancelled successfully');
            }else{         
            $response = array('status' => 1, 'message' => 'Order already dispatched you can not cancel this order');
            }
        }
        }else
        {
        $response = array('status' => 0, 'message' => 'Logout', 'logout' => 0); 
        }
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function faqList_post() {
        $data = json_decode(file_get_contents('php://input'), true);

        $faq = array();
        $faq_list = array();
        $faqlists = $this->App_model->getFaqs();
        foreach ($faqlists as $faqlists) {
            array_push($faq_list, array('id' => $faqlists->id, 'question' => $faqlists->question, 'answer' => strip_tags($faqlists->answer)));
        }
        $response = array('status' => 1, 'data' => $faq_list);
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function contactUs_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $name = $data['name'];
        $email = $data['email'];
        $mobile = $data['mobile'];
        $comment = $data['comment'];
        if($email and $mobile){
        $contactarray = array('fullname' => $name, 'email' => $email, 'mobile' => $mobile, 'comment' => $comment, 'created_dt' => time());
        $contact = $this->App_model->contactUs($contactarray);
        $message = 'Hello ' . $name . ' , Your request has been received successfully.We will get back to you soon.';
        $subject = "Patanjaliayurved : Contact request";
        $to = $email;
        sendEmail($to, $subject, $message);
        $subject = 'Patanjali order query';
        $message1 = 'Name - '.$name.'<br><br>Email - '.$email.'<br><br>Mobile No. - '.$mobile.'<br><br>Message - '.$comment;
        $to1 = "ecommerce@patanjaliayurved.org";
        //$to1 = "shoaib.satisfaction@gmail.com";
        sendEmail($to1, $subject, $message1);
        $response = array('status' => 1, 'message' => 'Your contact request has been submitted successfully.');
        }else{
                 $response = array('status' => 0);   
        }
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function payuResponse_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $orderno = $data['order_no'];
        $order_id = $data['order_id'];
        $paystatus = 1;
        $payment_mode = 4;
       // $final_amount = $data['final_amount'];
        //$shipping_charges = $data['shipping_charges'];
        //$cod_charges = $data['cod_charges'];
        //$shipping_address_id = $data['shipping_address_id'];
        $user_id = $data['user_id'];
        $token = $data['token'];
        $checkToken = $this->App_model->getUserToken($user_id);
        if($checkToken->token==$token && $token){
        $cart_id = $data['cart_id'];
        $user_info = $this->App_model->getUserDetails($user_id);
        $app_order = 1;
        $status = 0;
       // $orderamount = $final_amount;
//		$customercart = $this->Cart_model->getCustomerCart($user_id);
//		// cart items
//		$cartprice = $customercart->cart_price;
//		$cartitems = $customercart->cart_items;
//		$cartqty = $customercart->cart_qty;
        // cart items
        $payu_array = array('mihpayid' => $data['mihpayid'],
            'mode' => $data['mode'],
            'txnid' => $data['order_no'],
            'amount' => $data['amount'],
            'cardCategory' => $data['cardCategory'],
            'net_amount_debit' => $data['net_amount_debit'],
            'addedon' => $data['addedon'],
            'productinfo' => $data['productinfo']
        );

        $payu_values = $this->Transactions_model->insertPayuValues($payu_array);

        $order_detail = $this->Orders_model->getOrderDetails($order_id);
        $orderno = $order_detail->order_no;
        $fullorderdetails = $this->Orders_model->getFullorderDetails($order_id);
        $itemarray1 = array('status' => 0, 'payment_status' => 1, 'is_confirmed' => 1, 'modified_dt' => time(), 'modified_by' => $user_id);
        $value1 = $this->Orders_model->updateorder($order_id, $itemarray1);
        $cartitems = $this->Cart_model->getCartItems($cart_id);
        foreach ($cartitems as $item) {
            $this->Products_model->updateQuantity($item->product_id, $item->quantity);
            $this->Products_model->updatePackageQuantity($item->product_id, $item->quantity);
        }
        $this->Cart_model->removeCart($cart_id, $user_id);

        $message = 'Dear Sir/Madam,' . '<br>' . 'Your Order Was Successfull, Below is your order number for further references.' . '<br>' . 'Patanjali Ayurved Limited, Company TIN No. 05006754814' . '<br>' . 'Your Order Number is' . '&nbsp;' . $orderno . ' and your order amount is Rs.' . $final_amount . ' (inclusive of shipping charges)';

        $subject = 'Order Confirmation - Your Order with "patanjaliayurved.net" ' . $orderno . ' has been successfully placed!';
        $to = $user_info->email;
        $mobile_number = $user_info->mobile;
        // $sms_message = 'Hello Mr/Mrs/Ms' . $user_info->firstname . ' ,this is a confirmation message from patanjaliayurved.net.Your order has been placed successfully.Order No : ' . $txnid;
        $sms_message = 'Your order at patanjali has been placed successfully . Your order number is ' . $orderno . '. and order amount is ' . $final_amount . '. Thank you for choosing patanjali.';
        //send email
        $custom = array('type' => 'order', 'details' => array('name' => $user_info->firstname, 'orderno' => $orderno, 'order_detail' => $order_detail, 'fullorderdetails' => $fullorderdetails));
        sendEmail($to, $subject, $message, $custom);

        $this->sms->send_sms($mobile_number, $sms_message);
        $response = array('status' => 1, 'msg' => 'Order has been placed successfully', 'order_no' => $data['order_no'], 'order_id' => $data['order_id']);
        /* $order=$this->App_model->payuOrder($cart_id,$user_id,$payment_mode,$orderamount,$shipping_charges,$cod_charges,$shipping_address_id,$app_order,$status,$cartprice,$cartitems,$cartqty,$orderno,$paystatus);
          if($order){
          $order_id=$order['order_id'];
          $order_no=$order['order_no'];
          $response = array('status'=>1,'msg'=>'Order has been placed successfully','order_no'=>$order_no,'order_id'=>$order_id);
          }else{
          $response = array('status'=>1,'msg'=>'Error in processing your request');
          } */
        }else
        {
        $response = array('status' => 0, 'message' => 'Logout', 'logout' => 0); 
        }
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function processPayu_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $cart_items = array();
        // $cod_charges = 70;
        $payment_mode =  4;//$data['payment_mode'];
        $final_amount = $data['final_amount'];
        $shipping_charges = $data['shipping_charges'];
        $cod_charges = 0;//$data['cod_charges'];
        $shipping_address_id = $data['shipping_address_id'];
        $user_id = $data['user_id'];
        $token = $data['token'];
        $checkToken = $this->App_model->getUserToken($user_id);
        if($checkToken->token==$token && $token){
        $cart_id = $data['cart_id'];
        $user_info = $this->App_model->getUserDetails($user_id);
        $app_order = 1;
        $status = 10;
        // if($final_amount > 999){
        // $cod_charges = 0;
        // }
        // if($final_amount > 499){
        // $shipping_charges = 0;
        // }
        // $orderamount = $final_amount + $cod_charges + $shipping_charges;
        $orderamount = $final_amount;
        $customercart = $this->Cart_model->getCustomerCart($user_id);
        // cart items
        $cartprice = $customercart->cart_price;
        $cartitems = $customercart->cart_items;
        $cartqty = $customercart->cart_qty;
        // cart items
		 $orderamount1 = number_format($cartprice + $cod_charges + $shipping_charges, 0, '.', '');
        // cart items
        $final_amount=number_format($final_amount, 0, '.', '');
		if($orderamount1==$final_amount){

        $order = $this->App_model->addOrder($cart_id, $user_id, $payment_mode, $orderamount, $shipping_charges, $cod_charges, $shipping_address_id, $app_order, $status, $cartprice, $cartitems, $cartqty);
        if ($order) {
            /* $order_id=$order['order_id'];
              $order_no=$order['order_no'];
              $digits_needed=6;
              $otp=''; // set up a blank string
              $count=0;
              while ( $count < $digits_needed ) {
              $random_digit = mt_rand(0, 9);

              $otp .= $random_digit;
              $count++;
              }
              $verify_message = 'Your one time password for Patanjali is ' . $otp . '. Treat this as confidential and do not share with anyone.';
              $this->sms->send_sms($user_info->mobile, $verify_message); */
            $response = array('status' => 1, 'cart_id' => $cart_id, 'order_id' => $order['order_id'], 'order_no' => $order['order_no'], 'mobile_number' => $user_info->mobile);
        } else {
            $response = array('status' => 0, 'message' => 'Desired quantity is not available in stock.');
        }}else{
			$response = array('status' => 0, 'message' => 'Please try again.');
		}
        }else
        {
        $response = array('status' => 0, 'message' => 'Logout', 'logout' => 0); 
        }
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function getFdbQuestions_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        //$user_id = $data['user_id'];
        $questionarray = array();
        $questions = $this->Customer_model->getFdbQuestions();
        foreach ($questions as $question) {
            $variants = $this->Customer_model->getQuesvariants($question->que_id);
            $variantarray = array();
            foreach ($variants as $variant) {
                array_push($variantarray, array('ans_id' => $variant->var_id, 'var_text' => $variant->var_text));
            } array_push($questionarray, array('ques_id' => $question->que_id, 'que_text' => $question->que_text, 'variant' => $variantarray));
        } $response = array('status' => 1, 'data' => $questionarray);
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function getHomeslider_post() {
        //$data = json_decode(file_get_contents('php://input'), true);
        $slider_images = $this->Ui_model->getSliderImages();
        if ($slider_images) {
            $sliderarray = array();
            foreach ($slider_images as $image) {
                $data = array('id' => $image->id,
                    //'title' => $image->title,
                    'image' => base_url() . 'assets/home_slider/' . $image->image
                );
                array_push($sliderarray, $data);
            }
            $response = array("status" => 1, "data" => $sliderarray);
        } else {
            $response = array("status" => 0, "message" => "Not Available");
        }
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function latest_products_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $products = $this->Products_model->getHomeProducts('latest',0,0,0,'available_qty','desc');
        $productsarray = array();
        foreach ($products as $product) {
			if($product->available_qty>0){
            $imagename = rawurlencode($product->main_image);
			if($product->mrp and $product->mrp-$product->price>0){
 $offer_per = 'ON OFFER'; 
 $product_offer=1;
 $product_mrp=$product->mrp;
}else{
$product_offer=0;
$offer_per=0;
$product_mrp=0;
}
            array_push($productsarray, array('product_id' => $product->id, 'product_name' => $product->name, 'product_image' => $this->mainimage . $imagename, 'product_price' => $product->price, 'is_veg' => 0, 'product_offer' => $product_offer, 'product_mrp' => $product_mrp,'offer_per'=>$offer_per,'weight' => $product->weight, 'unit' => $product->unit, 'available_qty' => $product->available_qty));
            }  }
        $response = array('status' => 1, 'data' => $productsarray);
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function featured_products_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $products = $this->Products_model->getHomeProducts('featured');
        $productsarray = array();
        foreach ($products as $product) {
			if($product->available_qty>0){
            $imagename = rawurlencode($product->main_image);
            array_push($productsarray, array('product_id' => $product->id, 'product_name' => $product->name, 'product_image' => $this->mainimage . $imagename, 'product_price' => $product->price, 'is_veg' => 0));
        }
}
        $response = array('status' => 1, 'data' => $productsarray);
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function combo_packs_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $ids= array(1032,1033,1044,1046,1047,1048,1049,1058,1059,1072,1074,1075,1076,1077,1078,1079,1080,1081,1082,1083,1084,1085,1086,1087,1088,1089,1090,1091,1092,1093,1094,1095,1096,1097,1098,1099,1100,1106,1107,1108,1109,1110,1111,1112,1113,1114,1115,1116,1147,1148,1151,1158,1159,1160,1163,1164,1165,1166,1176,1177,1178,1179,1180,1181,1182,1183,1193,1223,1224,1230,1229,1228,1227,1225,1222,1221,1220,1219,1218,1217,1214,1213,1210,1208,1205,1204,1203,1200,1199,1198,1197,1196,1195,1194,1233,1234,1239,1240,1242,1243,1244,1245,1246,1247,1250,1251,1252,1253,1188,901,603,1284,1202);//1254
        $products = $this->Products_model->combo_packs($ids);
        $productsarray = array();
        foreach ($products as $product) {
			if($product->available_qty>0){
            $imagename = rawurlencode($product->main_image);
			if($product->mrp and $product->mrp-$product->price>0){
 $offer_per = 'ON OFFER'; 
 $product_offer=1;
 $product_mrp=$product->mrp;
}else{
$product_offer=0;
$offer_per=0;
$product_mrp=0;
}
            array_push($productsarray, array('product_id' => $product->id, 'product_name' => $product->name, 'product_image' => $this->mainimage . $imagename, 'product_price' => $product->price, 'is_veg' => 0, 'product_offer' => $product_offer, 'product_mrp' => $product_mrp,'offer_per'=>$offer_per,'weight' => $product->weight, 'unit' => $product->unit, 'available_qty' => $product->available_qty));
        } }
        $response = array('status' => 1, 'data' => $productsarray);
        $this->response($response, REST_Controller::HTTP_OK);
    }
    public function homeScreenBanner_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $categoriesarray = array();   
		
	array_push($categoriesarray, array('category_id' => 8, 'category_name' => "Natural Personal Care", 'icon' => base_url() . 'assets/app_banner/personal_care.jpg'));       
        array_push($categoriesarray, array('category_id' => 4, 'category_name' => "Ayurvedic Medicine", 'icon' => base_url() . 'assets/app_banner/ayurvedic_medicine.jpg'));       
        array_push($categoriesarray, array('category_id' => 2, 'category_name' => "Natural Food Product", 'icon' => base_url() . 'assets/app_banner/food_product.jpg'));       
        array_push($categoriesarray, array('category_id' => 6, 'category_name' => "Herbal Home Care", 'icon' => base_url() . 'assets/app_banner/home_care.jpg'));       
        array_push($categoriesarray, array('category_id' => 9, 'category_name' => "Patanjali Publication", 'icon' => base_url() . 'assets/app_banner/publication.jpg'));
        //array_push($categoriesarray, array('category_id' => 1, 'category_name' => "Natural Health Care", 'icon' => base_url() . 'assets/app_banner/natural-health-care-450x250.png'));       
       // array_push($categoriesarray, array('category_id' => 8, 'category_name' => "Natural Personal Care", 'icon' => base_url() . 'assets/app_banner/natural-personal-care-450x250.png'));       
       // array_push($categoriesarray, array('category_id' => 4, 'category_name' => "Ayurvedic Medicine", 'icon' => base_url() . 'assets/app_banner/ayurvedic-medicine450x250.jpg'));       
        //array_push($categoriesarray, array('category_id' => 2, 'category_name' => "Natural Food Product", 'icon' => base_url() . 'assets/app_banner/natural-food-products-450x250.png'));       
       // array_push($categoriesarray, array('category_id' => 6, 'category_name' => "Herbal Home Care", 'icon' => base_url() . 'assets/app_banner/herbal-home-care-450x250.png'));       
       // array_push($categoriesarray, array('category_id' => 9, 'category_name' => "Patanjali Publication", 'icon' => base_url() . 'assets/app_banner/publication450x250.png'));       
        $response = array('status' => 1, 'data' => $categoriesarray);
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function searchStore_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $stores = $this->Ui_model->searchStore($data['searchkey']);     
        if($stores){
        $response = array('status' => 1, 'data' => $stores);
        }else{
           $response = array('status' => 0,"message" => "Not Available"); 
        }
        $this->response($response, REST_Controller::HTTP_OK);
    }
    public function storebylocation_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $stores = $this->Ui_model->getStore($data['latitude'],$data['longitude']);
        if($stores){
        $response = array('status' => 1, 'data' => $stores);
        }else{
           $response = array('status' => 0,"message" => "Not Available"); 
        }
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function checkmobile_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $mobile = $data['mobile_number'];
        $status = $this->Customer_model->checkmobile($mobile);
        if ($status) {
            $response = array('status' => 1);
        } else {
            $response = array('status' => 0, 'message' => 'Mobile No. already exists');
        }
        $this->response($response, REST_Controller::HTTP_OK);
    }
    public function changemobile_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $mobile_number = $data['mobile_number'];
        $user_id = $data['user_id'];
        $token = $data['token'];
        $checkToken = $this->App_model->getUserToken($user_id);
        if($checkToken->token==$token && $token){
        $status = $this->Customer_model->checkmobile($mobile_number);
		if($status){
        $otp = rand(123456, 989878);
        $otparray = array('otp' => sha1($otp), 'mobile' => $mobile_number);
        $updateotp = $this->Customer_model->updatecustomerinfo($user_id, $otparray);
        $sms_message = 'Your one time password for Patanjali is ' . $otp . '. Treat this as confidential and do not share with anyone.';
        $this->sms->send_sms($mobile_number, $sms_message);
        $response = array('status' => 1,'otp' => $otp, "message" => "Otp has been sent to your mobile , verify your account first.");
		}else{
		$response = array('status' => 0, 'message' => 'Mobile No. already exists');	
		}	
                }else
        {
        $response = array('status' => 0, 'message' => 'Logout', 'logout' => 0); 
        }
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function social_login_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $userarray = array();
        $email = $data['email'];
        $social_id = $data['social_id'];
        $social_type = $data['social_type'];
        $user = $this->Customer_model->check_social_login($social_type, $social_id);
        //$token='9UAacXGYyG2wIkEeVaXTBFyQqOhfdqcN';
            $token=token();
        if ($user) {
            
            if ($user->is_block == 1) {
                $response = array('status' => 0, 'error' => 'Your account has been disabled');
            } else {
                
            $customerinfo = array(
            'token' => $token          
            );
            $this->Customer_model->updatecustomerinfo($user->id, $customerinfo);
                if ($user->status == 1 and $user->is_otp_verified == 1) {
                    array_push($userarray, array('customer_id' => $user->id, 'firstname' => $user->firstname, 'lastname' => $user->lastname, 'email' => $user->email, 'mobile' => $user->mobile, 'token' => $token));
                    $response = array('status' => 1, 'data' => $userarray, "message" => "You have successfully logged in.");
                } else {
                    array_push($userarray, array('customer_id' => $user->id, 'firstname' => $user->firstname, 'lastname' => $user->lastname, 'email' => $user->email, 'mobile' => $user->mobile, 'token' => $token));
                    $otp = rand(123456, 989878);
                    $sms_message = 'Your one time password for Patanjali is ' . $otp . '. Treat this as confidential and do not share with anyone.';
                    $this->sms->send_sms($user->mobile, $sms_message);
                    $response = array('status' => 0, 'otp' => $otp, 'data' => $userarray, "message" => "Otp has been sent to your mobile , verify your account first.");
                }
            }
        } else {
            $user = $this->Customer_model->getCustomerProfile($email);            
            if($user) {
            if ($user->is_block == 1) {
                $response = array('status' => 0, 'error' => 'Your account has been disabled');
            } else {
                
            $customerinfo = array(
            'token' => $token          
            );
            $this->Customer_model->updatecustomerinfo($user->id, $customerinfo);
                if ($user->status == 1 and $user->is_otp_verified == 1) {
                    array_push($userarray, array('customer_id' => $user->id, 'firstname' => $user->firstname, 'lastname' => $user->lastname, 'email' => $user->email, 'mobile' => $user->mobile, 'token' => $token));
                    $response = array('status' => 1, 'data' => $userarray, "message" => "You have successfully logged in.");
                } else {
                    array_push($userarray, array('customer_id' => $user->id, 'firstname' => $user->firstname, 'lastname' => $user->lastname, 'email' => $user->email, 'mobile' => $user->mobile, 'token' => $token));
                    $otp = rand(123456, 989878);
                    $sms_message = 'Your one time password for Patanjali is ' . $otp . '. Treat this as confidential and do not share with anyone.';
                    $this->sms->send_sms($user->mobile, $sms_message);
                    $response = array('status' => 0, 'otp' => $otp, 'data' => $userarray, "message" => "Otp has been sent to your mobile , verify your account first.");
                }
            }            
                }
            else{
            $response = array("status" => 2, 'message' => "Social id not available");
            
            }
        }
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function social_register_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $userarray = array();
        $title = $data['title'];
        $firstname = $data['firstname'];
        $lastname = $data['lastname'];
        $email = $data['email'];
        //$password = $data['password'];
        //$mobile = $data['mobile'];
        $social_id = $data['social_id'];
        $social_type = $data['social_type'];
        $checkuser = $this->App_model->checkEmail($email);
        if (!$checkuser) {
            //$mobilestatus = $this->Customer_model->checkmobile($mobile);
            //if ($mobilestatus) {
            //$token='9UAacXGYyG2wIkEeVaXTBFyQqOhfdqcN';
            $token=token();
                $customerinfo = array(
                    'title' => $title,
                    'firstname' => $firstname,
                    'lastname' => $lastname,
                    'email' => $email,
                    //'password' => sha1($password),
                    'is_app_registered' => 1,
                    'created_dt' => time(),
                    'social_type' => $social_type,
                    'social_id' => $social_id,
                    'status' => 1,
                    'token' => $token
                    //'mobile' => $mobile
                        );
                $customer_id = $this->Customer_model->register($customerinfo);
                $user = $this->Customer_model->getCustomerDetails($customer_id);
                $digits_needed = 6;
                $otp = ''; // set up a blank string
                $count = 0;
                while ($count < $digits_needed) {
                    $random_digit = mt_rand(0, 9);
                    $otp .= $random_digit;
                    $count++;
                }
                $otparray = array('otp' => sha1($otp));
                $updateotp = $this->Customer_model->updatecustomerinfo($user->id, $otparray);
                $mobilenumber = $user->mobile;
                $sms_message = 'Your one time password for Patanjali is ' . $otp . '. Treat this as confidential and do not share with anyone.';
                $this->sms->send_sms($mobilenumber, $sms_message);
                array_push($userarray, array('customer_id' => $user->id, 'firstname' => $user->firstname, 'lastname' => $user->lastname, 'email' => $user->email, 'mobile' => $user->mobile, 'otp' => $otp, 'token' => $token));
                $response = array('status' => 1, 'data' => $userarray, "message" => "You are registered successfully");
            //} else {
            //    $response = array('status' => 0, 'message' => 'Mobile No. already exist.');
           // }
        } else {
            $response = array('status' => 0, "message" => "Email id already exist");
        }
        $this->response($response, REST_Controller::HTTP_OK);
    }
    public function processPaytm_post() {
            $data = json_decode(file_get_contents('php://input'), true);
            $cart_items = array();
            // $cod_charges = 70;
            $payment_mode = 3;//$data['payment_mode'];
            $final_amount = $data['final_amount'];
            $shipping_charges = $data['shipping_charges'];
            $cod_charges = 0;//$data['cod_charges'];
            $shipping_address_id = $data['shipping_address_id'];
            $user_id = $data['user_id'];
            $token = $data['token'];
        $checkToken = $this->App_model->getUserToken($user_id);
        if($checkToken->token==$token && $token){
            $cart_id = $data['cart_id'];
            $user_info = $this->App_model->getUserDetails($user_id);
            $app_order = 1;
            $status = 10;
           
            $orderamount = $final_amount;
            $customercart = $this->Cart_model->getCustomerCart($user_id);
            // cart items
            $cartprice = $customercart->cart_price;
            $cartitems = $customercart->cart_items;
            $cartqty = $customercart->cart_qty;
            // cart items
 $orderamount1 = number_format($cartprice + $cod_charges + $shipping_charges, 0, '.', '');
        // cart items
        $final_amount=number_format($final_amount, 0, '.', '');
		if($orderamount1==$final_amount){
            $order = $this->App_model->addOrder($cart_id, $user_id, $payment_mode, $orderamount, $shipping_charges, $cod_charges, $shipping_address_id, $app_order, $status, $cartprice, $cartitems, $cartqty);
            if ($order) {
                
                $response = array('status' => 1, 'cart_id' => $cart_id, 'order_id' => $order['order_id'], 'order_no' => $order['order_no'], 'mobile_number' => $user_info->mobile);
            } else {
                $response = array('status' => 0, 'message' => 'Desired quantity is not available in stock.');
            }}else{
			$response = array('status' => 0, 'message' => 'Please try again.');
		}
            }else
        {
        $response = array('status' => 0, 'message' => 'Logout', 'logout' => 0); 
        }
            $this->response($response, REST_Controller::HTTP_OK);
        }
        public function paytmResponse_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $order_no = $data['order_no'];
        $order_id = $data['order_id'];
       // $final_amount = $data['final_amount'];        
        $user_id = $data['user_id'];
        $token = $data['token'];
        $checkToken = $this->App_model->getUserToken($user_id);
        if($checkToken->token==$token && $token){
        $cart_id = $data['cart_id'];
        $user_info = $this->App_model->getUserDetails($user_id);
        $app_order = 1;
        $status = 0;
        //$orderamount = $final_amount;

        // cart items
        $paytm_array = array('MID' => $data['MID'],
            'ORDERID' => $order_no,
            'TXNAMOUNT' => $data['TXNAMOUNT'],
            'CURRENCY' => $data['CURRENCY'],
            'TXNID' => $data['TXNID'],
            'BANKTXNID' => $data['BANKTXNID'],
            'STATUS' => $data['STATUS'],
            'RESPCODE' => $data['RESPCODE'],
            'RESPMSG' => $data['RESPMSG'],
            'TXNDATE' => $data['TXNDATE'],
            'GATEWAYNAME' => $data['GATEWAYNAME'],
            'BANKNAME' => $data['BANKNAME'],
            'PAYMENTMODE' => $data['PAYMENTMODE'],
            'CHECKSUMHASH' => $data['CHECKSUMHASH']);

        $paytm_values = $this->Transactions_model->insertPaytmValues($paytm_array);

        $order_detail = $this->Orders_model->getOrderDetails($order_id);
        $orderno = $order_detail->order_no;
        $fullorderdetails = $this->Orders_model->getFullorderDetails($order_id);
        $itemarray1 = array('status' => 0, 'payment_status' => 1, 'is_confirmed' => 1, 'modified_dt' => time(), 'modified_by' => $user_id);
        $value1 = $this->Orders_model->updateorder($order_id, $itemarray1);
        $cartitems = $this->Cart_model->getCartItems($cart_id);
        foreach ($cartitems as $item) {
            $this->Products_model->updateQuantity($item->product_id, $item->quantity);
            $this->Products_model->updatePackageQuantity($item->product_id, $item->quantity);
        }
        $this->Cart_model->removeCart($cart_id, $user_id);

        $message = 'Dear Sir/Madam,' . '<br>' . 'Your Order Was Successfull, Below is your order number for further references.' . '<br>' . 'Patanjali Ayurved Limited, Company TIN No. 05006754814' . '<br>' . 'Your Order Number is' . '&nbsp;' . $orderno . ' and your order amount is Rs.' . $final_amount . ' (inclusive of shipping charges)';

        $subject = 'Order Confirmation - Your Order with "patanjaliayurved.net" ' . $orderno . ' has been successfully placed!';
        $to = $user_info->email;
        $mobile_number = $user_info->mobile;
        // $sms_message = 'Hello Mr/Mrs/Ms' . $user_info->firstname . ' ,this is a confirmation message from patanjaliayurved.net.Your order has been placed successfully.Order No : ' . $txnid;
        $sms_message = 'Your order at patanjali has been placed successfully . Your order number is ' . $orderno . '. and order amount is ' . $final_amount . '. Thank you for choosing patanjali.';
        //send email
        $custom = array('type' => 'order', 'details' => array('name' => $user_info->firstname, 'orderno' => $orderno, 'order_detail' => $order_detail, 'fullorderdetails' => $fullorderdetails));
        sendEmail($to, $subject, $message, $custom);

        $this->sms->send_sms($mobile_number, $sms_message);
        $response = array('status' => 1, 'msg' => 'Order has been placed successfully', 'order_no' => $data['order_no'], 'order_id' => $data['order_id']);
        }else
        {
        $response = array('status' => 0, 'message' => 'Logout', 'logout' => 0); 
        }
        $this->response($response, REST_Controller::HTTP_OK);
    }
        public function pincodeAvailability_post() {
            $data = json_decode(file_get_contents('php://input'), true);
        $pincode = $data['pincode'];
        $codavailable = 0;
        $prepaidavailable = 0;
        $status = 0;
        $msg= "Delivery to this pincode is not available.";
          
        $checkcoddtdc = $this->Orders_model->getDtdcPriceByPincode($pincode, 1);
        $checkcodxpressbees = $this->Orders_model->getXpressBeesByPincode($pincode, 1);
        $checkcodecomexpress = $this->Orders_model->getEcomExpressByPincode($pincode, 1);
        $checkcoddelhivery = $this->Orders_model->getDelhiveryByPincode($pincode, 1);                    
        $checkcodbluedart = $this->Orders_model->getBluedartPriceByPincode($pincode, 1);           
        if($checkcoddtdc or $checkcodxpressbees or $checkcodecomexpress or $checkcoddelhivery or $checkcodbluedart){
		$codavailable = 1;
		$status=1;
                $msg= "Only COD delivery to this pincode is available.";
		}		
        $checkprepaiddtdc = $this->Orders_model->getDtdcPriceByPincode($pincode, 2);
        $checkprepaidxpressbees = $this->Orders_model->getXpressBeesByPincode($pincode, 2);
        $checkprepaidecomexpress = $this->Orders_model->getEcomExpressByPincode($pincode, 2);
        $checkprepaiddelhivery = $this->Orders_model->getDelhiveryByPincode($pincode, 2);                    
        $checkprepaidbluedart = $this->Orders_model->getBluedartPriceByPincode($pincode, 2);  
        if($checkprepaiddtdc or $checkprepaidxpressbees or $checkprepaidecomexpress or $checkprepaiddelhivery or $checkprepaidbluedart){
		$prepaidavailable = 1;
		$status=2;
                $msg= "Only prepaid delivery to this pincode is available.";
		}
		if($codavailable == 1 and $prepaidavailable == 1){
		$status=3;
                $msg= "Both cod and prepaid delivery to this pincode is available.";
		}
		$status=3;
                $msg= "Both cod and prepaid delivery to this pincode is available.";
        $response = array('status' => $status, 'msg' => $msg);

        $this->response($response, REST_Controller::HTTP_OK);
        }
        public function generateChecksum_post() {
            $data = json_decode(file_get_contents('php://input'), true);
            $this->load->helper('paytm');
            $paytm = $this->config->item('paytm');
            $checkSum = "";
            $paramList = array();           
            $paramList["MID"] = $data["MID"];
            $paramList["ORDER_ID"] = $data["ORDER_ID"];
            $paramList["CUST_ID"] = $data["CUST_ID"];
            $paramList["INDUSTRY_TYPE_ID"] = $data["INDUSTRY_TYPE_ID"];
            $paramList["CHANNEL_ID"] = $data["CHANNEL_ID"];
            $paramList["TXN_AMOUNT"] = $data["TXN_AMOUNT"];
            $paramList["WEBSITE"] = $data["WEBSITE"];
            $paramList["EMAIL"] = $data["EMAIL"];
            $paramList["MOBILE_NO"] = $data["MOBILE_NO"];
            $paramList["CALLBACK_URL"] = $data["CALLBACK_URL"];//"https://securegw-stage.paytm.in/theia/paytmCallback?ORDER_ID=" + $data["ORDER_ID"]; 
            $checkSum = getChecksumFromArray($paramList, $paytm['PAYTM_MERCHANT_KEY']);
            $response=array("CHECKSUMHASH" => $checkSum,"ORDER_ID" => $data["ORDER_ID"], "payt_STATUS" => "1");      
            $this->response($response, REST_Controller::HTTP_OK);
         }
         public function verifyChecksum_post() {
            $this->load->helper('paytm');
            $paytm = $this->config->item('paytm');
            $checkSum = "";
            $paramList = array();           
            $paramList["MID"] = $_POST["MID"];
            $paramList["ORDER_ID"] = $_POST["ORDER_ID"];
            $paramList["CUST_ID"] = $_POST["CUST_ID"];
            $paramList["INDUSTRY_TYPE_ID"] = $_POST["INDUSTRY_TYPE_ID"];
            $paramList["CHANNEL_ID"] = $_POST["CHANNEL_ID"];
            $paramList["TXN_AMOUNT"] = $_POST["TXN_AMOUNT"];
            $paramList["WEBSITE"] = $_POST["WEBSITE"];
            $paramList["EMAIL"] = $_POST["EMAIL"];
            $paramList["MOBILE_NO"] = $_POST["MOBILE_NO"];
            $checkSum = getChecksumFromArray($paramList, $paytm['PAYTM_MERCHANT_KEY']);
            $response=array("CHECKSUMHASH" => $checkSum,"ORDER_ID" => $_POST["ORDER_ID"], "payt_STATUS" => "1");      
            $this->response($response, REST_Controller::HTTP_OK);
         }
}
