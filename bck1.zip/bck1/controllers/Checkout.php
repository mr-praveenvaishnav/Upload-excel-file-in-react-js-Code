<?php

defined('BASEPATH') OR exit('No direct script access allowed');
require_once APPPATH . "/third_party/razorpay-php/Razorpay.php";
use Razorpay\Api\Api;

class Checkout extends CI_Controller {

    public function __construct() {
        parent:: __construct();
        $this->load->model('Customer_model');
        $this->load->model('Order_model');
        $this->load->model('App_model');
    }

    public function index() {
        
    }

    public function orderProcess() {
        $data = json_decode(file_get_contents('php://input'), true);
        $cart_items = array();
        $cod_charges = 0;
        $coupon_id = 0;
        $coupon_discount = 0;
        $wallet_amount = 0;
        $wallet = $data['wallet'];
        $payment_mode = $data['payment_mode'];
        $shipping_address_id = $data['shipping_address_id'];
        $billing_address_id = $data['billing_address_id'];
        $coupon_code = $data['coupon_code'];
        $customer_id = $data['customer_id'];
        $token = $data['token'];
        if ($data) {
        if (verifyToken($customer_id, $token)) {
            if (getpaymenttype($payment_mode) && $payment_mode) {
                if ($coupon_code) {
                    $coupondetail = json_decode($this->App_model->applyCoupon($customer_id, $coupon_code));
                    if ($coupondetail->status == 1) {
                        $coupon_id = $coupondetail->data->coupon_id;
                        $coupon_discount = $coupondetail->data->discount_amount;
                    }
                }
                $app_order = 1;
                $status = 0;
                //$customer_detail = $this->Customer_model->getCustomerDetails($customer_id);   
                $cart_detail = $this->Product_model->getCartDetail($customer_id);
                $cartprice = $cart_detail['amount'];
                $cartitems = $cart_detail['itemcount'];
                $cartqty = $cart_detail['itemquantity'];
                $cod_charges_limit = $this->config->item('cod_charges_limit');
                $shipping_charges_limit = $this->config->item('shipping_charges_limit');
                if ($payment_mode == 1) {
                    if ($cartprice >= $cod_charges_limit) {
                        $cod_charges = 0;
                    } else {
                        $cod_charges = $this->config->item('cod_charges');
                    }
                }
                if ($cartprice >= $shipping_charges_limit) {
                    $shipping_charges = 0;
                } else {
                    $shipping_charges = 25;
                }
                $orderamount = number_format($cartprice + $cod_charges + $shipping_charges - $coupon_discount, 0, '.', '');
                if ($wallet == 1) {
                    $avail_wallet_amount = $this->Customer_model->getWalletAmount($customer_id);
                    if ($avail_wallet_amount < $orderamount - $cod_charges) {
                        $wallet_amount = $avail_wallet_amount;
                    } else {
                        $wallet_amount = $orderamount - $cod_charges;
                        $orderamount = $orderamount - $cod_charges;
                        $payment_mode = 11;
                        $cod_charges = 0;
                    }
                }
                $finalamount = $orderamount - $wallet_amount;
                $order = $this->Order_model->addOrder($customer_id, $payment_mode, $finalamount, $shipping_charges, $cod_charges, $wallet_amount, $shipping_address_id, $billing_address_id, $app_order, $status, $cartprice, $cartitems, $cartqty, $coupon_id, $coupon_discount);
                if ($order['status'] == 1) {
                    $url = "";
                    $order_id = $order['order_id'];
                    $order_no = $order['order_no'];
                    if ($payment_mode == 11) {
                        $this->confirmOrder($order_id, $customer_id, $token);
                    } elseif ($payment_mode == 1) {
                        $this->confirmOrder($order_id, $customer_id, $token);
                    } elseif ($payment_mode == 3) {
                        $url = base_url().'checkout/processpaytm/' . $customer_id . '/' . $order_id;
                    } elseif ($payment_mode == 4) {
                        $url = base_url().'checkout/processpayu/' . $customer_id . '/' . $order_id;
                    } elseif ($payment_mode == 7) {
                        $url = base_url().'checkout/processmobikwik/' . $customer_id . '/' . $order_id;
                    } elseif ($payment_mode == 8) {
                        $url = base_url().'checkout/processphonepe/' . $customer_id . '/' . $order_id;
                    } elseif ($payment_mode == 9) {
                        $url = base_url().'checkout/process_ssc/' . $customer_id . '/' . $order_id;
                    } elseif ($payment_mode == 10) {
                        $url = base_url().'checkout/processrazorpay/' . $customer_id . '/' . $order_id;
                    }
                    if($url){
                    $response = array('status' => 10, 'date' => array('order_id' => $order_id, 'order_no' => $order_no,'url'=>$url));
                    }else{                  
                    $response = array('status' => 1, 'date' => array('order_id' => $order_id, 'order_no' => $order_no), 'message' => 'Order has been placed successfully.');
                    }
                } else {
                    $response = array('status' => 0, 'message' => $order['message']);
                }
            } else {
                $response = array('status' => 0, 'message' => 'Invalid Payment Mode');
            }
        } else {
            $response = array('status' => 0, 'message' => 'Token mismatch');
        }
        } else {
            $response = array('status' => 0, 'message' => 'Invalid Json');
        }
        echo json_encode($response);
    }

    public function confirmOrder($order_id, $customer_id, $token = 0) {
        // if (verifyToken($customer_id, $token)) {
        $OrderDetails = $this->Order_model->getOrderDetails($order_id, $customer_id);
        if ($OrderDetails) {
            $avail_wallet_amount = $this->Customer_model->getWalletAmount($customer_id);
            if ($avail_wallet_amount >= $OrderDetails->WalletAmount) {
                if ($OrderDetails->Status == 0 and $OrderDetails->PaymentStatus == 0) {
                    $itemarray1 = array('Status' => 1, 'PaymentStatus' => 1,'IsConfirmed'=>1);
                    $value1 = $this->Order_model->updateOrder($order_id, $itemarray1);
                    $order_items = $this->Order_model->getOrderAllItems($order_id);
                    if ($order_items) {
                        foreach ($order_items as $product) {
                            $this->Product_model->updateQuantity($product->ProductId, $product->Quantity * $product->ItemQuantity);
                        }
                    }
                    if ($OrderDetails->WalletAmount > 0) {
                        $wallet_data = array(
                            'CustomerId' => $customer_id,
                            'OrderId' => $order_id,
                            'Amount' => $OrderDetails->WalletAmount,
                            'AmountType' => 'debit',
                            'Description' => 'Paid on Order No : ' . $OrderDetails->OrderNumber,
                            'Status' => 1
                        );
                        $this->Customer_model->addWalletAmount($wallet_data);
                    }
                    $response = array('status' => 1, 'message' => 'Order has been placed successfully.');
                } else {
                    $response = array('status' => 1, 'message' => 'Order has been placed successfully.');
                }
            } else {
                $response = array('status' => 0, 'message' => 'Insufficient wallet balance.');
            }
        } else {
            $response = array('status' => 0, 'message' => 'Error');
        }
        return $response;
        // } else {
        //      $response = array('status' => 0, 'message' => 'Token mismatch');
        //  }
        //$this->response($response, REST_Controller::HTTP_OK);
    }

    public function processpaytm($customer_id, $order_id) {
        $this->load->helper('paytm');
        $paytm = $this->config->item('paytm');
        $checkSum = "";
        $paramList = array();
        $customer_detail = $this->Customer_model->getCustomerDetails($customer_id);
        $OrderDetails = $this->Order_model->getOrderDetails($order_id, $customer_id);
        if ($OrderDetails) {
            $paramList["MID"] = $paytm['PAYTM_MERCHANT_MID'];
            $paramList["ORDER_ID"] = $OrderDetails->OrderNumber;
            $paramList["CUST_ID"] = $customer_id;
            $paramList["INDUSTRY_TYPE_ID"] = $paytm['PAYTM_INDUSTRY_TYPE_ID'];
            $paramList["CHANNEL_ID"] = $paytm['PAYTM_CHANNEL_ID'];
            $paramList["TXN_AMOUNT"] = $OrderDetails->FinalAmount;
            $paramList["WEBSITE"] = $paytm['PAYTM_MERCHANT_WEBSITE'];
            $paramList["MOBILE_NO"] = $customer_detail->Mobile;
            $paramList["EMAIL"] = $customer_detail->Email;
            $paramList["CALLBACK_URL"] = base_url() . "checkout/paytm_response";
            $checkSum = getChecksumFromArray($paramList, $paytm['PAYTM_MERCHANT_KEY']);
            $paramList["CHECKSUMHASH"] = $checkSum;
            $data["PAYTM_TXN_URL"] = $paytm['PAYTM_TXN_URL'];
            $data["parameters"] = $paramList;
            $this->load->view('checkout/processpaytm', $data);
        } else {
            echo "error";
        }
    }

    public function paytm_response() {
        $this->load->helper('paytm');
        $paytm = $this->config->item('paytm');
        $paytmChecksum = "";
        $paramList = array();
        $isValidChecksum = FALSE;
        $customer_id = $this->input->post('CUST_ID');
        $customer_detail = $this->Customer_model->getCustomerDetails($customer_id);
        $paramList = $this->input->post();
        $order_no = $this->input->post('ORDERID');
        $OrderDetails = $this->Order_model->getOrderNumber($order_no);
        $txn_number = $this->input->post('TXNID');
        if ($txn_number == null) {
            $txn_number = 0;
        }
        $MID = $this->input->post('MID');
        $TXNAMOUNT = $this->input->post('TXNAMOUNT');
        $CURRENCY = $this->input->post('CURRENCY');
        if ($CURRENCY == null) {
            $CURRENCY = 0;
        }
        $BANKTXNID = $this->input->post('BANKTXNID');
        if ($BANKTXNID == null) {
            $BANKTXNID = 0;
        }
        $STATUS = $this->input->post('STATUS');
        if ($STATUS == null) {
            $STATUS = 0;
        }
        $RESPCODE = $this->input->post('RESPCODE');
        if ($RESPCODE == null) {
            $RESPCODE = 0;
        }
        $RESPMSG = $this->input->post('RESPMSG');
        if ($RESPMSG == null) {
            $RESPMSG = 0;
        }
        $TXNDATE = $this->input->post('TXNDATE');
        if ($TXNDATE == null) {
            $TXNDATE = 0;
        }
        $GATEWAYNAME = $this->input->post('GATEWAYNAME');
        if ($GATEWAYNAME == null) {
            $GATEWAYNAME = 0;
        }
        $BANKNAME = $this->input->post('BANKNAME');
        if ($BANKNAME == null) {
            $BANKNAME = 0;
        }
        $PAYMENTMODE = $this->input->post('PAYMENTMODE');
        if ($PAYMENTMODE == null) {
            $PAYMENTMODE = 0;
        }
        $CHECKSUMHASH = $this->input->post('CHECKSUMHASH');
        $paytm_array = array('MID' => $MID,
            'ORDERID' => $order_no,
            'TXNAMOUNT' => $TXNAMOUNT,
            'CURRENCY' => $CURRENCY,
            'TXNID' => $txn_number,
            'BANKTXNID' => $BANKTXNID,
            'STATUS' => $STATUS,
            'RESPCODE' => $RESPCODE,
            'RESPMSG' => $RESPMSG,
            'TXNDATE' => $TXNDATE,
            'GATEWAYNAME' => $GATEWAYNAME,
            'BANKNAME' => $BANKNAME,
            'PAYMENTMODE' => $PAYMENTMODE,
            'CHECKSUMHASH' => $CHECKSUMHASH);
        //$paytm_values = $this->Transactions_model->insertPaytmValues($paytm_array);
        $paytmChecksum = isset($paramList["CHECKSUMHASH"]) ? $paramList["CHECKSUMHASH"] : "";
        $isValidChecksum = verifychecksum_e($paramList, $paytm['PAYTM_MERCHANT_KEY'], $paytmChecksum);
        if ($isValidChecksum === TRUE) {
            if ($this->input->post("STATUS") == "TXN_SUCCESS") {
                //echo "<b>Transaction status is success</b>" . "<br/>";
                //Process your transaction here as success transaction.
                //Verify amount & order id received from Payment gateway with your application's order id and amount.
                $r = $this->confirmOrder($OrderDetails->OrderId, $customer_id);
                // now redirect
//                $message = 'Dear Sir/Madam,' . '<br>' . 'Your Transaction with PAYTM was Successfull, Below is your order number for further references.' . '<br>' . 'Patanjali Ayurved Limited, Company TIN No. 05006754814' . '<br>' . 'Your Order Number is' . '&nbsp;' . $order_no . ' and your order amount is Rs.' . $TXNAMOUNT . ' (inclusive of shipping charges)';
//                $subject = 'Order Confirmation - Your Order with "patanjaliayurved.net" ' . $order_no . ' has been successfully placed!';
//                $to = $customer_detail->email;
//                $mobile_number = $customer_detail->mobile;
//                // $sms_message = "Your order has been placed successfully..Your order number is" . $order_no;
//                $sms_message = 'Your order at patanjali has been placed successfully . Your order number is ' . $order_no . '. and order amount is ' . $TXNAMOUNT . '. Thank you for choosing patanjali.';
//                //send email
//                $custom = array('type' => 'order', 'details' => array('name' => $customer_detail->firstname, 'orderno' => $order_no, 'order_detail' => $order_detail, 'fullorderdetails' => $fullorderdetails));
//                sendEmail($to, $subject, $message, $custom);
//                $this->sms->send_sms($mobile_number, $sms_message);
//                // @TO-DO : Send email to admin for payment recieved for order submitted
//                // @TO-DO : Update order table and deduct the quantity for inventory
//                $this->session->set_flashdata('update_msg', 'Order #' . $order_no . ' placed successfully.');
//                //$this->Transactions_model->add($data);
//                $this->session->set_userdata('torder_id', $OrderDetails->OrderId);
                redirect('/checkout/thankyou');
            } else {
                //echo "<b>Transaction status is failure</b>" . "<br/>";
//                $message = 'Dear Sir/Madam,' . '<br>' . 'Your order#' . $order_no . ' was not processed because of failed transaction';
//                $subject = 'Order failure';
//                $to = $customer_detail->email;
//                $mobile_number = $customer_detail->mobile;
//                $sms_message = 'Hello , Your order with reference to the order number ' . $order_no . ' is not processed due to a failed transaction';
//                //send email
//                sendEmail($to, $subject, $message);
//                $this->load->library('sms');
//                $this->sms->send_sms($mobile_number, $sms_message);
//                $this->session->set_flashdata('update_msg', 'Payment for Order #' . $order_no . ' failed.');
//                //$this->Transactions_model->add($data);
                redirect('/checkout/orderdetails/' . $OrderDetails->OrderId);
            }
        } else {
            echo "<b>Checksum mismatched.</b>";
            //Process transaction as suspicious.
        }  
    }

    public function processpayu($customer_id, $order_id) {
        $customer_detail = $this->Customer_model->getCustomerDetails($customer_id);
        $OrderDetails = $this->Order_model->getOrderDetails($order_id, $customer_id);
        if ($OrderDetails) {
            $MERCHANT_KEY = "gtKFFx"; // live kBck2c // test gtKFFx
            $SALT = "eCwWELxi"; // live DMe4KJre test eCwWELxi
            $PAYU_BASE_URL = "https://test.payu.in"; //"https://secure.payu.in";
            $action = '';
            $posted = array();
            $final_amount = $OrderDetails->FinalAmount;
            $hash = '';
            $hashSequence = "key|txnid|amount|productinfo|name|email|udf1|udf2|udf3|udf4|udf5|udf6|udf7|udf8|udf9|udf10";
            $hashVarsSeq = explode('|', $hashSequence);
            $hash_string = '';
            $posted = array($MERCHANT_KEY, $OrderDetails->OrderNumber, $final_amount, 'patanjali', $customer_detail->Name, $customer_detail->Email, $customer_detail->CustomerId, '', '', '', '', '', '', '', '', '', $SALT);
            //print_r($posted);
            $hash_string = implode('|', $posted);
            $hash = strtolower(hash('sha512', $hash_string));
            $action = $PAYU_BASE_URL . '/_payment';
            $data['PAYU_BASE_URL'] = $action;
            $data['MERCHANT_KEY'] = $MERCHANT_KEY;
            $data['hash'] = $hash;
            $data['txnid'] = $OrderDetails->OrderNumber;
            $data['final_amount'] = $final_amount;
            $data['name'] = $customer_detail->Name;
            $data['email'] = $customer_detail->Email;
            $data['customer_id'] = $customer_detail->CustomerId;
            $this->load->view('checkout/processpayu', $data);
        } else {
            echo "error";
        }
    }

    public function payusuccess() {
        $status = $this->input->post('status');
        $name = $this->input->post('firstname');
        $customer_id = $this->input->post('udf1');
        $mihpayid = $this->input->post('mihpayid');
        $mode = $this->input->post('mode');
        $cardCategory = $this->input->post('cardCategory');
        $net_amount_debit = $this->input->post('net_amount_debit');
        $addedon = $this->input->post('addedon');
        $amount = $this->input->post('amount');
        $txnid = $this->input->post('txnid');
        $discount = $this->input->post('discount');
        $posted_hash = $this->input->post('hash');
        $payment_source = $this->input->post('payment_source');
        $issuing_bank = $this->input->post('issuing_bank');
        $card_type = $this->input->post('card_type');
        $name_on_card = $this->input->post('name_on_card');
        $cardnum = $this->input->post('cardnum');
        $key = $this->input->post('key');
        $productinfo = $this->input->post('productinfo');
        $email = $this->input->post('email');
        $salt = "eCwWELxi"; // live DMe4KJre // test eCwWELxi
        $payu_array = array('mihpayid' => $mihpayid,
            'mode' => $mode,
            'status' => $status,
            'txnid' => $txnid,
            'amount' => $amount,
            'cardCategory' => $cardCategory,
            'net_amount_debit' => $net_amount_debit,
            'addedon' => $addedon,
            'productinfo' => $productinfo,
            'discount' => $discount,
            'hash' => $posted_hash,
            'payment_source' => $payment_source,
            'issuing_bank' => $issuing_bank,
            'card_type' => $card_type,
            'name_on_card' => $name_on_card,
            'cardnum' => $cardnum
        );
        //$payu_values = $this->Transactions_model->insertPayuValues($payu_array);
        If (isset($_POST['additionalCharges'])) {
            $additionalCharges = $this->input->post('additionalCharges');
            $retHashSeq = $additionalCharges . '|' . $salt . '|' . $status . '||||||||||' . $customer_id . '|' . $email . '|' . $name . '|' . $productinfo . '|' . $amount . '|' . $txnid . '|' . $key;
        } else {
            $retHashSeq = $salt . '|' . $status . '||||||||||' . $customer_id . '|' . $email . '|' . $name . '|' . $productinfo . '|' . $amount . '|' . $txnid . '|' . $key;
        }
        $hash = hash("sha512", $retHashSeq);
        if ($hash == $posted_hash) {
            $orderdetail = $this->Order_model->getOrderNumber($txnid);
            $r = $this->confirmOrder($orderdetail->OrderId, $customer_id);
//            $customer_detail = $this->Customer_model->getCustomerDetails($customer_id);      
//            $this->Cart_model->removeCart($cart_id, $customer_id);
//            $message = 'Dear Sir/Madam,' . '<br>' . 'Your Order Was Successfull, Below is your order number for further references.' . '<br>' . 'Patanjali Ayurved Limited, Company TIN No. 05006754814' . '<br>' . 'Your Order Number is' . '&nbsp;' . $txnid . ' and your order amount is Rs.' . $amount . ' (inclusive of shipping charges)';
//            $subject = 'Order Confirmation - Your Order with "patanjaliayurved.net" ' . $txnid . ' has been successfully placed!';
//            $to = $customer_detail->Email;
//            $mobile_number = $customer_detail->Mobile;
//            // $sms_message = 'Hello Mr/Mrs/Ms' . $customer_detail->Name . ' ,this is a confirmation message from patanjaliayurved.net.Your order has been placed successfully.Order No : ' . $txnid;
//            $sms_message = 'Your order at patanjali has been placed successfully . Your order number is ' . $txnid . '. and order amount is ' . $amount . '. Thank you for choosing patanjali.';
//            //send email
//            $custom = array('type' => 'order', 'details' => array('name' => $customer_detail->Name, 'orderno' => $txnid, 'order_detail' => $order_detail, 'fullorderdetails' => $fullorderdetails));
//            sendEmail($to, $subject, $message, $custom);
//            $this->sms->send_sms($mobile_number, $sms_message);
//            $this->session->set_userdata('torder_id', $OrderDetails->OrderId);
//            $this->session->set_flashdata('update_msg', 'Order has been placed successfully');
            redirect('/checkout/thankyou');
        } else {
            // cancel order
            $customer_detail = $this->Customer_model->getCustomerDetails($customer_id);
            $order_id = $this->Order_model->getOrderNumber($txnid);
//            $message = 'Hello , Your order with reference to the order number ' . $txnid . ' is not processed due to a failed transaction';
//            $subject = 'Order failure';
//            $to = $customer_detail->Email;
//            $mobile_number = $customer_detail->Mobile;
//            $sms_message = 'Hello , your order with reference to ' . $txnid . ' has been cancelled due to a failed transaction.';
//            //send email
//            sendEmail($to, $subject, $message);
//            $this->load->library('sms');
//            $this->sms->send_sms($mobile_number, $sms_message);
//            $this->session->set_flashdata('update_msg', 'Payment for Order #' . $txnid . ' failed.');
            redirect('/checkout/orderdetails/' . $OrderDetails->OrderId);
        }
    }

    public function payufailure() {
        $status = $this->input->post('status');
        $name = $this->input->post('firstname');
        $customer_id = $this->input->post('udf1');
        $mihpayid = $this->input->post('mihpayid');
        $mode = $this->input->post('mode');
        $cardCategory = $this->input->post('cardCategory');
        $net_amount_debit = $this->input->post('net_amount_debit');
        $addedon = $this->input->post('addedon');
        $amount = $this->input->post('amount');
        $txnid = $this->input->post('txnid');
        $discount = $this->input->post('discount');
        $posted_hash = $this->input->post('hash');
        $payment_source = $this->input->post('payment_source');
        $error_message = $this->input->post('error_Message');
        $key = $this->input->post('key');
        $productinfo = $this->input->post('productinfo');
        $email = $this->input->post('email');
        $salt = "eCwWELxi"; // live DMe4KJre // test eCwWELxi
        $payu_array = array('mihpayid' => $mihpayid,
            'mode' => $mode,
            'status' => $status,
            'txnid' => $txnid,
            'amount' => $amount,
            'cardCategory' => $cardCategory,
            'net_amount_debit' => $net_amount_debit,
            'addedon' => $addedon,
            'hash' => $posted_hash,
            'discount' => $discount,
            'payment_source' => $payment_source,
            'error_message' => $error_message,
            'productinfo' => $productinfo
        );
        //$payu_values = $this->Transactions_model->insertPayuValues($payu_array);
        // $customer_detail = $this->Customer_model->getCustomerDetails($customer_id);
        $orderdetail = $this->Order_model->getOrderNumber($txnid);
//        $message = 'Hello , Your order with reference to the order number ' . $txnid . ' is not processed due to a failed transaction';
//        $subject = 'Order failure';
//        $to = $customer_detail->Email;
//        $mobile_number = $customer_detail->Mobile;
//        $sms_message = 'Hello , your order with reference to ' . $txnid . ' has been cancelled due to a failed transaction.';
//        //send email
//        sendEmail($to, $subject, $message);
//        $this->load->library('sms');
//        $this->sms->send_sms($mobile_number, $sms_message);
//        $this->session->set_flashdata('update_msg', 'Payment for Order #' . $txnid . ' failed.');
        redirect('/checkout/orderdetails/' . $orderdetail->OrderId);
    }

    public function processmobikwik($customer_id, $order_id) {
        $customer_detail = $this->Customer_model->getCustomerDetails($customer_id);
        $OrderDetails = $this->Order_model->getOrderDetails($order_id, $customer_id);
        if ($OrderDetails) {
            $name = $customer_detail->Name;
            $lastname = "a";
            $email = $customer_detail->Email;
            $mobile = $customer_detail->Mobile;
            $order_no = $OrderDetails->OrderNumber;
            $final_amount = $OrderDetails->FinalAmount;
            $MERCHANT_ID = $this->config->item('mobikwik_mid');
            $return_url = base_url() . 'checkout/mobikwik_response';
            $data['MERCHANT_ID'] = $MERCHANT_ID;
            $data['name'] = $name;
            $data['lastname'] = $lastname;
            $data['email'] = $email;
            $data['address'] = '';
            $data['city'] = '';
            $data['state'] = '';
            $data['country'] = '';
            $data['pincode'] = '';
            $data['phoneno'] = $mobile;
            $data['url'] = $return_url;
            $data['txtdate'] = date("Y-m-d");
            $data['order_id'] = $order_no;
            $data['final_amount'] = $final_amount;
            $final_amount1 = $final_amount * 100;
            $idaddress = isset($_SERVER['HTTP_X_FORWARDED_FOR']) ? $_SERVER['HTTP_X_FORWARDED_FOR'] : $_SERVER['REMOTE_ADDR'];
            $all = "amount=" . $final_amount1 . "&buyerEmail=" . $email . "&buyerFirstName=" . $name . "&buyerLastName=" . $lastname . "&buyerPhoneNumber=" . $mobile . "&currency=INR&merchantIdentifier=" . $MERCHANT_ID . "&merchantIpAddress=" . $idaddress . "&mode=1&orderId=" . $order_no . "&productDescription=Patanjali Products&purpose=1&returnUrl=" . $return_url . "&txnDate=" . date("Y-m-d") . "&txnType=1&zpPayOption=1&";
            $this->load->library('Checksum');
            $BASE_URL = $this->config->item('mobikwik_url');
            $data['BASE_URL'] = $BASE_URL;
            $data['checksum'] = Checksum::calculateChecksum($this->config->item('mobikwik_key'), $all);
            $this->load->view('checkout/processmobikwik', $data);
        } else {
            echo "error";
        }
    }

    public function mobikwik_response() {
        $this->load->library('Checksum');
        $secret = $this->config->item('mobikwik_key');
        $recd_checksum = $this->input->post('checksum');
        $all = Checksum::getAllResponseParams();
        $checksum_check = Checksum::verifyChecksum($recd_checksum, $all, $secret);
        $order_no = $this->input->post('orderId');
        $orderdetail = $this->Order_model->getOrderNumber($order_no);
        $customer_id = $orderdetail->CustomerId;
        $customer_detail = $this->Customer_model->getCustomerDetails($customer_id);
        $order_id = $orderdetail->OrderId;
        if ($this->input->post('responseCode') == 100 and $checksum_check == 1 and $this->input->post('amount') == ($orderdetail->FinalAmount * 100)) {
            $this->confirmOrder($orderdetail->OrderId, $customer_id);
            // @TO-DO : Send email to user for payment recieved for order submitted
//            $message = '';
//            $subject = 'Order Confirmation - Your Order with "patanjaliayurved.net" ' . $order_no . ' has been successfully placed!';
//            $to = $customer_detail->Email;
//            $mobile_number = $customer_detail->Mobile;
//            // $sms_message = "Your order has been placed successfully..Your order number is" . $order_no;
//            $sms_message = 'Your order at patanjali has been placed successfully . Your order number is ' . $order_no . '. and order amount is ' . $order_detail->final_amount . '. Thank you for choosing patanjali.';
//            //send email
//            $custom = array('type' => 'order', 'details' => array('name' => $customer_detail->Name, 'orderno' => $order_no, 'order_detail' => $order_detail, 'fullorderdetails' => $fullorderdetails));
//            sendEmail($to, $subject, $message, $custom);
//            $this->sms->send_sms($mobile_number, $sms_message);
//            // @TO-DO : Send email to admin for payment recieved for order submitted
//            // @TO-DO : Update order table and deduct the quantity for inventory
//            $this->session->set_flashdata('update_msg', 'Order #' . $order_no . ' placed successfully.');
//            $this->Transactions_model->insertmobikwikValues($this->input->post);
//            $this->session->set_userdata('torder_id', $order_id);
            redirect('/checkout/thankyou');
        } else {
//            $message = 'Hello , Your order with reference to the order number ' . $order_no . ' is not processed due to a failed transaction';
//            $subject = 'Order failure';
//            $to = $customer_detail->Email;
//            $mobile_number = $customer_detail->Mobile;
//            $sms_message = 'Hello , your order with reference to ' . $order_no . ' has been cancelled due to a failed transaction.';
//            //send email
//            sendEmail($to, $subject, $message);
//            $this->load->library('sms');
//            $this->sms->send_sms($mobile_number, $sms_message);
//            $this->session->set_flashdata('update_msg', 'Payment for Order #' . $order_no . ' failed.');
//            $this->Transactions_model->insertmobikwikValues($this->input->post);
            redirect('/checkout/orderdetails/' . $order_id);
        }
    }

    public function processphonepe($customer_id, $order_id) {
        $customer_detail = $this->Customer_model->getCustomerDetails($customer_id);
        $OrderDetails = $this->Order_model->getOrderDetails($order_id, $customer_id);
        if ($OrderDetails) {
            $final_amount = $OrderDetails->FinalAmount;
            $final_amount = 100 * $final_amount;
            $url = $this->config->item('phonepe_url');
            $merchantId = $this->config->item('phonepe_merchantId');
            $salt_key = $this->config->item('phonepe_salt_key');
            $salt_index = $this->config->item('phonepe_salt_index');
            $orderid = $OrderDetails->OrderNumber;
            $pay = '{
   "merchantId": "' . $merchantId . '", 
   "transactionId": "' . $orderid . '",
   "merchantUserId": "' . $customer_detail->CustomerId . '",
   "amount": ' . $final_amount . ',
   "merchantOrderId": "' . $orderid . '",
   "mobileNumber": "' . $customer_detail->Mobile . '",
   "message": "Payment for order placed for the order no ' . $orderid . '",
   "email": "' . $customer_detail->Email . '",
   "shortName": "' . $customer_detail->Name . '"
}';
            $payload = base64_encode($pay);
            $verify = hash('sha256', $payload . "/v3/debit" . $salt_key) . "###" . $salt_index;
//echo "</br>";
            $curl = curl_init();
            curl_setopt_array($curl, array(
                CURLOPT_URL => $url . "/debit",
                CURLOPT_TIMEOUT => 30,
                CURLOPT_CUSTOMREQUEST => "POST",
                CURLOPT_SSL_VERIFYPEER => false,
                CURLOPT_FOLLOWLOCATION => false,
                CURLOPT_RETURNTRANSFER => TRUE,
                CURLOPT_POSTFIELDS => "{\"request\":\"" . $payload . "\"}",
                CURLOPT_HTTPHEADER => array(
                    "Content-Type: application/json",
                    "X-REDIRECT-URL: " . base_url() . "checkout/phonepe_ui_callback_response/",
                    "X-REDIRECT-MODE: POST",
                    "X-CALLBACK-URL: " . base_url() . "checkout/phonepe_s2s_callback_response",
                    "X-CALL-MODE: POST",
                    "x-verify: " . $verify
                ),
            ));
            $response = json_decode(curl_exec($curl));
            $err = curl_error($curl);
            $info = curl_getinfo($curl);
            curl_close($curl);
//echo "{\"request\":\"".$payload."\"}";
//echo "</br>";
//echo $url."/debit";
//echo "</br>";
//print_r($info);
//die;
            if ($info['redirect_url']) {
                header("location:" . $info['redirect_url']);
            } else {
                redirect('/checkout/orderdetails/' . $order_id);
            }
        } else {
            echo "error";
        }
    }

    public function phonepe_ui_callback_response() {
        // $merchantId= $this->config->item('phonepe_merchantId');
        // print_r($_POST);die;
        $salt_key = $this->config->item('phonepe_salt_key');
        $salt_index = $this->config->item('phonepe_salt_index');
        $code = $_POST['code'];
        $merchantId = $_POST['merchantId'];
        $amount = $_POST['amount'];
        $providerReferenceId = $_POST['providerReferenceId'];
        $txnid = $_POST['transactionId'];
        $checksum = $_POST['checksum'];
        $orderdetail = $this->Order_model->getOrderNumber($txnid);
        if ($orderdetail) {
            $customer_id = $orderdetail->CustomerId;
//$customer_detail = $this->Customer_model->getCustomerDetails($user_id);	
//$customer_cart = $this->Cart_model->getCustomerCart($user_id);        
//$cart_id = $customer_cart->id;
            $newchecksum = hash('sha256', $code . $merchantId . $txnid . $amount . $providerReferenceId . $_POST['param1'] . $_POST['param2'] . $_POST['param3'] . $_POST['param4'] . $_POST['param5'] . $_POST['param6'] . $_POST['param7'] . $_POST['param8'] . $_POST['param9'] . $_POST['param10'] . $_POST['param11'] . $_POST['param12'] . $_POST['param13'] . $_POST['param14'] . $_POST['param15'] . $_POST['param16'] . $_POST['param17'] . $_POST['param18'] . $_POST['param19'] . $_POST['param20'] . $salt_key) . "###" . $salt_index;
            if ($code == "PAYMENT_SUCCESS" and $checksum == $newchecksum) {
                $phonepe_array = array(
                    'code' => $code,
                    'transactionId' => $txnid,
                    'merchantId' => $merchantId,
                    'providerReferenceId' => $providerReferenceId,
                    'amount' => $amount / 100,
                    'response' => json_encode($_POST)
                );
                //$payu_values = $this->Transactions_model->insertPhonePeValues($phonepe_array);
                $finalamount = $amount / 100;
                if ($orderdetail->FinalAmount == $finalamount) {
                    $this->confirmOrder($orderdetail->OrderId, $customer_id);
//            $message = '';
//            $subject = 'Order Confirmation - Your Order with "patanjaliayurved.net" ' . $txnid . ' has been successfully placed!';
//            $to = $customer_detail->email;
//            $mobile_number = $customer_detail->mobile;
//            // $sms_message = 'Hello Mr/Mrs/Ms' . $customer_detail->firstname . ' ,this is a confirmation message from patanjaliayurved.net.Your order has been placed successfully.Order No : ' . $txnid;
//            $sms_message = 'Your order at patanjali has been placed successfully . Your order number is ' . $txnid . '. and order amount is ' . $amount . '. Thank you for choosing patanjali.';
//            //send email
//            $custom = array('type' => 'order', 'details' => array('name' => $customer_detail->firstname, 'orderno' => $txnid, 'order_detail' => $order_detail, 'fullorderdetails' => $fullorderdetails));
//            sendEmail($to, $subject, $message, $custom);
//            $this->sms->send_sms($mobile_number, $sms_message);
//            $this->session->set_userdata('torder_id', $OrderDetails->OrderId); 
//            $this->session->set_flashdata('update_msg', 'Order has been placed successfully');
                    redirect('/checkout/thankyou');
                } else {
                    // cancel order         
//            $message = 'Hello , Your order with reference to the order number ' . $txnid . ' is not processed due to a failed transaction';
//            $subject = 'Order failure';
//            $to = $customer_detail->email;
//            $mobile_number = $customer_detail->mobile;
//            $sms_message = 'Hello , your order with reference to ' . $txnid . ' has been cancelled due to a failed transaction.';
//            //send email
//            sendEmail($to, $subject, $message);
//            $this->load->library('sms');
//            $this->sms->send_sms($mobile_number, $sms_message);
//            $dataarray = array('is_pending' => 0);
//            $updateorder = $this->Orders_model->updateorder($OrderDetails->OrderId, $dataarray);     
//            $this->session->set_flashdata('update_msg', 'Payment for Order #' . $txnid . ' failed.');
                    redirect('/checkout/orderdetails/' . $OrderDetails->OrderId);
                }
            } else {
                if ($code == "PAYMENT_PENDING") {
                    $phonepe_array = array(
                        'code' => $code,
                        'response' => json_encode($_POST)
                    );
                    // $payu_values = $this->Transactions_model->insertPhonePeValues($phonepe_array);     
//            $this->Cart_model->removeCart($cart_id, $user_id);
//            $this->cart->destroy();
//            $dataarray = array('is_pending' => 1);
//            $updateorder = $this->Order_model->updateorder($OrderDetails->OrderId, $dataarray);
//            $this->session->set_flashdata('update_msg', 'Payment for Order #' . $txnid . ' is being processed.');
                    redirect('/checkout/orderdetails/' . $OrderDetails->OrderId);
                } else {
                    $phonepe_array = array(
                        'code' => $code,
                        'transactionId' => $txnid,
                        'merchantId' => $merchantId,
                        'providerReferenceId' => $providerReferenceId,
                        'amount' => $amount / 100,
                        'response' => json_encode($_POST)
                    );
                    //$payu_values = $this->Transactions_model->insertPhonePeValues($phonepe_array);
                    // cancel order            
//            $message = 'Hello , Your order with reference to the order number ' . $txnid . ' is not processed due to a failed transaction';
//            $subject = 'Order failure';
//            $to = $customer_detail->email;
//            $mobile_number = $customer_detail->mobile;
//            $sms_message = 'Hello , your order with reference to ' . $txnid . ' has been cancelled due to a failed transaction.';
//            //send email
//            sendEmail($to, $subject, $message);
//            $this->load->library('sms');
//            $this->sms->send_sms($mobile_number, $sms_message);
//             $dataarray = array('is_pending' => 0);
//            $updateorder = $this->Orders_model->updateorder($OrderDetails->OrderId, $dataarray);      
//            $this->session->set_flashdata('update_msg', 'Payment for Order #' . $txnid . ' failed.');
                    redirect('/checkout/orderdetails/' . $OrderDetails->OrderId);
                }
            }
        } else {
            $phonepe_array = array(
                'response' => json_encode($_POST)
            );
            //$payu_values = $this->Transactions_model->insertPhonePeValues($phonepe_array);
            redirect('home');
        }
    }

    public function phonepe_s2s_callback_response() {
        // print_r($_SERVER['HTTP_X_VERIFY']);
        $response = json_decode(file_get_contents('php://input'), true);
        $salt_key = $this->config->item('phonepe_salt_key');
        $salt_index = $this->config->item('phonepe_salt_index');
//echo $_SERVER['HTTP_X_VERIFY'];
//echo "<br>";
        $checksumverify = hash('sha256', $response["response"] . $salt_key) . "###" . $salt_index;
//
//die;
        $response = json_decode(base64_decode($response["response"]));
        if ($response->success == 1) {
            $txnid = $response->data->transactionId;
            $orderdetail = $this->Order_model->getOrderNumber($txnid);
            $customer_id = $orderdetail->CustomerId;
            if ($orderdetail->is_pending == 1) {
                if ($response->code == "PAYMENT_SUCCESS") {
                    //print_r($response); die;
                    if ($orderdetail->FinalAmount == $response->data->amount / 100 and $checksumverify == $_SERVER['HTTP_X_VERIFY']) {
                        $phonepe_array = array('success' => $response->success,
                            'code' => $response->code,
                            'message' => $response->message,
                            'transactionId' => $response->data->transactionId,
                            'merchantId' => $response->data->merchantId,
                            'providerReferenceId' => $response->data->providerReferenceId,
                            'amount' => $response->data->amount / 100,
                            'paymentState' => $response->data->paymentState,
                            //'payResponseCode' => $response->data->payResponseCode,
                            //'paymentModes_mode' => $response->data->paymentModes['0']->mode,
                            //'paymentModes_amount' => $response->data->paymentModes['0']->amount/100,
                            //'transactionContext' => $response->data->transactionContext,
                            'response' => json_encode($response)
                        );
                        // $payu_values = $this->Transactions_model->insertPhonePeValues($phonepe_array);            
                        //$customer_detail = $this->Customer_model->getCustomerDetails($customer_id);			    
                        $this->confirmOrder($orderdetail->OrderId, $customer_id);
//            $message = '';
//            $subject = 'Order Confirmation - Your Order with "patanjaliayurved.net" ' . $txnid . ' has been successfully placed!';
//            $to = $customer_detail->email;
//            $mobile_number = $customer_detail->mobile;
//            // $sms_message = 'Hello Mr/Mrs/Ms' . $customer_detail->firstname . ' ,this is a confirmation message from patanjaliayurved.net.Your order has been placed successfully.Order No : ' . $txnid;
//            $sms_message = 'Your order at patanjali has been placed successfully . Your order number is ' . $txnid . '. and order amount is ' . $amount . '. Thank you for choosing patanjali.';
//            //send email
//            $custom = array('type' => 'order', 'details' => array('name' => $customer_detail->firstname, 'orderno' => $txnid, 'order_detail' => $order_detail, 'fullorderdetails' => $fullorderdetails));
//            sendEmail($to, $subject, $message, $custom);
//            $this->sms->send_sms($mobile_number, $sms_message);
//            $this->session->set_userdata('torder_id', $OrderDetails->OrderId);
//            $this->session->set_flashdata('update_msg', 'Order has been placed successfully');
                        redirect('/checkout/thankyou');
                    } else {
                        redirect('/checkout/orderdetails/' . $orderdetail->OrderId);  
                    }
                } else {
                    if ($response->code == "PAYMENT_PENDING") {
                        $phonepe_array = array('success' => $response->success,
                            'code' => $response->code,
                            'message' => $response->message,
                            'response' => json_encode($response)
                        );
                        //  $payu_values = $this->Transactions_model->insertPhonePeValues($phonepe_array);            
                        // $customer_detail = $this->Customer_model->getCustomerDetails($user_id);
                        $orderdetail = $this->Orders_model->getOrderNumber($txnid);
                        // $dataarray = array('is_pending' => 1);
                        // $updateorder = $this->Orders_model->updateorder($OrderDetails->OrderId, $dataarray);
                        // $this->session->set_flashdata('update_msg', 'Payment for Order #' . $txnid . ' is being processed.');
                        redirect('/checkout/orderdetails/' . $orderdetail->OrderId);
                    } else {
                        $phonepe_array = array('success' => $response->success,
                            'code' => $response->code,
                            'message' => $response->message,
                            'transactionId' => $response->data->transactionId,
                            'merchantId' => $response->data->merchantId,
                            'providerReferenceId' => $response->data->providerReferenceId,
                            'amount' => $response->data->amount / 100,
                            'paymentState' => $response->data->paymentState,
                            'response' => json_encode($response)
                        );
                        //$payu_values = $this->Transactions_model->insertPhonePeValues($phonepe_array);
                        // cancel order
                        //$customer_detail = $this->Customer_model->getCustomerDetails($user_id);
                        $orderdetail = $this->Orders_model->getOrderNumber($txnid);
//            $this->Customer_model->cancelOrder($orderdetail->OrderId, $txnid, 0, 0);
//            $message = 'Hello , Your order with reference to the order number ' . $txnid . ' is not processed due to a failed transaction';
//            $subject = 'Order failure';
//            $to = $customer_detail->email;
//            $mobile_number = $customer_detail->mobile;
//            $sms_message = 'Hello , your order with reference to ' . $txnid . ' has been cancelled due to a failed transaction.';
//            //send email
//            sendEmail($to, $subject, $message);
//            $this->load->library('sms');
//            $this->sms->send_sms($mobile_number, $sms_message);
//             $dataarray = array('is_pending' => 0);
//            $updateorder = $this->Order_model->updateorder($orderdetail->OrderId, $dataarray);
//            $this->session->set_flashdata('update_msg', 'Payment for Order #' . $txnid . ' failed.');
                        redirect('/checkout/orderdetails/' . $orderdetail->OrderId);
                    }
                }
            }
        } else {
            $txnid = $response->data->transactionId;
            $orderdetail = $this->Orders_model->getOrderNumber($txnid);
            $order_detail = $this->Orders_model->getOrderDetails($orderdetail->OrderId);
            $user_id = $order_detail->user_id;
            $phonepe_array = array('success' => $response->success,
                'code' => $response->code,
                'message' => $response->message,
                'response' => json_encode($response)
            );
            // $payu_values = $this->Transactions_model->insertPhonePeValues($phonepe_array);
            // cancel order
//            $customer_detail = $this->Customer_model->getCustomerDetails($user_id);
//            $this->Customer_model->cancelOrder($orderdetail->OrderId, $txnid, 0, 0);
//            $message = 'Hello , Your order with reference to the order number ' . $txnid . ' is not processed due to a failed transaction';
//            $subject = 'Order failure';
//            $to = $customer_detail->email;
//            $mobile_number = $customer_detail->mobile;
//            $sms_message = 'Hello , your order with reference to ' . $txnid . ' has been cancelled due to a failed transaction.';
//            //send email
//            sendEmail($to, $subject, $message);
//            $this->load->library('sms');
//            $this->sms->send_sms($mobile_number, $sms_message);
//            $dataarray = array('is_pending' => 0);
//            $updateorder = $this->Orders_model->updateorder($orderdetail->OrderId, $dataarray);
//            $this->session->set_flashdata('update_msg', 'Payment for Order #' . $txnid . ' failed.');
            redirect('/checkout/orderdetails/' . $orderdetail->OrderId);
        }
        die;
    }

    public function process_ssc($customer_id, $order_id) {
        $customer_detail = $this->Customer_model->getCustomerDetails($customer_id);
        $OrderDetails = $this->Order_model->getOrderDetails($order_id, $customer_id);
        if ($OrderDetails) {
            $this->load->view('checkout/ssc_payment');
        } else {
            echo "error";
        }
    }

    public function processrazorpay($customer_id, $order_id) {
        $customer_detail = $this->Customer_model->getCustomerDetails($customer_id);
        $OrderDetails = $this->Order_model->getOrderDetails($order_id, $customer_id);
        if ($OrderDetails) {
            //echo $payment_mode;
            $final_amount = $OrderDetails->FinalAmount * 100;
            $keyId = $this->config->item('razorpay_keyId');
            $keySecret = $this->config->item('razorpay_keySecret');
            $displayCurrency = 'INR';
            $api = new Api($keyId, $keySecret);
            $orderData = [
                'receipt' => $OrderDetails->OrderNumber,
                'amount' => $final_amount, // 2000 rupees in paise
                'currency' => 'INR',
                'payment_capture' => 1 // auto capture
            ];
            $razorpayOrder = $api->order->create($orderData);
            $razorpayOrderId = $razorpayOrder['id'];
            // $_SESSION['razorpay_order_id'] = $razorpayOrderId;
            $displayAmount = $amount = $orderData['amount'];
            if ($displayCurrency !== 'INR') {
                $url = "https://api.fixer.io/latest?symbols=$displayCurrency&base=INR";
                $exchange = json_decode(file_get_contents($url), true);
                $displayAmount = $exchange['rates'][$displayCurrency] * $amount / 100;
            }
            $data = [
                "key" => $keyId,
                "amount" => $amount,
                "name" => "Patanjali Ayurved",
                "description" => "",
                "image" => "https://www.patanjaliayurved.net/assets/img/logo-big.png",
                "prefill" => [
                    "name" => $customer_detail->Name,
                    "email" => $customer_detail->Email,
                    "contact" => $customer_detail->Mobile,
                ],
                "notes" => [
                    "address" => "",
                    "merchant_order_id" => "",
                ],
                "theme" => [
                    "color" => "#F37254"
                ],
                "order_id" => $razorpayOrderId,
            ];
            if ($displayCurrency !== 'INR') {
                $data['display_currency'] = $displayCurrency;
                $data['display_amount'] = $displayAmount;
            }
            $data1['json'] = json_encode($data);
            $data1['order_no'] = $OrderDetails->OrderNumber;
            $data1['order_id'] = $OrderDetails->OrderId;
            $RazorpayValues = array('order_no' => $OrderDetails->OrderNumber,
                'razorpay_order_id' => $razorpayOrderId
            );
            //$this->Transactions_model->insertRazorpayValues($RazorpayValues);
            $this->load->view('checkout/processrazorpay', $data1);
        } else {
            echo "error";
        }
    }

    public function razorpay_response() {
        $keyId = $this->config->item('razorpay_keyId');
        $keySecret = $this->config->item('razorpay_keySecret');
        $displayCurrency = 'INR';
        //print_r($_POST);
        $order_no = $_POST['order_no'];
        $orderdetail = $this->Order_model->getOrderNumber($order_no);
        if ($orderdetail) {
            $customer_id = $orderdetail->CustomerId;
            // $customer_detail = $this->Customer_model->getCustomerDetails($customer_id);
            $order_id = $orderdetail->OrderId;
            $success = false;
            $error = "Payment Failed";
            if (empty($_POST['razorpay_payment_id']) === false) {
                $api = new Api($keyId, $keySecret);
                try {
                    // Please note that the razorpay order ID must
                    // come from a trusted source (session here, but
                    // could be database or something else)
                    $attributes = array(
                        'razorpay_order_id' => $_POST['razorpay_order_id'],
                        'razorpay_payment_id' => $_POST['razorpay_payment_id'],
                        'razorpay_signature' => $_POST['razorpay_signature']
                    );
                    $success = true;
                    $api->utility->verifyPaymentSignature($attributes);
                } catch (SignatureVerificationError $e) {
                    $success = false;
                    $error = 'Razorpay Error : ' . $e->getMessage();
                }
            }
//print_r($_POST);
            if ($success === true) {
                //$html = "<p>Your payment was successful</p>
                //    <p>Payment ID: {$_POST['razorpay_payment_id']}</p>";
                $this->confirmOrder($orderdetail->OrderId, $customer_id);
//                $message = '';
//                $subject = 'Order Confirmation - Your Order with "patanjaliayurved.net" ' . $order_no . ' has been successfully placed!';
//                $to = $customer_detail->email;
//                $mobile_number = $customer_detail->mobile;
//                // $sms_message = "Your order has been placed successfully..Your order number is" . $order_no;
//                $sms_message = 'Your order at patanjali has been placed successfully . Your order number is ' . $order_no . '. and order amount is ' . $order_detail->final_amount . '. Thank you for choosing patanjali.';
//                //send email
//                $custom = array('type' => 'order', 'details' => array('name' => $customer_detail->firstname, 'orderno' => $order_no, 'order_detail' => $order_detail, 'fullorderdetails' => $fullorderdetails));
//                sendEmail($to, $subject, $message, $custom);
//
//                $this->sms->send_sms($mobile_number, $sms_message);
//                // @TO-DO : Send email to admin for payment recieved for order submitted
//                // @TO-DO : Update order table and deduct the quantity for inventory
//                $this->session->set_flashdata('update_msg', 'Order #' . $order_no . ' placed successfully.');
//                $_POST['status']='success';
//                $this->Transactions_model->insertRazorpayValues($_POST);
//                $this->session->set_userdata('torder_id', $order_id);
                redirect('/checkout/thankyou');
            } else {
                // $html = "<p>Your payment failed</p>
                //          <p>{$error}</p>";
//                //$message = 'Dear Sir/Madam,' . '<br>' . 'Your order#' . $order_no . ' was not processed because of failed transaction';
//                $message = 'Hello , Your order with reference to the order number ' . $order_no . ' is not processed due to a failed transaction';
//                $subject = 'Order failure';
//                $to = $customer_detail->email;
//                $mobile_number = $customer_detail->mobile;
//                $sms_message = 'Hello , your order with reference to ' . $order_no . ' has been cancelled due to a failed transaction.';
//                //send email
//                sendEmail($to, $subject, $message);
//                $this->load->library('sms');
//                $this->sms->send_sms($mobile_number, $sms_message);
//                $this->session->set_flashdata('update_msg', 'Payment for Order #' . $order_no . ' failed.');
//                $_POST['status']='failed';
//                $this->Transactions_model->insertRazorpayValues($_POST);
                redirect('/checkout/orderdetails/' . $order_id);
            }
        } else {
            redirect('/home');
        }
    }

    public function orderdetails($order_id) {
        echo "Payment Failed";
    }

    public function thankyou() {
        echo "Thank You";
    }

}

?>
