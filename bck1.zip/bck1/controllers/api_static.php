<?php

defined('BASEPATH') OR exit('No direct script access allowed');
// This can be removed if you use __autoload() in config.php OR use Modular Extensions
require APPPATH . '/libraries/REST_Controller.php';

/**
 * This is an example of a few basic user interaction methods you could use
 * all done with a hardcoded array
 *
 * @package         CodeIgniter
 * @subpackage      Rest Server
 * @category        Controller
 * @author          Phil Sturgeon, Chris Kacerguis
 * @license         MIT
 * @link            https://github.com/chriskacerguis/codeigniter-restserver
 */
class Api extends REST_Controller {

    function __construct() {
        parent::__construct();
        //$this->load->model('App_model');
    }

    public function index_get() {
        echo "test";
    }

    public function getAppSettings_post() {
        //$appsettings = $this->App_model->appSettings();
        $appsettings = array(
            "id" => 1,
            "version" => 1,
            "message" => "App has been started",
            "status" => 1
        );
        $response = array('status' => 1, 'data' => $appsettings);
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function register_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $mobile = $data['mobile'];
        $userarray = array();
        array_push($userarray, array('customer_id' => 1));
        $response = array('status' => 1, 'data' => $userarray, 'message' => 'OTP sent to registered number.');

        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function resendOtp_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $mobile = $data['mobile'];
        $userarray = array();
        array_push($userarray, array('customer_id' => 1));
        $response = array('status' => 1, 'data' => $userarray, 'message' => 'OTP sent to registered number.');
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function verifyOtp_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $mobile = $data['mobile'];
        $otp = $data['otp'];
        $customer_id = $data['customer_id'];
        $userarray = array();
        array_push($userarray, array('customer_id' => 1));
        $response = array('status' => 1, 'message' => 'You are registered successfully.');
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function login_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $userarray = array();
        $mobile = $data['mobile'];
        $password = $data['password'];
        $token = '9UAacXGYyG2wIkEeVaXTBFyQqOhfdWK2';
        array_push($userarray, array('customer_id' => 1, 'name' => "Shoaib Qureshi", 'email' => "shoaib.satisfaction@gmail.com", 'mobile' => "9174000321", "gender" => "Male", "profile_image"=> "http://oseemo.com/patanjaliapi/assets/uploads/profile/profile.png", 'token' => $token));
        $response = array('status' => 1, 'data' => $userarray, "message" => "You have successfully logged in.");
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function forgotPassword_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $mobile = $data['mobile'];
        $userarray = array();
        array_push($userarray, array('customer_id' => 1));
        $response = array('status' => 1, 'data' => $userarray, 'message' => 'OTP sent to registered number.');
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function forgotPasswordVerifyOtp_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $mobile = $data['mobile'];
        $otp = $data['otp'];
        $customer_id = $data['customer_id'];
        $userarray = array();
        $token = '9UAacXGYyG2wIkEeVaXTBFyQqOhfdWK2';
        array_push($userarray, array('customer_id' => 1,"token"=>$token));
        $response = array('status' => 1, 'data' => $userarray);
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function resetPassword_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $customer_id = $data['customer_id'];
        $token = $data['token'];
        $password = $data['password'];
        $response = array('status' => 1, 'message' => 'Password reset successfully.');
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function changePassword_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $customer_id = $data['customer_id'];
        $token = $data['token'];
        $password = $data['password'];
        $current_password = $data['current_password'];
        $response = array('status' => 1, 'message' => 'Your password has been changed successfully.');
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function checkMobile_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $mobile = $data['mobile'];
        // if ($mobile != "9876543210") {
            // $response = array('status' => 1);
        // } else {
            $response = array('status' => 0, 'message' => 'Mobile No. already exists');
        //}
        $this->response($response, REST_Controller::HTTP_OK);
    }
    public function checkEmail_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $email = $data['email'];
        // if ($email != "a@gmail.com") {
            // $response = array('status' => 1);
        // } else {
            $response = array('status' => 0, 'message' => 'Email address already exists');
        // }
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function editProfile_post() {
        $data = $_POST; //json_decode(file_get_contents('php://input'), true);
        $customerdetailarray = array();
        $customer_id = $data['customer_id'];
        $token = $data['token'];
        $name = $data['name'];
        $mobile = $data['mobile'];
        $alternatemobile = $data['alternatemobile'];
        $gender = $data['gender'];
        $email = $data['email'];
        $profile_image = $data['profile_image'];
        array_push($customerdetailarray, array('customer_id' => $customer_id, 'name' => $name, 'email' => $email, 'mobile' => $mobile, 'alternatemobile' => $alternatemobile, "gender" => $gender,"profile_image"=> "http://oseemo.com/patanjaliapi/assets/uploads/profile/profile.png"));
        $response = array('status' => 1, 'data' => $customerdetailarray, "message" => "Profile updated successfully");
        $this->response($response, REST_Controller::HTTP_OK);
    }
	public function getCustomerDetail_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $customerdetailarray = array();
        $customer_id = $data['customer_id'];
        $token = $data['token'];
        array_push($customerdetailarray, array('customer_id' => 1, 'name' => "Shoaib Qureshi", 'email' => "shoaib.satisfaction@gmail.com", 'mobile' => "9174000321", 'alternatemobile' => "9090808070", "gender" => "Male", "profile_image" => "http://oseemo.com/patanjaliapi/assets/uploads/profile/profile.png"));
        $response = array('status' => 1, 'data' => $customerdetailarray);
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function searchProducts_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $id = $data['searchkey'];
        $productlist = json_decode('[
        {
            "product_id": 924,
            "product_name": "COWS GHEE 5 LTR"           
        },
        {
            "product_id": 962,
            "product_name": "COWS GHEE 200 ML"
        },
        {
            "product_id": 807,
            "product_name": "DESI GHEE"
        },
        {
            "product_id": 806,
            "product_name": "DESI GHEE 1 LTR"
        }
    ]
');
        $response = array('status' => 1, 'data' => $productlist);
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function categoryList_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $id = $data['category_id'];
        if (!$id) {
            $id = 0;
        }
        $categorylist = json_decode('[
        {
            "category_id": 1,
            "category_name": "Natural Health Care",
            "description": "Health & Nutrition Patanjali offers wide range of health care products to take care of your health prepared from naturally grown organic fruits and vegetables. We produce variety of juices, jam and sharbat from Aloe Vera, Amla, Guava, Harad, Murabba, Karela, Khus, Lemon, Litchi, Mango and Mixed Fruits. These products are hygienically made with finest of machines and brains to provide you excellent products.",
            "parent_id": 0,
            "category_image": "http://oseemo.com/patanjaliapi/assets/uploads/category_image/banner.jpg",
            "app_icon": "http://oseemo.com/patanjaliapi/assets/uploads/app_icon/ayurvedic_medicine.png",
            "sub_category": [
                {
                    "category_id": 138,
                    "category_name": "Digestives",
                    "description": "",
                    "parent_id": 1,
                    "category_image": "http://oseemo.com/patanjaliapi/assets/uploads/category_image/banner.jpg",
                    "app_icon": "http://oseemo.com/patanjaliapi/assets/uploads/app_icon/ayurvedic_medicine.png",
                    "sub_category": []
                },
                {
                    "category_id": 139,
                    "category_name": "Health and Wellness",
                    "description": "",
                    "parent_id": 1,
                    "category_image": "http://oseemo.com/patanjaliapi/assets/uploads/category_image/banner.jpg",
                    "app_icon": "http://oseemo.com/patanjaliapi/assets/uploads/app_icon/ayurvedic_medicine.png",
                    "sub_category": []
                },
                {
                    "category_id": 150,
                    "category_name": "Chyawanprash",
                    "description": "",
                    "parent_id": 1,
                    "category_image": "http://oseemo.com/patanjaliapi/assets/uploads/category_image/banner.jpg",
                    "app_icon": "http://oseemo.com/patanjaliapi/assets/uploads/app_icon/ayurvedic_medicine.png",
                    "sub_category": []
                },
                {
                    "category_id": 151,
                    "category_name": "Badam pak",
                    "description": "",
                    "parent_id": 1,
                    "category_image": "http://oseemo.com/patanjaliapi/assets/uploads/category_image/banner.jpg",
                    "app_icon": "http://oseemo.com/patanjaliapi/assets/uploads/app_icon/ayurvedic_medicine.png",
                    "sub_category": []
                },
                {
                    "category_id": 152,
                    "category_name": "Ghee",
                    "description": "",
                    "parent_id": 1,
                    "category_image": "http://oseemo.com/patanjaliapi/assets/uploads/category_image/banner.jpg",
                    "app_icon": "http://oseemo.com/patanjaliapi/assets/uploads/app_icon/ayurvedic_medicine.png",
                    "sub_category": []
                },
                {
                    "category_id": 153,
                    "category_name": "Honey",
                    "description": "",
                    "parent_id": 1,
                    "category_image": "http://oseemo.com/patanjaliapi/assets/uploads/category_image/banner.jpg",
                    "app_icon": "http://oseemo.com/patanjaliapi/assets/uploads/app_icon/ayurvedic_medicine.png",
                    "sub_category": []
                },
                {
                    "category_id": 177,
                    "category_name": "Health drinks",
                    "description": "",
                    "parent_id": 1,
                    "category_image": "http://oseemo.com/patanjaliapi/assets/uploads/category_image/banner.jpg",
                    "app_icon": "http://oseemo.com/patanjaliapi/assets/uploads/app_icon/ayurvedic_medicine.png",
                    "sub_category": []
                },
                {
                    "category_id": 184,
                    "category_name": "Fruit Juice",
                    "description": "",
                    "parent_id": 1,
                    "category_image": "http://oseemo.com/patanjaliapi/assets/uploads/category_image/banner.jpg",
                    "app_icon": "http://oseemo.com/patanjaliapi/assets/uploads/app_icon/ayurvedic_medicine.png",
                    "sub_category": []
                }
            ]
        },        
        {
            "category_id": 6,
            "category_name": "Herbal Home Care",
            "description": "Care Redefined We bring our best of Herbal Home Care Collection comprising of variety of Incense Sticks of different types like Jasmine, Vangandha, Amber, Sandal etc, to spread the fragrance at your home. Best quality Detergents in Popular, Premium and Superior quality which not only take care of your clothes but your hands too. Dental care products to protect your teeth and gums. Wide variety of products like Shishu Body care, Lotion, Gel, Hair oil, massage oil etc. to take care of your little ones.",
            "parent_id": 0,
            "category_image": "http://oseemo.com/patanjaliapi/assets/uploads/category_image/banner.jpg",
            "app_icon": "http://oseemo.com/patanjaliapi/assets/uploads/app_icon/ayurvedic_medicine.png",
            "sub_category": [
                {
                    "category_id": 7,
                    "category_name": "Agarbatti",
                    "description": "",
                    "parent_id": 6,
                    "category_image": "http://oseemo.com/patanjaliapi/assets/uploads/category_image/banner.jpg",
                    "app_icon": "http://oseemo.com/patanjaliapi/assets/uploads/app_icon/ayurvedic_medicine.png",
                    "sub_category": []
                },
                {
                    "category_id": 136,
                    "category_name": "Dish Wash bar",
                    "description": "",
                    "parent_id": 6,
                    "category_image": "http://oseemo.com/patanjaliapi/assets/uploads/category_image/banner.jpg",
                    "app_icon": "http://oseemo.com/patanjaliapi/assets/uploads/app_icon/ayurvedic_medicine.png",
                    "sub_category": []
                },
                {
                    "category_id": 182,
                    "category_name": "Herbal Gulal",
                    "description": "",
                    "parent_id": 6,
                    "category_image": "http://oseemo.com/patanjaliapi/assets/uploads/category_image/banner.jpg",
                    "app_icon": "http://oseemo.com/patanjaliapi/assets/uploads/app_icon/ayurvedic_medicine.png",
                    "sub_category": []
                },
                {
                    "category_id": 200,
                    "category_name": "Hawan Samagri",
                    "description": "",
                    "parent_id": 6,
                    "category_image": "http://oseemo.com/patanjaliapi/assets/uploads/category_image/banner.jpg",
                    "app_icon": "http://oseemo.com/patanjaliapi/assets/uploads/app_icon/ayurvedic_medicine.png",
                    "sub_category": []
                }
            ]
        }        
    ]');
        $response = array('status' => 1, 'data' => $categorylist);
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function getHomeSlider_post() {
        $sliderarray = json_decode('[
        {
            "id": 1,
            "image": "http://oseemo.com/patanjaliapi/assets/uploads/home_slider/001.jpg"
        },
        {
            "id": 2,
            "image": "http://oseemo.com/patanjaliapi/assets/uploads/home_slider/002.jpg"
        },
        {
            "id": 3,
            "image": "http://oseemo.com/patanjaliapi/assets/uploads/home_slider/003.jpg"
        }
    ]');
        $response = array("status" => 1, "data" => $sliderarray, "message" => "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.");
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function getHomeProducts_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $homeproducts = array();
        $customer_id = $data['customer_id'];
        $pro = json_decode('[
        {
            "product_id": 958,
            "product_name": "ROASTED DIET-QUINOA PUFF -TOMATO FLAV 80 GM",
            "product_image": "https://www.patanjaliayurved.net/assets/product_images/400x500/1514268807PatanjaliQuinoaPuffTomatoFlavour400x500.png",
            "product_price": 75,
            "product_offer": "",
            "product_mrp": 0,
            "weight": 80,
            "unit": "gms",
            "available_qty": 458,
	    "in_wishlist":1
        },
        {
            "product_id": 887,
            "product_name": "AASTHA CONE DHOOP (SANDAL)",
            "product_image": "https://www.patanjaliayurved.net/assets/product_images/400x500/Aastha%20Dhoop%20Sandal-400x500.png",
            "product_price": 15,
            "product_offer": "",
            "product_mrp": 0,
            "weight": 33,
            "unit": "GM",
            "available_qty": 423,
            "in_wishlist":1
        },
        {
            "product_id": 961,
            "product_name": "ROASTED DIET-ROASTED MIX. LIME 125 GM",
            "product_image": "https://www.patanjaliayurved.net/assets/product_images/400x500/1514272142RoastedMixtureLime400x500.png",
            "product_price": 55,
            "product_offer": "",
            "product_mrp": 0,
            "weight": 125,
            "unit": "gms",
            "available_qty": 423,
	    "in_wishlist":0
        },
        {
            "product_id": 960,
            "product_name": "ROASTED DIET-QUINOA-MASALA FLAV 80 GM",
            "product_image": "https://www.patanjaliayurved.net/assets/product_images/400x500/1514272015PatanjliQuinoaPuffMasalaFlavour400x500.png",
            "product_price": 75,
            "product_offer": "",
            "product_mrp": 0,
            "weight": 80,
            "unit": "gms",
            "available_qty": 0,
	    "in_wishlist":1
        },
        {
            "product_id": 955,
            "product_name": "ROASTED DIET-FLAXSEED CHILI LIME 150GM ",
            "product_image": "https://www.patanjaliayurved.net/assets/product_images/400x500/1514268380PatanjaliFlaxseedChilliLime400x500.png",
            "product_price": 65,
            "product_offer": "",
            "product_mrp": 0,
            "weight": 150,
            "unit": "gms",
            "available_qty": 407,
	    "in_wishlist":1			
        },
        {
            "product_id": 979,
            "product_name": "PATANJALI BALM  ",
            "product_image": "https://www.patanjaliayurved.net/assets/product_images/400x500/1514366303PATANJALIBALM10gm400x500.png",
            "product_price": 18,
            "product_offer": "",
            "product_mrp": 0,
            "weight": 10,
            "unit": "gms",
            "available_qty": 0,
	    "in_wishlist":1
        }
    ]');

        $data1 = array('id' => 1,
            'title' => "Offers",
            'products' => $pro
        );
        array_push($homeproducts, $data1);

        $data2 = array('id' => 2,
            'title' => "Latest Products",
            'products' => $pro
        );
        array_push($homeproducts, $data2);

        $data3 = array('id' => 3,
            'title' => "Wishlist",
            'products' => $pro
        );
        array_push($homeproducts, $data3);

        $data4 = array('id' => 4,
            'title' => "Now in Stock",
            'products' => $pro
        );
        array_push($homeproducts, $data4);

        $data5 = array('id' => 5,
            'title' => "Most Popular Items",
            'products' => $pro
        );
        array_push($homeproducts, $data5);
        $data6 = array('id' => 6,
            'title' => "Popular Combos",
            'products' => $pro
        );
        array_push($homeproducts, $data6);
        $response = array("status" => 1, "data" => $homeproducts);
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function getOffers_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $customer_id = $data['customer_id'];
        $productsarray = json_decode('[
        {
            "product_id": 958,
            "product_name": "ROASTED DIET-QUINOA PUFF -TOMATO FLAV 80 GM",
            "product_image": "https://www.patanjaliayurved.net/assets/product_images/400x500/1514268807PatanjaliQuinoaPuffTomatoFlavour400x500.png",
            "product_price": 75,
            "product_offer": "",
            "product_mrp": 0,
            "weight": 80,
            "unit": "gms",
            "available_qty": 458,
	    "in_wishlist": 1
        },
        {
            "product_id": 887,
            "product_name": "AASTHA CONE DHOOP (SANDAL)",
            "product_image": "https://www.patanjaliayurved.net/assets/product_images/400x500/Aastha%20Dhoop%20Sandal-400x500.png",
            "product_price": 15,
            "product_offer": "",
            "product_mrp": 0,
            "weight": 33,
            "unit": "GM",
            "available_qty": 423,
            "in_wishlist": 1
        },
        {
            "product_id": 961,
            "product_name": "ROASTED DIET-ROASTED MIX. LIME 125 GM",
            "product_image": "https://www.patanjaliayurved.net/assets/product_images/400x500/1514272142RoastedMixtureLime400x500.png",
            "product_price": 55,
            "product_offer": "",
            "product_mrp": 0,
            "weight": 125,
            "unit": "gms",
            "available_qty": 423,
	    "in_wishlist": 0
        },
        {
            "product_id": 960,
            "product_name": "ROASTED DIET-QUINOA-MASALA FLAV 80 GM",
            "product_image": "https://www.patanjaliayurved.net/assets/product_images/400x500/1514272015PatanjliQuinoaPuffMasalaFlavour400x500.png",
            "product_price": 75,
            "product_offer": "",
            "product_mrp": 0,
            "weight": 80,
            "unit": "gms",
            "available_qty": 0,
	    "in_wishlist": 0
        },
        {
            "product_id": 955,
            "product_name": "ROASTED DIET-FLAXSEED CHILI LIME 150GM ",
            "product_image": "https://www.patanjaliayurved.net/assets/product_images/400x500/1514268380PatanjaliFlaxseedChilliLime400x500.png",
            "product_price": 65,
            "product_offer": "",
            "product_mrp": 0,
            "weight": 150,
            "unit": "gms",
            "available_qty": 407,
	    "in_wishlist": 1			
        },
        {
            "product_id": 979,
            "product_name": "PATANJALI BALM  ",
            "product_image": "https://www.patanjaliayurved.net/assets/product_images/400x500/1514366303PATANJALIBALM10gm400x500.png",
            "product_price": 18,
            "product_offer": "",
            "product_mrp": 0,
            "weight": 10,
            "unit": "gms",
            "available_qty": 0,
	    "in_wishlist": 0
        },
        {
            "product_id": 933,
            "product_name": "PATANJALI CREAMFEAST MILK VANILLA BISCUIT 84 GM",
            "product_image": "https://www.patanjaliayurved.net/assets/product_images/400x500/1515230708CreamfeastVanilla400x500.png",
            "product_price": 9,
            "product_offer": "10% OFF",
            "product_mrp": 10,
            "weight": 84,
            "unit": "gms",
            "available_qty": 395,
	    "in_wishlist": 0
        },
        {
            "product_id": 959,
            "product_name": "ROASTED DIET-RICE CRISPY MIXTURE 125 G",
            "product_image": "https://www.patanjaliayurved.net/assets/product_images/400x500/1514271838PatanjaliRiceCrispyMixture400x500.png",
            "product_price": 35,
            "product_offer": "30% OFF",
            "product_mrp": 50,
            "weight": 125,
            "unit": "gms",
            "available_qty": 0,
	    "in_wishlist": 0
        },
        {
            "product_id": 956,
            "product_name": "ROASTED DIET-MELON & FLAXSEED 150 GM",
            "product_image": "https://www.patanjaliayurved.net/assets/product_images/400x500/1514268528PatanjaliMelonnFlaxseed400x500.png",
            "product_price": 80,
            "product_offer": "",
            "product_mrp": 0,
            "weight": 150,
            "unit": "gms",
            "available_qty": 380,
	    "in_wishlist": 1
        }
    ]');
        $response = array('status' => 1, 'data' => $productsarray);
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function getLatestProducts_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $customer_id = $data['customer_id'];
        $productsarray = json_decode('[
        {
            "product_id": 958,
            "product_name": "ROASTED DIET-QUINOA PUFF -TOMATO FLAV 80 GM",
            "product_image": "https://www.patanjaliayurved.net/assets/product_images/400x500/1514268807PatanjaliQuinoaPuffTomatoFlavour400x500.png",
            "product_price": 75,
            "product_offer": "",
            "product_mrp": 0,
            "weight": 80,
            "unit": "gms",
            "available_qty": 458,
	    "in_wishlist": 1
        },
        {
            "product_id": 979,
            "product_name": "PATANJALI BALM",
            "product_image": "https://www.patanjaliayurved.net/assets/product_images/400x500/1514366303PATANJALIBALM10gm400x500.png",
            "product_price": 18,
            "product_offer": "",
            "product_mrp": 0,
            "weight": 10,
            "unit": "gms",
            "available_qty": 0,
	    "in_wishlist": 0
        },
        {
            "product_id": 961,
            "product_name": "ROASTED DIET-ROASTED MIX. LIME 125 GM",
            "product_image": "https://www.patanjaliayurved.net/assets/product_images/400x500/1514272142RoastedMixtureLime400x500.png",
            "product_price": 55,
            "product_offer": "",
            "product_mrp": 0,
            "weight": 125,
            "unit": "gms",
            "available_qty": 423,
	    "in_wishlist": 0
        },
        {
            "product_id": 960,
            "product_name": "ROASTED DIET-QUINOA-MASALA FLAV 80 GM",
            "product_image": "https://www.patanjaliayurved.net/assets/product_images/400x500/1514272015PatanjliQuinoaPuffMasalaFlavour400x500.png",
            "product_price": 75,
            "product_offer": "",
            "product_mrp": 0,
            "weight": 80,
            "unit": "gms",
            "available_qty": 0,
	    "in_wishlist": 0
        },
        {
            "product_id": 887,
            "product_name": "AASTHA CONE DHOOP (SANDAL)",
            "product_image": "https://www.patanjaliayurved.net/assets/product_images/400x500/Aastha%20Dhoop%20Sandal-400x500.png",
            "product_price": 15,
            "product_offer": "",
            "product_mrp": 0,
            "weight": 33,
            "unit": "GM",
            "available_qty": 423,
            "in_wishlist": 1
        },
        {
            "product_id": 955,
            "product_name": "ROASTED DIET-FLAXSEED CHILI LIME 150GM ",
            "product_image": "https://www.patanjaliayurved.net/assets/product_images/400x500/1514268380PatanjaliFlaxseedChilliLime400x500.png",
            "product_price": 65,
            "product_offer": "",
            "product_mrp": 0,
            "weight": 150,
            "unit": "gms",
            "available_qty": 407,
	    "in_wishlist": 1			
        },
        {
            "product_id": 933,
            "product_name": "PATANJALI CREAMFEAST MILK VANILLA BISCUIT 84 GM",
            "product_image": "https://www.patanjaliayurved.net/assets/product_images/400x500/1515230708CreamfeastVanilla400x500.png",
            "product_price": 9,
            "product_offer": "10% OFF",
            "product_mrp": 10,
            "weight": 84,
            "unit": "gms",
            "available_qty": 395,
	    "in_wishlist": 0
        },
        {
            "product_id": 959,
            "product_name": "ROASTED DIET-RICE CRISPY MIXTURE 125 G",
            "product_image": "https://www.patanjaliayurved.net/assets/product_images/400x500/1514271838PatanjaliRiceCrispyMixture400x500.png",
            "product_price": 35,
            "product_offer": "30% OFF",
            "product_mrp": 50,
            "weight": 125,
            "unit": "gms",
            "available_qty": 0,
	    "in_wishlist": 0
        },
        {
            "product_id": 956,
            "product_name": "ROASTED DIET-MELON & FLAXSEED 150 GM",
            "product_image": "https://www.patanjaliayurved.net/assets/product_images/400x500/1514268528PatanjaliMelonnFlaxseed400x500.png",
            "product_price": 80,
            "product_offer": "",
            "product_mrp": 0,
            "weight": 150,
            "unit": "gms",
            "available_qty": 380,
	    "in_wishlist": 1
        }
    ]');
        $response = array('status' => 1, 'data' => $productsarray);
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function getWishlist_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $customer_id = $data['customer_id'];
        $productsarray = json_decode('[
        {
            "product_id": 958,
            "product_name": "ROASTED DIET-QUINOA PUFF -TOMATO FLAV 80 GM",
            "product_image": "https://www.patanjaliayurved.net/assets/product_images/400x500/1514268807PatanjaliQuinoaPuffTomatoFlavour400x500.png",
            "product_price": 75,
            "product_offer": "",
            "product_mrp": 0,
            "weight": 80,
            "unit": "gms",
            "available_qty": 458,
	    "in_wishlist": 1
        },
        {
            "product_id": 979,
            "product_name": "PATANJALI BALM",
            "product_image": "https://www.patanjaliayurved.net/assets/product_images/400x500/1514366303PATANJALIBALM10gm400x500.png",
            "product_price": 18,
            "product_offer": "",
            "product_mrp": 0,
            "weight": 10,
            "unit": "gms",
            "available_qty": 0,
	    "in_wishlist": 0
        },
        {
            "product_id": 960,
            "product_name": "ROASTED DIET-QUINOA-MASALA FLAV 80 GM",
            "product_image": "https://www.patanjaliayurved.net/assets/product_images/400x500/1514272015PatanjliQuinoaPuffMasalaFlavour400x500.png",
            "product_price": 75,
            "product_offer": "",
            "product_mrp": 0,
            "weight": 80,
            "unit": "gms",
            "available_qty": 0,
	    "in_wishlist": 0
        },
        {
            "product_id": 933,
            "product_name": "PATANJALI CREAMFEAST MILK VANILLA BISCUIT 84 GM",
            "product_image": "https://www.patanjaliayurved.net/assets/product_images/400x500/1515230708CreamfeastVanilla400x500.png",
            "product_price": 9,
            "product_offer": "10% OFF",
            "product_mrp": 10,
            "weight": 84,
            "unit": "gms",
            "available_qty": 395,
	    "in_wishlist": 0
        },
        {
            "product_id": 887,
            "product_name": "AASTHA CONE DHOOP (SANDAL)",
            "product_image": "https://www.patanjaliayurved.net/assets/product_images/400x500/Aastha%20Dhoop%20Sandal-400x500.png",
            "product_price": 15,
            "product_offer": "",
            "product_mrp": 0,
            "weight": 33,
            "unit": "GM",
            "available_qty": 423,
            "in_wishlist": 1
        },
        {
            "product_id": 955,
            "product_name": "ROASTED DIET-FLAXSEED CHILI LIME 150GM",
            "product_image": "https://www.patanjaliayurved.net/assets/product_images/400x500/1514268380PatanjaliFlaxseedChilliLime400x500.png",
            "product_price": 65,
            "product_offer": "",
            "product_mrp": 0,
            "weight": 150,
            "unit": "gms",
            "available_qty": 407,
	    "in_wishlist": 1			
        },
        {
            "product_id": 961,
            "product_name": "ROASTED DIET-ROASTED MIX. LIME 125 GM",
            "product_image": "https://www.patanjaliayurved.net/assets/product_images/400x500/1514272142RoastedMixtureLime400x500.png",
            "product_price": 55,
            "product_offer": "",
            "product_mrp": 0,
            "weight": 125,
            "unit": "gms",
            "available_qty": 423,
	    "in_wishlist": 0
        },
        {
            "product_id": 959,
            "product_name": "ROASTED DIET-RICE CRISPY MIXTURE 125 GM",
            "product_image": "https://www.patanjaliayurved.net/assets/product_images/400x500/1514271838PatanjaliRiceCrispyMixture400x500.png",
            "product_price": 35,
            "product_offer": "30% OFF",
            "product_mrp": 50,
            "weight": 125,
            "unit": "gms",
            "available_qty": 0,
	    "in_wishlist": 0
        },
        {
            "product_id": 956,
            "product_name": "ROASTED DIET-MELON & FLAXSEED 150 GM",
            "product_image": "https://www.patanjaliayurved.net/assets/product_images/400x500/1514268528PatanjaliMelonnFlaxseed400x500.png",
            "product_price": 80,
            "product_offer": "",
            "product_mrp": 0,
            "weight": 150,
            "unit": "gms",
            "available_qty": 380,
	    "in_wishlist": 1
        }
    ]');
        $response = array('status' => 1, 'data' => $productsarray);
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function getNowInStock_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $customer_id = $data['customer_id'];
        $productsarray = json_decode('[
        {
            "product_id": 958,
            "product_name": "ROASTED DIET-QUINOA PUFF -TOMATO FLAV 80 GM",
            "product_image": "https://www.patanjaliayurved.net/assets/product_images/400x500/1514268807PatanjaliQuinoaPuffTomatoFlavour400x500.png",
            "product_price": 75,
            "product_offer": "",
            "product_mrp": 0,
            "weight": 80,
            "unit": "gms",
            "available_qty": 458,
	    "in_wishlist": 1
        },
        {
            "product_id": 979,
            "product_name": "PATANJALI BALM",
            "product_image": "https://www.patanjaliayurved.net/assets/product_images/400x500/1514366303PATANJALIBALM10gm400x500.png",
            "product_price": 18,
            "product_offer": "",
            "product_mrp": 0,
            "weight": 10,
            "unit": "gms",
            "available_qty": 0,
	    "in_wishlist": 0
        },
        {
            "product_id": 933,
            "product_name": "PATANJALI CREAMFEAST MILK VANILLA BISCUIT 84 GM",
            "product_image": "https://www.patanjaliayurved.net/assets/product_images/400x500/1515230708CreamfeastVanilla400x500.png",
            "product_price": 9,
            "product_offer": "10% OFF",
            "product_mrp": 10,
            "weight": 84,
            "unit": "gms",
            "available_qty": 395,
	    "in_wishlist": 0
        },
        {
            "product_id": 959,
            "product_name": "ROASTED DIET-RICE CRISPY MIXTURE 125 GM",
            "product_image": "https://www.patanjaliayurved.net/assets/product_images/400x500/1514271838PatanjaliRiceCrispyMixture400x500.png",
            "product_price": 35,
            "product_offer": "30% OFF",
            "product_mrp": 50,
            "weight": 125,
            "unit": "gms",
            "available_qty": 0,
	    "in_wishlist": 0
        },
        {
            "product_id": 887,
            "product_name": "AASTHA CONE DHOOP (SANDAL)",
            "product_image": "https://www.patanjaliayurved.net/assets/product_images/400x500/Aastha%20Dhoop%20Sandal-400x500.png",
            "product_price": 15,
            "product_offer": "",
            "product_mrp": 0,
            "weight": 33,
            "unit": "GM",
            "available_qty": 423,
            "in_wishlist": 1
        },
        {
            "product_id": 955,
            "product_name": "ROASTED DIET-FLAXSEED CHILI LIME 150GM",
            "product_image": "https://www.patanjaliayurved.net/assets/product_images/400x500/1514268380PatanjaliFlaxseedChilliLime400x500.png",
            "product_price": 65,
            "product_offer": "",
            "product_mrp": 0,
            "weight": 150,
            "unit": "gms",
            "available_qty": 407,
	    "in_wishlist": 1			
        },
        {
            "product_id": 961,
            "product_name": "ROASTED DIET-ROASTED MIX. LIME 125 GM",
            "product_image": "https://www.patanjaliayurved.net/assets/product_images/400x500/1514272142RoastedMixtureLime400x500.png",
            "product_price": 55,
            "product_offer": "",
            "product_mrp": 0,
            "weight": 125,
            "unit": "gms",
            "available_qty": 423,
	    "in_wishlist": 0
        },
        {
            "product_id": 956,
            "product_name": "ROASTED DIET-MELON & FLAXSEED 150 GM",
            "product_image": "https://www.patanjaliayurved.net/assets/product_images/400x500/1514268528PatanjaliMelonnFlaxseed400x500.png",
            "product_price": 80,
            "product_offer": "",
            "product_mrp": 0,
            "weight": 150,
            "unit": "gms",
            "available_qty": 380,
	    "in_wishlist": 1
        },
        {
            "product_id": 960,
            "product_name": "ROASTED DIET-QUINOA-MASALA FLAV 80 GM",
            "product_image": "https://www.patanjaliayurved.net/assets/product_images/400x500/1514272015PatanjliQuinoaPuffMasalaFlavour400x500.png",
            "product_price": 75,
            "product_offer": "",
            "product_mrp": 0,
            "weight": 80,
            "unit": "gms",
            "available_qty": 0,
	    "in_wishlist": 0
        }
    ]');
        $response = array('status' => 1, 'data' => $productsarray);
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function getMostPopularItems_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $customer_id = $data['customer_id'];
        $productsarray = json_decode('[
        {
            "product_id": 958,
            "product_name": "ROASTED DIET-QUINOA PUFF -TOMATO FLAV 80 GM",
            "product_image": "https://www.patanjaliayurved.net/assets/product_images/400x500/1514268807PatanjaliQuinoaPuffTomatoFlavour400x500.png",
            "product_price": 75,
            "product_offer": "",
            "product_mrp": 0,
            "weight": 80,
            "unit": "gms",
            "available_qty": 458,
	    "in_wishlist": 1
        },
        {
            "product_id": 979,
            "product_name": "PATANJALI BALM",
            "product_image": "https://www.patanjaliayurved.net/assets/product_images/400x500/1514366303PATANJALIBALM10gm400x500.png",
            "product_price": 18,
            "product_offer": "",
            "product_mrp": 0,
            "weight": 10,
            "unit": "gms",
            "available_qty": 0,
	    "in_wishlist": 0
        },
        {
            "product_id": 933,
            "product_name": "PATANJALI CREAMFEAST MILK VANILLA BISCUIT 84 GM",
            "product_image": "https://www.patanjaliayurved.net/assets/product_images/400x500/1515230708CreamfeastVanilla400x500.png",
            "product_price": 9,
            "product_offer": "10% OFF",
            "product_mrp": 10,
            "weight": 84,
            "unit": "gms",
            "available_qty": 395,
	    "in_wishlist": 0
        },
        {
            "product_id": 959,
            "product_name": "ROASTED DIET-RICE CRISPY MIXTURE 125 GM",
            "product_image": "https://www.patanjaliayurved.net/assets/product_images/400x500/1514271838PatanjaliRiceCrispyMixture400x500.png",
            "product_price": 35,
            "product_offer": "30% OFF",
            "product_mrp": 50,
            "weight": 125,
            "unit": "gms",
            "available_qty": 0,
	    "in_wishlist": 0
        },
        {
            "product_id": 887,
            "product_name": "AASTHA CONE DHOOP (SANDAL)",
            "product_image": "https://www.patanjaliayurved.net/assets/product_images/400x500/Aastha%20Dhoop%20Sandal-400x500.png",
            "product_price": 15,
            "product_offer": "",
            "product_mrp": 0,
            "weight": 33,
            "unit": "GM",
            "available_qty": 423,
            "in_wishlist": 1
        },
        {
            "product_id": 955,
            "product_name": "ROASTED DIET-FLAXSEED CHILI LIME 150GM",
            "product_image": "https://www.patanjaliayurved.net/assets/product_images/400x500/1514268380PatanjaliFlaxseedChilliLime400x500.png",
            "product_price": 65,
            "product_offer": "",
            "product_mrp": 0,
            "weight": 150,
            "unit": "gms",
            "available_qty": 407,
	    "in_wishlist": 1			
        },
        {
            "product_id": 961,
            "product_name": "ROASTED DIET-ROASTED MIX. LIME 125 GM",
            "product_image": "https://www.patanjaliayurved.net/assets/product_images/400x500/1514272142RoastedMixtureLime400x500.png",
            "product_price": 55,
            "product_offer": "",
            "product_mrp": 0,
            "weight": 125,
            "unit": "gms",
            "available_qty": 423,
	    "in_wishlist": 0
        },
        {
            "product_id": 956,
            "product_name": "ROASTED DIET-MELON & FLAXSEED 150 GM",
            "product_image": "https://www.patanjaliayurved.net/assets/product_images/400x500/1514268528PatanjaliMelonnFlaxseed400x500.png",
            "product_price": 80,
            "product_offer": "",
            "product_mrp": 0,
            "weight": 150,
            "unit": "gms",
            "available_qty": 380,
	    "in_wishlist": 1
        },
        {
            "product_id": 960,
            "product_name": "ROASTED DIET-QUINOA-MASALA FLAV 80 GM",
            "product_image": "https://www.patanjaliayurved.net/assets/product_images/400x500/1514272015PatanjliQuinoaPuffMasalaFlavour400x500.png",
            "product_price": 75,
            "product_offer": "",
            "product_mrp": 0,
            "weight": 80,
            "unit": "gms",
            "available_qty": 0,
	    "in_wishlist": 0
        }
    ]');
        $response = array('status' => 1, 'data' => $productsarray);
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function getPopularCombo_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $customer_id = $data['customer_id'];
        $productsarray = json_decode('[
        {
            "product_id": 958,
            "product_name": "ROASTED DIET-QUINOA PUFF -TOMATO FLAV 80 GM",
            "product_image": "https://www.patanjaliayurved.net/assets/product_images/400x500/1514268807PatanjaliQuinoaPuffTomatoFlavour400x500.png",
            "product_price": 75,
            "product_offer": "",
            "product_mrp": 0,
            "weight": 80,
            "unit": "gms",
            "available_qty": 458,
	    "in_wishlist": 1
        },
        {
            "product_id": 979,
            "product_name": "PATANJALI BALM",
            "product_image": "https://www.patanjaliayurved.net/assets/product_images/400x500/1514366303PATANJALIBALM10gm400x500.png",
            "product_price": 18,
            "product_offer": "",
            "product_mrp": 0,
            "weight": 10,
            "unit": "gms",
            "available_qty": 0,
	    "in_wishlist": 0
        },
        {
            "product_id": 933,
            "product_name": "PATANJALI CREAMFEAST MILK VANILLA BISCUIT 84 GM",
            "product_image": "https://www.patanjaliayurved.net/assets/product_images/400x500/1515230708CreamfeastVanilla400x500.png",
            "product_price": 9,
            "product_offer": "10% OFF",
            "product_mrp": 10,
            "weight": 84,
            "unit": "gms",
            "available_qty": 395,
	    "in_wishlist": 0
        },
        {
            "product_id": 959,
            "product_name": "ROASTED DIET-RICE CRISPY MIXTURE 125 GM",
            "product_image": "https://www.patanjaliayurved.net/assets/product_images/400x500/1514271838PatanjaliRiceCrispyMixture400x500.png",
            "product_price": 35,
            "product_offer": "30% OFF",
            "product_mrp": 50,
            "weight": 125,
            "unit": "gms",
            "available_qty": 0,
	    "in_wishlist": 0
        },
        {
            "product_id": 887,
            "product_name": "AASTHA CONE DHOOP (SANDAL)",
            "product_image": "https://www.patanjaliayurved.net/assets/product_images/400x500/Aastha%20Dhoop%20Sandal-400x500.png",
            "product_price": 15,
            "product_offer": "",
            "product_mrp": 0,
            "weight": 33,
            "unit": "GM",
            "available_qty": 423,
            "in_wishlist": 1
        },
        {
            "product_id": 955,
            "product_name": "ROASTED DIET-FLAXSEED CHILI LIME 150GM",
            "product_image": "https://www.patanjaliayurved.net/assets/product_images/400x500/1514268380PatanjaliFlaxseedChilliLime400x500.png",
            "product_price": 65,
            "product_offer": "",
            "product_mrp": 0,
            "weight": 150,
            "unit": "gms",
            "available_qty": 407,
	    "in_wishlist": 1			
        },
        {
            "product_id": 961,
            "product_name": "ROASTED DIET-ROASTED MIX. LIME 125 GM",
            "product_image": "https://www.patanjaliayurved.net/assets/product_images/400x500/1514272142RoastedMixtureLime400x500.png",
            "product_price": 55,
            "product_offer": "",
            "product_mrp": 0,
            "weight": 125,
            "unit": "gms",
            "available_qty": 423,
	    "in_wishlist": 0
        },
        {
            "product_id": 956,
            "product_name": "ROASTED DIET-MELON & FLAXSEED 150 GM",
            "product_image": "https://www.patanjaliayurved.net/assets/product_images/400x500/1514268528PatanjaliMelonnFlaxseed400x500.png",
            "product_price": 80,
            "product_offer": "",
            "product_mrp": 0,
            "weight": 150,
            "unit": "gms",
            "available_qty": 380,
	    "in_wishlist": 1
        },
        {
            "product_id": 960,
            "product_name": "ROASTED DIET-QUINOA-MASALA FLAV 80 GM",
            "product_image": "https://www.patanjaliayurved.net/assets/product_images/400x500/1514272015PatanjliQuinoaPuffMasalaFlavour400x500.png",
            "product_price": 75,
            "product_offer": "",
            "product_mrp": 0,
            "weight": 80,
            "unit": "gms",
            "available_qty": 0,
	    "in_wishlist": 0
        }
    ]');
        $response = array('status' => 1, 'data' => $productsarray);
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function productByCategory_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $customer_id = $data['customer_id'];
        $category_id = $data['category_id'];
        $productsarray = json_decode('[
        {
            "product_id": 958,
            "product_name": "ROASTED DIET-QUINOA PUFF -TOMATO FLAV 80 GM",
            "product_image": "https://www.patanjaliayurved.net/assets/product_images/400x500/1514268807PatanjaliQuinoaPuffTomatoFlavour400x500.png",
            "product_price": 75,
            "product_offer": "",
            "product_mrp": 0,
            "weight": 80,
            "unit": "gms",
            "available_qty": 458,
	    "in_wishlist": 1
        },
        {
            "product_id": 979,
            "product_name": "PATANJALI BALM",
            "product_image": "https://www.patanjaliayurved.net/assets/product_images/400x500/1514366303PATANJALIBALM10gm400x500.png",
            "product_price": 18,
            "product_offer": "",
            "product_mrp": 0,
            "weight": 10,
            "unit": "gms",
            "available_qty": 0,
	    "in_wishlist": 0
        },
        {
            "product_id": 933,
            "product_name": "PATANJALI CREAMFEAST MILK VANILLA BISCUIT 84 GM",
            "product_image": "https://www.patanjaliayurved.net/assets/product_images/400x500/1515230708CreamfeastVanilla400x500.png",
            "product_price": 9,
            "product_offer": "10% OFF",
            "product_mrp": 10,
            "weight": 84,
            "unit": "gms",
            "available_qty": 395,
	    "in_wishlist": 0
        },
        {
            "product_id": 959,
            "product_name": "ROASTED DIET-RICE CRISPY MIXTURE 125 GM",
            "product_image": "https://www.patanjaliayurved.net/assets/product_images/400x500/1514271838PatanjaliRiceCrispyMixture400x500.png",
            "product_price": 35,
            "product_offer": "30% OFF",
            "product_mrp": 50,
            "weight": 125,
            "unit": "gms",
            "available_qty": 0,
	    "in_wishlist": 0
        },
        {
            "product_id": 887,
            "product_name": "AASTHA CONE DHOOP (SANDAL)",
            "product_image": "https://www.patanjaliayurved.net/assets/product_images/400x500/Aastha%20Dhoop%20Sandal-400x500.png",
            "product_price": 15,
            "product_offer": "",
            "product_mrp": 0,
            "weight": 33,
            "unit": "GM",
            "available_qty": 423,
            "in_wishlist": 1
        },
        {
            "product_id": 955,
            "product_name": "ROASTED DIET-FLAXSEED CHILI LIME 150GM",
            "product_image": "https://www.patanjaliayurved.net/assets/product_images/400x500/1514268380PatanjaliFlaxseedChilliLime400x500.png",
            "product_price": 65,
            "product_offer": "",
            "product_mrp": 0,
            "weight": 150,
            "unit": "gms",
            "available_qty": 407,
	    "in_wishlist": 1			
        },
        {
            "product_id": 961,
            "product_name": "ROASTED DIET-ROASTED MIX. LIME 125 GM",
            "product_image": "https://www.patanjaliayurved.net/assets/product_images/400x500/1514272142RoastedMixtureLime400x500.png",
            "product_price": 55,
            "product_offer": "",
            "product_mrp": 0,
            "weight": 125,
            "unit": "gms",
            "available_qty": 423,
	    "in_wishlist": 0
        },
        {
            "product_id": 956,
            "product_name": "ROASTED DIET-MELON & FLAXSEED 150 GM",
            "product_image": "https://www.patanjaliayurved.net/assets/product_images/400x500/1514268528PatanjaliMelonnFlaxseed400x500.png",
            "product_price": 80,
            "product_offer": "",
            "product_mrp": 0,
            "weight": 150,
            "unit": "gms",
            "available_qty": 380,
	    "in_wishlist": 1
        },
        {
            "product_id": 960,
            "product_name": "ROASTED DIET-QUINOA-MASALA FLAV 80 GM",
            "product_image": "https://www.patanjaliayurved.net/assets/product_images/400x500/1514272015PatanjliQuinoaPuffMasalaFlavour400x500.png",
            "product_price": 75,
            "product_offer": "",
            "product_mrp": 0,
            "weight": 80,
            "unit": "gms",
            "available_qty": 0,
	    "in_wishlist": 0
        }
    ]');
        $response = array('status' => 1, 'data' => $productsarray);
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function addToCart_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $cartarray = array();
        $customer_id = $data['customer_id'];
        $token = $data['token'];
        $product_id = $data['product_id'];
        $quantity = $data['quantity'];
        array_push($cartarray, array('cart_id' => 1, 'cart_items' => 3, 'cart_qty' => 5, 'cart_price' => 376));
        $response = array('status' => 1, 'data' => $cartarray, 'message' => 'Product has been added to your cart.');
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function addNotify_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $customer_id = $data['customer_id'];
        $token = $data['token'];
        $product_id = $data['product_id'];
        $response = array('status' => 1, 'message' => 'Product has been added to your notification list.');
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function addWishlist_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $customer_id = $data['customer_id'];
        $token = $data['token'];
        $product_id = $data['product_id'];
        $response = array('status' => 1, 'message' => 'Product has been added to your wishlist.');
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function productDetails_post() {
        $details_array = array();
        $data = json_decode(file_get_contents('php://input'), true);
        $customer_id = $data['customer_id'];
        $product_id = $data['product_id'];
        $productImage[] = "https://www.patanjaliayurved.net/assets/product_images/400x500/1514272015PatanjliQuinoaPuffMasalaFlavour400x500.png";
        $productImage[] = "https://www.patanjaliayurved.net/assets/product_images/400x500/1514272015PatanjliQuinoaPuffMasalaFlavour400x500.png";
        $productImage[] = "https://www.patanjaliayurved.net/assets/product_images/400x500/1514272015PatanjliQuinoaPuffMasalaFlavour400x500.png";
        $reviewlist = array();
        $review["review_id"] = 12;
        $review["review_user_id"] = 76;
        $review["username"] = "Rajesh Kumar";
        $review["review_title"] = "awesome chamanprash";
        $review["review_image"] = "https://www.patanjaliayurved.net/assets/product_images/400x500/1514272015PatanjliQuinoaPuffMasalaFlavour400x500.png";
        $review["review_description"] = "amazing chamanprash awesome quality and great taste";
        $review["rating_star"] = 4;
        array_push($reviewlist, $review);
        $review["review_id"] = 15;
        $review["review_user_id"] = 114;
        $review["username"] = "Aniket Sharma";
        $review["review_title"] = "awesome chamanprash";
        $review["review_image"] = "https://www.patanjaliayurved.net/assets/product_images/400x500/1514272015PatanjliQuinoaPuffMasalaFlavour400x500.png";
        $review["review_description"] = "amazing chamanprash awesome quality and great taste";
        $review["rating_star"] = 5;
        array_push($reviewlist, $review);
        array_push($details_array, array('product_id' => 1, 'category_id' => 1, 'product_name' => "SPECIAL CHYAWANPRASH", 'product_description' => "Patanjali Special Chyawanprash with Amla (Indian Gooseberry), a useful antioxidant and source of Vitamin C as its main ingredient. It can be consumed by all ages. The pack size is 1kg", 'weight' => "1", 'unit' => "KG", 'product_image' => $productImage, 'available_qty' => 154, 'product_mrp' => 250, 'product_price' => 225, 'product_offer' => "10% OFF", 'average_rating' => "4.6", 'totalreviews' => "31", 'in_wishlist' => 1, 'is_veg' => 1, 'reviews' => $reviewlist));
        $response = array('status' => 1, 'data' => $details_array);
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function addAddress_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $newaddress = array();
        $customer_id = $data['customer_id'];
        $token = $data['token'];
        $name = $data['name'];
        $mobile = $data['mobile'];
        $alternatemobile = $data['alternatemobile'];
        $pincode = $data['pincode'];
        $state_id = $data['state_id'];
        $city_id = $data['city_id'];
        $address = $data['address'];
        $landmark = $data['landmark'];
        $type = $data['type'];
        $is_default = $data['is_default'];
        $response = array('status' => 1, "message" => "Address has been added successfully");
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function getAddressDetail_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $customer_id = $data['customer_id'];
        $token = $data['token'];
        $address_id = $data['address_id'];
        $addresses = json_decode('{
            "address_id": 63,
            "name": "Sanjay Singh",
            "mobile": 9875424854,
            "alternatemobile": 9800000021,
            "address": "Patanjali Ayurved Limited Department ecommerce ",
            "landmark": "D-28 Industrial area Near Income Tax office",
            "city_name": "Haridwar",
            "state_name": "Uttarakhand",
            "zipcode": 249401,
            "is_default": 1,
            "type": "Home"
            
        }');
        $response = array('status' => 1, 'data' => $addresses);
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function editAddress_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $customer_id = $data['customer_id'];
        $token = $data['token'];
        $address_id = $data['address_id'];
        $name = $data['name'];
        $mobile = $data['mobile'];
        $alternatemobile = $data['alternatemobile'];
        $pincode = $data['pincode'];
        $state_id = $data['state_id'];
        $city_id = $data['city_id'];
        $address = $data['address'];
        $landmark = $data['landmark'];
        $type = $data['type'];
        $is_default = $data['is_default'];
        $response = array('status' => 1, "message" => "Address has been updated successfully");
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function getBillingAddressDetail_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $customer_id = $data['customer_id'];
        $token = $data['token'];
        $address_id = $data['address_id'];
        $addresses = json_decode('{
            "address_id": 63,
            "name": "Sanjay Singh",
            "mobile": 9875424854,
            "alternatemobile": 9800000021,
            "address": "Patanjali Ayurved Limited Department ecommerce ",
            "landmark": "D-28 Industrial area Near Income Tax office",
            "city_name": "Haridwar",
            "state_name": "Uttarakhand",
            "zipcode": 249401,
            "type": "Home"
            
        }');
        $response = array('status' => 1, 'data' => $addresses);
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function editBillingAddress_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $customer_id = $data['customer_id'];
        $token = $data['token'];
        $address_id = $data['address_id'];
        $name = $data['name'];
        $mobile = $data['mobile'];
        $alternatemobile = $data['alternatemobile'];
        $pincode = $data['pincode'];
        $state_id = $data['state_id'];
        $city_id = $data['city_id'];
        $address = $data['address'];
        $landmark = $data['landmark'];
        $type = $data['type'];
        $response = array('status' => 1, "message" => "Billing address has been updated successfully");
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function removeAddress_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $customer_id = $data['customer_id'];
        $token = $data['token'];
        $address_id = $data['address_id'];
        $response = array('status' => 1, "message" => "Address has been deleted successfully");
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function setDefaultAddress_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $customer_id = $data['customer_id'];
        $token = $data['token'];
        $address_id = $data['address_id'];
        $response = array('status' => 1, "message" => "Address has been updated successfully");
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function getAddresses_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $customer_id = $data['customer_id'];
        $token = $data['token'];
        $addresses = json_decode('{
    "status": 1,
    "data": [
        {
            "address_id": 63,
            "name": "Sanjay Singh",
            "mobile": 9875424854,
            "alternatemobile": 9800000021,
            "address": "Patanjali Ayurved Limited Department ecommerce ",
            "landmark": "D-28 Industrial area Near Income Tax office",
            "city_name": "Haridwar",
            "state_name": "Uttarakhand",
            "zipcode": 249401,
            "is_default": 1,
            "type": "Home"
            
        },
        {
            "address_id": 152,
            "name": "Puneet Yadav",
            "mobile": 9174000321,
            "alternatemobile": 9000001021,
            "address": "Patanjali Ayurved Limited Department ecommerce ",
            "landmark": "D-28 Industrial area Near Income Tax office",
            "city_name": "Dewas",
            "state_name": "Madhya Pradesh",
            "zipcode": 249401,
            "is_default": 1,
            "type": "Home"
        }
    ]
}');
        $response = array('status' => 1, 'data' => $addresses);
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function addIssue_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $newaddress = array();
        $customer_id = $data['customer_id'];
        $token = $data['token'];
        $name = $data['product_id'];
        $issue_type = $data['issue_type'];
        $issue_message = $data['issue_message'];
        $response = array('status' => 1, "message" => "Added successfully");
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function addReview_post() {
        $data = $_POST;
        $customer_id = $data['customer_id'];
        $token = $data['token'];
        $product_id = $data['product_id'];
        $title = $data['title'];
        $description = $data['description'];
        $rating = $data['rating'];
        $review_image = $data['review_image'];
        $response = array('status' => 1, 'message' => 'Review has been added successfully');
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function productReview_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $product_id = $data['product_id'];
        $reviewlist = array();
        $review["review_id"] = 12;
        $review["review_user_id"] = 76;
        $review["username"] = "Rajesh Kumar";
        $review["review_title"] = "awesome chamanprash";
        $review["review_image"] = "https://www.patanjaliayurved.net/assets/product_images/400x500/1514272015PatanjliQuinoaPuffMasalaFlavour400x500.png";
        $review["review_description"] = "amazing chamanprash awesome quality and great taste";
        $review["rating_star"] = 4;
        array_push($reviewlist, $review);
        $review["review_id"] = 15;
        $review["review_user_id"] = 114;
        $review["username"] = "Aniket Sharma";
        $review["review_title"] = "awesome chamanprash";
        $review["review_image"] = "https://www.patanjaliayurved.net/assets/product_images/400x500/1514272015PatanjliQuinoaPuffMasalaFlavour400x500.png";
        $review["review_description"] = "amazing chamanprash awesome quality and great taste";
        $review["rating_star"] = 5;
        array_push($reviewlist, $review);
        $review["review_id"] = 12;
        $review["review_user_id"] = 76;
        $review["username"] = "Rajesh Kumar";
        $review["review_title"] = "awesome chamanprash";
        $review["review_image"] = "https://www.patanjaliayurved.net/assets/product_images/400x500/1514272015PatanjliQuinoaPuffMasalaFlavour400x500.png";
        $review["review_description"] = "amazing chamanprash awesome quality and great taste";
        $review["rating_star"] = 4;
        array_push($reviewlist, $review);
        $review["review_id"] = 15;
        $review["review_user_id"] = 114;
        $review["username"] = "Aniket Sharma";
        $review["review_title"] = "awesome chamanprash";
        $review["review_image"] = "https://www.patanjaliayurved.net/assets/product_images/400x500/1514272015PatanjliQuinoaPuffMasalaFlavour400x500.png";
        $review["review_description"] = "amazing chamanprash awesome quality and great taste";
        $review["rating_star"] = 5;
        array_push($reviewlist, $review);
        $review["review_id"] = 12;
        $review["review_user_id"] = 76;
        $review["username"] = "Rajesh Kumar";
        $review["review_title"] = "awesome chamanprash";
        $review["review_image"] = "https://www.patanjaliayurved.net/assets/product_images/400x500/1514272015PatanjliQuinoaPuffMasalaFlavour400x500.png";
        $review["review_description"] = "amazing chamanprash awesome quality and great taste";
        $review["rating_star"] = 4;
        array_push($reviewlist, $review);
        $review["review_id"] = 15;
        $review["review_user_id"] = 114;
        $review["username"] = "Aniket Sharma";
        $review["review_title"] = "awesome chamanprash";
        $review["review_image"] = "https://www.patanjaliayurved.net/assets/product_images/400x500/1514272015PatanjliQuinoaPuffMasalaFlavour400x500.png";
        $review["review_description"] = "amazing chamanprash awesome quality and great taste";
        $review["rating_star"] = 5;
        array_push($reviewlist, $review);
        $review["review_id"] = 12;
        $review["review_user_id"] = 76;
        $review["username"] = "Rajesh Kumar";
        $review["review_title"] = "awesome chamanprash";
        $review["review_image"] = "https://www.patanjaliayurved.net/assets/product_images/400x500/1514272015PatanjliQuinoaPuffMasalaFlavour400x500.png";
        $review["review_description"] = "amazing chamanprash awesome quality and great taste";
        $review["rating_star"] = 4;
        array_push($reviewlist, $review);
        $review["review_id"] = 15;
        $review["review_user_id"] = 114;
        $review["username"] = "Aniket Sharma";
        $review["review_title"] = "awesome chamanprash";
        $review["review_image"] = "https://www.patanjaliayurved.net/assets/product_images/400x500/1514272015PatanjliQuinoaPuffMasalaFlavour400x500.png";
        $review["review_description"] = "amazing chamanprash awesome quality and great taste";
        $review["rating_star"] = 5;
        array_push($reviewlist, $review);
        $response = array('status' => 1, 'data' => $reviewlist);
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function relativeProducts_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $customer_id = $data['customer_id'];
        $product_id = $data['product_id'];
        $productsarray = json_decode('[
        {
            "product_id": 958,
            "product_name": "ROASTED DIET-QUINOA PUFF -TOMATO FLAV 80 GM",
            "product_image": "https://www.patanjaliayurved.net/assets/product_images/400x500/1514268807PatanjaliQuinoaPuffTomatoFlavour400x500.png",
            "product_price": 75,
            "product_offer": "",
            "product_mrp": 0,
            "weight": 80,
            "unit": "gms",
            "available_qty": 458,
	    "in_wishlist": 1
        },
        {
            "product_id": 979,
            "product_name": "PATANJALI BALM",
            "product_image": "https://www.patanjaliayurved.net/assets/product_images/400x500/1514366303PATANJALIBALM10gm400x500.png",
            "product_price": 18,
            "product_offer": "",
            "product_mrp": 0,
            "weight": 10,
            "unit": "gms",
            "available_qty": 0,
	    "in_wishlist": 0
        },
        {
            "product_id": 933,
            "product_name": "PATANJALI CREAMFEAST MILK VANILLA BISCUIT 84 GM",
            "product_image": "https://www.patanjaliayurved.net/assets/product_images/400x500/1515230708CreamfeastVanilla400x500.png",
            "product_price": 9,
            "product_offer": "10% OFF",
            "product_mrp": 10,
            "weight": 84,
            "unit": "gms",
            "available_qty": 395,
	    "in_wishlist": 0
        },
        {
            "product_id": 959,
            "product_name": "ROASTED DIET-RICE CRISPY MIXTURE 125 GM",
            "product_image": "https://www.patanjaliayurved.net/assets/product_images/400x500/1514271838PatanjaliRiceCrispyMixture400x500.png",
            "product_price": 35,
            "product_offer": "30% OFF",
            "product_mrp": 50,
            "weight": 125,
            "unit": "gms",
            "available_qty": 0,
	    "in_wishlist": 0
        },
        {
            "product_id": 887,
            "product_name": "AASTHA CONE DHOOP (SANDAL)",
            "product_image": "https://www.patanjaliayurved.net/assets/product_images/400x500/Aastha%20Dhoop%20Sandal-400x500.png",
            "product_price": 15,
            "product_offer": "",
            "product_mrp": 0,
            "weight": 33,
            "unit": "GM",
            "available_qty": 423,
            "in_wishlist": 1
        },
        {
            "product_id": 955,
            "product_name": "ROASTED DIET-FLAXSEED CHILI LIME 150GM",
            "product_image": "https://www.patanjaliayurved.net/assets/product_images/400x500/1514268380PatanjaliFlaxseedChilliLime400x500.png",
            "product_price": 65,
            "product_offer": "",
            "product_mrp": 0,
            "weight": 150,
            "unit": "gms",
            "available_qty": 407,
	    "in_wishlist": 1			
        },
        {
            "product_id": 961,
            "product_name": "ROASTED DIET-ROASTED MIX. LIME 125 GM",
            "product_image": "https://www.patanjaliayurved.net/assets/product_images/400x500/1514272142RoastedMixtureLime400x500.png",
            "product_price": 55,
            "product_offer": "",
            "product_mrp": 0,
            "weight": 125,
            "unit": "gms",
            "available_qty": 423,
	    "in_wishlist": 0
        },
        {
            "product_id": 956,
            "product_name": "ROASTED DIET-MELON & FLAXSEED 150 GM",
            "product_image": "https://www.patanjaliayurved.net/assets/product_images/400x500/1514268528PatanjaliMelonnFlaxseed400x500.png",
            "product_price": 80,
            "product_offer": "",
            "product_mrp": 0,
            "weight": 150,
            "unit": "gms",
            "available_qty": 380,
	    "in_wishlist": 1
        },
        {
            "product_id": 960,
            "product_name": "ROASTED DIET-QUINOA-MASALA FLAV 80 GM",
            "product_image": "https://www.patanjaliayurved.net/assets/product_images/400x500/1514272015PatanjliQuinoaPuffMasalaFlavour400x500.png",
            "product_price": 75,
            "product_offer": "",
            "product_mrp": 0,
            "weight": 80,
            "unit": "gms",
            "available_qty": 0,
	    "in_wishlist": 0
        }
    ]');
        $response = array('status' => 1, 'data' => $productsarray);
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function recentlyViewed_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $customer_id = $data['customer_id'];
        $productsarray = json_decode('[
        {
            "product_id": 958,
            "product_name": "ROASTED DIET-QUINOA PUFF -TOMATO FLAV 80 GM",
            "product_image": "https://www.patanjaliayurved.net/assets/product_images/400x500/1514268807PatanjaliQuinoaPuffTomatoFlavour400x500.png",
            "product_price": 75,
            "product_offer": "",
            "product_mrp": 0,
            "weight": 80,
            "unit": "gms",
            "available_qty": 458,
	    "in_wishlist": 1
        },
        {
            "product_id": 979,
            "product_name": "PATANJALI BALM",
            "product_image": "https://www.patanjaliayurved.net/assets/product_images/400x500/1514366303PATANJALIBALM10gm400x500.png",
            "product_price": 18,
            "product_offer": "",
            "product_mrp": 0,
            "weight": 10,
            "unit": "gms",
            "available_qty": 0,
	    "in_wishlist": 0
        },
        {
            "product_id": 933,
            "product_name": "PATANJALI CREAMFEAST MILK VANILLA BISCUIT 84 GM",
            "product_image": "https://www.patanjaliayurved.net/assets/product_images/400x500/1515230708CreamfeastVanilla400x500.png",
            "product_price": 9,
            "product_offer": "10% OFF",
            "product_mrp": 10,
            "weight": 84,
            "unit": "gms",
            "available_qty": 395,
	    "in_wishlist": 0
        },
        {
            "product_id": 959,
            "product_name": "ROASTED DIET-RICE CRISPY MIXTURE 125 GM",
            "product_image": "https://www.patanjaliayurved.net/assets/product_images/400x500/1514271838PatanjaliRiceCrispyMixture400x500.png",
            "product_price": 35,
            "product_offer": "30% OFF",
            "product_mrp": 50,
            "weight": 125,
            "unit": "gms",
            "available_qty": 0,
	    "in_wishlist": 0
        },
        {
            "product_id": 887,
            "product_name": "AASTHA CONE DHOOP (SANDAL)",
            "product_image": "https://www.patanjaliayurved.net/assets/product_images/400x500/Aastha%20Dhoop%20Sandal-400x500.png",
            "product_price": 15,
            "product_offer": "",
            "product_mrp": 0,
            "weight": 33,
            "unit": "GM",
            "available_qty": 423,
            "in_wishlist": 1
        },
        {
            "product_id": 955,
            "product_name": "ROASTED DIET-FLAXSEED CHILI LIME 150GM",
            "product_image": "https://www.patanjaliayurved.net/assets/product_images/400x500/1514268380PatanjaliFlaxseedChilliLime400x500.png",
            "product_price": 65,
            "product_offer": "",
            "product_mrp": 0,
            "weight": 150,
            "unit": "gms",
            "available_qty": 407,
	    "in_wishlist": 1			
        },
        {
            "product_id": 961,
            "product_name": "ROASTED DIET-ROASTED MIX. LIME 125 GM",
            "product_image": "https://www.patanjaliayurved.net/assets/product_images/400x500/1514272142RoastedMixtureLime400x500.png",
            "product_price": 55,
            "product_offer": "",
            "product_mrp": 0,
            "weight": 125,
            "unit": "gms",
            "available_qty": 423,
	    "in_wishlist": 0
        },
        {
            "product_id": 956,
            "product_name": "ROASTED DIET-MELON & FLAXSEED 150 GM",
            "product_image": "https://www.patanjaliayurved.net/assets/product_images/400x500/1514268528PatanjaliMelonnFlaxseed400x500.png",
            "product_price": 80,
            "product_offer": "",
            "product_mrp": 0,
            "weight": 150,
            "unit": "gms",
            "available_qty": 380,
	    "in_wishlist": 1
        },
        {
            "product_id": 960,
            "product_name": "ROASTED DIET-QUINOA-MASALA FLAV 80 GM",
            "product_image": "https://www.patanjaliayurved.net/assets/product_images/400x500/1514272015PatanjliQuinoaPuffMasalaFlavour400x500.png",
            "product_price": 75,
            "product_offer": "",
            "product_mrp": 0,
            "weight": 80,
            "unit": "gms",
            "available_qty": 0,
	    "in_wishlist": 0
        }
    ]');
        $response = array('status' => 1, 'data' => $productsarray);
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function getCartItems_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $cartarray = array();
        $customer_id = $data['customer_id'];
        $token = $data['token'];
        $response = json_decode('{
    "status": 1,
    "data": [
        {
            "cart_id": 1,
            "product_id": 560,
            "product_name": "OJAS AQUAFRESH",
            "product_mrp": 30,
            "product_price": 25,
            "product_quantity": 2,
            "available_qty": 580,
            "weight": 75,
            "unit": "gm",
            "total_price": 50,
            "max_qty": 1000,
            "product_image": "https://www.patanjaliayurved.net/assets/product_images/400x300/OJASAQUAFRESH400300.png"
        },
        {
            "cart_id": 1,
            "product_id": 800,
            "product_name": "CHOCO FLAKES",
            "product_mrp": 100,
            "product_price": 95,
            "product_quantity": 5,
            "available_qty": 33,
            "weight": 250,
            "unit": "GM",
            "total_price": 475,
            "max_qty": 1000,
            "product_image": "https://www.patanjaliayurved.net/assets/product_images/400x300/1514970482CHOCOFLAKES-250gm400x300.png"
        }
    ],
    "cart_items": 2,
    "total_mrp": 560,
    "total_discount": 25,
    "delivery_charges": 20,
    "total_cart_price": 555
}');
        //$response = array('status' => 1, 'data' => $cartarray, 'cart_items' => $customercart->cart_items, 'total_cart_price' => $customercart->cart_price, 'free_shipping_product' => $this->config->item('free_shipping_product'));
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function updateCart_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $customer_id = $data['customer_id'];
        $token = $data['token'];
        $product_id = $data['product_id'];
        $cart_id = $data['cart_id'];
        $quantity = $data['quantity'];

        $response = json_decode('{
    "status": 1,
    "data": [
        {
            "cart_id": 1,
            "product_id": 560,
            "product_name": "OJAS AQUAFRESH",
            "product_mrp": 30,
            "product_price": 25,
            "product_quantity": 2,
            "available_qty": 580,
            "weight": 75,
            "unit": "gm",
            "total_price": 50,
            "max_qty": 1000,
            "product_image": "https://www.patanjaliayurved.net/assets/product_images/400x300/OJASAQUAFRESH400300.png"
        },
        {
            "cart_id": 1,
            "product_id": 800,
            "product_name": "CHOCO FLAKES",
            "product_mrp": 100,
            "product_price": 95,
            "product_quantity": 5,
            "available_qty": 33,
            "weight": 250,
            "unit": "GM",
            "total_price": 475,
            "max_qty": 1000,
            "product_image": "https://www.patanjaliayurved.net/assets/product_images/400x300/1514970482CHOCOFLAKES-250gm400x300.png"
        }
    ],
    "cart_items": 2,
    "total_mrp": 560,
    "total_discount": 25,
    "delivery_charges": 20,
    "total_cart_price": 555
}');
        //$response = array('status' => 1, 'data' => $cartarray, 'cart_items' => $customercart->cart_items, 'total_cart_price' => $customercart->cart_price, 'free_shipping_product' => $this->config->item('free_shipping_product'));
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function removeFromCart_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $customer_id = $data['customer_id'];
        $token = $data['token'];
        $product_id = $data['product_id'];
        $cart_id = $data['cart_id'];
        $response = json_decode('{
    "status": 1,
    "data": [
        {
            "cart_id": 1,
            "product_id": 560,
            "product_name": "OJAS AQUAFRESH",
            "product_mrp": 30,
            "product_price": 25,
            "product_quantity": 2,
            "available_qty": 580,
            "weight": 75,
            "unit": "gm",
            "total_price": 50,
            "max_qty": 1000,
            "product_image": "https://www.patanjaliayurved.net/assets/product_images/400x300/OJASAQUAFRESH400300.png"
        },
        {
            "cart_id": 1,
            "product_id": 800,
            "product_name": "CHOCO FLAKES",
            "product_mrp": 100,
            "product_price": 95,
            "product_quantity": 5,
            "available_qty": 33,
            "weight": 250,
            "unit": "GM",
            "total_price": 475,
            "max_qty": 1000,
            "product_image": "https://www.patanjaliayurved.net/assets/product_images/400x300/1514970482CHOCOFLAKES-250gm400x300.png"
        }
    ],
    "cart_items": 2,
    "total_mrp": 560,
    "total_discount": 25,
    "delivery_charges": 20,
    "total_cart_price": 555
}');
        //$response = array('status' => 1, 'data' => $cartarray, 'cart_items' => $customercart->cart_items, 'total_cart_price' => $customercart->cart_price, 'free_shipping_product' => $this->config->item('free_shipping_product'));
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function orderList_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $customer_id = $data['customer_id'];
        $token = $data['token'];
        $orderlist = json_decode('{
    "status": 1,
    "data": [
        {
            "order_id": 2595,
            "order_number": 1410661377,
            "final_amount": 10000,
            "order_date": "16-05-2019",
            "items": 1,
            "status": "Completed"
        },
        {
            "order_id": 2594,
            "order_number": 1431365662,
            "final_amount": 10121,
            "order_date": "16-05-2019",
            "items": 18,
            "status": "Pending"
        },
        {
            "order_id": 2593,
            "order_number": 1433604761,
            "final_amount": 10121,
            "order_date": "16-05-2019",
            "items": 1,
            "status": "Canceled"
        },
        {
            "order_id": 2592,
            "order_number": 1416528294,
            "final_amount": 834,
            "order_date": "06-05-2019",
            "items": 2,
            "status": "Completed"
        },
        {
            "order_id": 2591,
            "order_number": 1415143791,
            "final_amount": 834,
            "order_date": "06-05-2019",
            "items": 1,
            "status": "Pending"
        },
        {
            "order_id": 2590,
            "order_number": 1420492047,
            "final_amount": 641,
            "order_date": "06-05-2019",
            "items": 15,
            "status": "Completed"
        },
        {
            "order_id": 2589,
            "order_number": 1430377535,
            "final_amount": 641,
            "order_date": "06-05-2019",
            "items": 19,
            "status": "Pending"
        }     
    ]
}');
        $response = array('status' => 1, 'data' => $orderlist);
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function recurringOrderList_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $customer_id = $data['customer_id'];
        $token = $data['token'];
        $orderlist = json_decode('{
    "status": 1,
    "data": [
        {
            "recurringorder_id": 2595,
            "last_modified_date": "16-05-2019",
            "schedual": "every 2nd week on monday",
            "product_detail": [
        {
            "product_id": 560,
            "product_name": "OJAS AQUAFRESH",
            "product_mrp": 30,
            "product_price": 25,
            "product_quantity": 2,           
            "weight": 75,
            "unit": "gm",
            "total_price": 50,
            "product_image": "https://www.patanjaliayurved.net/assets/product_images/400x300/OJASAQUAFRESH400300.png"
        },
        {
            "product_id": 800,
            "product_name": "CHOCO FLAKES",
            "product_mrp": 100,
            "product_price": 95,
            "product_quantity": 5,
            "weight": 250,
            "unit": "GM",
            "total_price": 475,
            "product_image": "https://www.patanjaliayurved.net/assets/product_images/400x300/1514970482CHOCOFLAKES-250gm400x300.png"
        }
    ],
            "status": 1
        },
        {
            "recurringorder_id": 2595,
            "last_modified_date": "16-05-2019",
            "schedual": "every 2nd week on monday",
            "product_detail": [
        {
            "product_id": 560,
            "product_name": "OJAS AQUAFRESH",
            "product_mrp": 30,
            "product_price": 25,
            "product_quantity": 2,           
            "weight": 75,
            "unit": "gm",
            "total_price": 50,
            "product_image": "https://www.patanjaliayurved.net/assets/product_images/400x300/OJASAQUAFRESH400300.png"
        },
        {
            "product_id": 800,
            "product_name": "CHOCO FLAKES",
            "product_mrp": 100,
            "product_price": 95,
            "product_quantity": 5,
            "weight": 250,
            "unit": "GM",
            "total_price": 475,
            "product_image": "https://www.patanjaliayurved.net/assets/product_images/400x300/1514970482CHOCOFLAKES-250gm400x300.png"
        }
    ],
            "status": 1
        } 
    ]
}');
        $response = array('status' => 1, 'data' => $orderlist);
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function updateRecurringOrderStatus_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $recurringorder_id = $data['recurringorder_id'];
        $customer_id = $data['customer_id'];
        $token = $data['token'];
        $response = array('status' => 1, "message" => "Order has been updated successfully");
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function deleteRecurringOrder_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $recurringorder_id = $data['recurringorder_id'];
        $customer_id = $data['customer_id'];
        $token = $data['token'];
        $response = array('status' => 1, "message" => "Order has been deleted successfully");
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function deleteRecurringOrderProduct_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $recurringorder_id = $data['recurringorder_id'];
        $product_id = $data['product_id'];
        $customer_id = $data['customer_id'];
        $token = $data['token'];
        $response = array('status' => 1, "message" => "Product has been deleted successfully");
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function orderDetails_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $customer_id = $data['customer_id'];
        $token = $data['token'];
        $order_id = $data['order_id'];
        $orderdetails = json_decode('{
            "order_id": 2595,
            "order_number": 1410661377,
            "order_items": 3,
            "order_qty": 16,
            "order_price": 800,
            "total_discount": 70,
            "cod_charges": 0,
            "delivery_charges": 0,
            "coupon_code": "New100",
            "coupon_discount": 100,
            "patanjali_credit": 60,
            "final_amount": 570,
            "order_date": "16-05-2019",          
            "payment_mode": "Debit Card",          
            "credit_points": 15,          
            "products": [
                {
                    "product_name": "Patanjali Ghee",
                    "weight": 100,
                    "unit": "gm",
                    "quantity": 1,
                    "product_price": 200,
                    "product_image": "https://www.patanjaliayurved.net/assets/product_images/400x300/1514278053ghee200ml400x300.png",
                    "review_rating": "4",
                    "review_title": "Lorem Ipsum",
                    "review_description": "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever s"
                },
                {
                    "product_name": "KESH KANTI MILK PROTEIN HAIR CLEANSER",
                    "weight": 8,
                    "unit": "gm",
                    "quantity": 10,
                    "product_price": 3,
                    "product_image": "https://www.patanjaliayurved.net/assets/product_images/400x300/KESHKANTIMILKPROTEINHAIRCLEANSER8ml400300.png",
                    "review_rating": "4",
                    "review_title": "",
                    "review_description": ""
                },
                {
                    "product_name": "KESH KANTI MILK PROTEIN",
                    "weight": 200,
                    "unit": "ml",
                    "quantity": 5,
                    "product_price": 100,
                    "product_image": "https://www.patanjaliayurved.net/assets/product_images/400x300/1505294632KESH%20KANTI%20MILK%20PROTEIN%20HAIR%20CLEANSER-%20400-300.png",
                    "review_rating": "",
                    "review_title": "",
                    "review_description": ""
                }
            ],
            "billing_address":{
            "name": "Sanjay Singh",
            "mobile": 9875424854,
            "alternatemobile": 9800000021,
            "address": "Patanjali Ayurved Limited Department ecommerce ",
            "landmark": "D-28 Industrial area Near Income Tax office",
            "city_name": "Haridwar",
            "state_name": "Uttarakhand",
            "zipcode": 249401,
            "type": "Home"
        }
        }');




        $this->response($orderdetails, REST_Controller::HTTP_OK);
    }

    public function removeWishlist_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $customer_id = $data['customer_id'];
        $token = $data['token'];
        $product_id = $data['product_id'];
        $response = array('status' => 1, 'message' => 'Product has been removed from your wishlist.');
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function getCardList_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $customer_id = $data['customer_id'];
        $token = $data['token'];
        $creditPointlist = json_decode('{
    "status": 1,
    "data": [
        {
            "card_id": 1,
            "bank_name": "State Bank of India",
            "card_number": "**** **** **** 1234"
        },
        {
            "card_id": 1,
            "bank_name": "Indusind Bank",
            "card_number": "**** **** **** 1234"
        },
        {
            "card_id": 1,
            "bank_name": "Indian Bank",
            "card_number": "**** **** **** 1234"
        }
    ]
}');

        $this->response($creditPointlist, REST_Controller::HTTP_OK);
    }

    public function removeCard_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $customer_id = $data['customer_id'];
        $token = $data['token'];
        $card_id = $data['card_id'];
        $response = array('status' => 1, 'message' => 'Card has been removed.');
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function couponList_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $customer_id = $data['customer_id'];
        $token = $data['token'];
        $couponlist = json_decode('{
    "status": 1,
    "data": [
        {
            "coupon_id": 1,
            "coupon_code": "test1",
            "coupon_remark": "Test"
        },
        {
            "coupon_id": 2,
            "coupon_code": "test2",
            "coupon_remark": "Test"
        },
        {
            "coupon_id": 3,
            "coupon_code": "test3",
            "coupon_remark": "Test"
        },
        {
            "coupon_id": 4,
            "coupon_code": "test4",
            "coupon_remark": "Test"
        }
    ]
}');

        $this->response($couponlist, REST_Controller::HTTP_OK);
    }

    public function creditPointList_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $customer_id = $data['customer_id'];
        $token = $data['token'];
        $creditPointlist = json_decode('{
    "status": 1,
    "data": [
        {
            "creditpoint_id": 1,
            "credit_point": "+20",
            "remark": "Test"
        },
        {
            "creditpoint_id": 4,
            "credit_point": "-10",
            "remark": "Test"
        },
        {
            "creditpoint_id": 8,
            "credit_point": "+50",
            "remark": "Test"
        },
        {
            "creditpoint_id": 15,
            "credit_point": "-12",
            "remark": "Test"
        }
    ]
}');

        $this->response($creditPointlist, REST_Controller::HTTP_OK);
    }

    public function getNotifiedproduct_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $customer_id = $data['customer_id'];
        $token = $data['token'];
        $productsarray = json_decode('[
        {
            "product_id": 958,
            "product_name": "ROASTED DIET-QUINOA PUFF -TOMATO FLAV 80 GM",
            "product_image": "https://www.patanjaliayurved.net/assets/product_images/400x500/1514268807PatanjaliQuinoaPuffTomatoFlavour400x500.png",
            "product_price": 75,
            "product_offer": "",
            "product_mrp": 0,
            "weight": 80,
            "unit": "gms",
            "available_qty": 458,
	    "in_wishlist": 1
        },
        {
            "product_id": 979,
            "product_name": "PATANJALI BALM",
            "product_image": "https://www.patanjaliayurved.net/assets/product_images/400x500/1514366303PATANJALIBALM10gm400x500.png",
            "product_price": 18,
            "product_offer": "",
            "product_mrp": 0,
            "weight": 10,
            "unit": "gms",
            "available_qty": 0,
	    "in_wishlist": 0
        },
        {
            "product_id": 960,
            "product_name": "ROASTED DIET-QUINOA-MASALA FLAV 80 GM",
            "product_image": "https://www.patanjaliayurved.net/assets/product_images/400x500/1514272015PatanjliQuinoaPuffMasalaFlavour400x500.png",
            "product_price": 75,
            "product_offer": "",
            "product_mrp": 0,
            "weight": 80,
            "unit": "gms",
            "available_qty": 0,
	    "in_wishlist": 0
        },
        {
            "product_id": 933,
            "product_name": "PATANJALI CREAMFEAST MILK VANILLA BISCUIT 84 GM",
            "product_image": "https://www.patanjaliayurved.net/assets/product_images/400x500/1515230708CreamfeastVanilla400x500.png",
            "product_price": 9,
            "product_offer": "10% OFF",
            "product_mrp": 10,
            "weight": 84,
            "unit": "gms",
            "available_qty": 395,
	    "in_wishlist": 0
        },
        {
            "product_id": 887,
            "product_name": "AASTHA CONE DHOOP (SANDAL)",
            "product_image": "https://www.patanjaliayurved.net/assets/product_images/400x500/Aastha%20Dhoop%20Sandal-400x500.png",
            "product_price": 15,
            "product_offer": "",
            "product_mrp": 0,
            "weight": 33,
            "unit": "GM",
            "available_qty": 423,
            "in_wishlist": 1
        },
        {
            "product_id": 955,
            "product_name": "ROASTED DIET-FLAXSEED CHILI LIME 150GM",
            "product_image": "https://www.patanjaliayurved.net/assets/product_images/400x500/1514268380PatanjaliFlaxseedChilliLime400x500.png",
            "product_price": 65,
            "product_offer": "",
            "product_mrp": 0,
            "weight": 150,
            "unit": "gms",
            "available_qty": 407,
	    "in_wishlist": 1			
        },
        {
            "product_id": 961,
            "product_name": "ROASTED DIET-ROASTED MIX. LIME 125 GM",
            "product_image": "https://www.patanjaliayurved.net/assets/product_images/400x500/1514272142RoastedMixtureLime400x500.png",
            "product_price": 55,
            "product_offer": "",
            "product_mrp": 0,
            "weight": 125,
            "unit": "gms",
            "available_qty": 423,
	    "in_wishlist": 0
        },
        {
            "product_id": 959,
            "product_name": "ROASTED DIET-RICE CRISPY MIXTURE 125 GM",
            "product_image": "https://www.patanjaliayurved.net/assets/product_images/400x500/1514271838PatanjaliRiceCrispyMixture400x500.png",
            "product_price": 35,
            "product_offer": "30% OFF",
            "product_mrp": 50,
            "weight": 125,
            "unit": "gms",
            "available_qty": 0,
	    "in_wishlist": 0
        },
        {
            "product_id": 956,
            "product_name": "ROASTED DIET-MELON & FLAXSEED 150 GM",
            "product_image": "https://www.patanjaliayurved.net/assets/product_images/400x500/1514268528PatanjaliMelonnFlaxseed400x500.png",
            "product_price": 80,
            "product_offer": "",
            "product_mrp": 0,
            "weight": 150,
            "unit": "gms",
            "available_qty": 380,
	    "in_wishlist": 1
        }
    ]');
        $response = array('status' => 1, 'data' => $productsarray);
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function removeNotifiedProduct_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $customer_id = $data['customer_id'];
        $token = $data['token'];
        $product_id = $data['product_id'];
        $response = array('status' => 1, 'message' => 'Product has been removed.');
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function notificationList_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $customer_id = $data['customer_id'];
        $token = $data['token'];
        $notificationlist = json_decode('{
    "status": 1,
    "data": [
        {
            "notification_id": 1,
            "notification": "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy",
            "date": "21-06-2019",
            "is_read":0
        },
        {
            "notification_id": 2,
            "notification": "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy",
            "date": "21-06-2019",
            "is_read":1
        },
        {
            "notification_id": 3,
            "notification": "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy",
            "date": "21-06-2019",
            "is_read":0
        },
        {
            "notification_id": 4,
            "notification": "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy",
            "date": "21-06-2019",
            "is_read":1
        }
    ]
}');
        $this->response($notificationlist, REST_Controller::HTTP_OK);
    }

    public function offerList_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $customer_id = $data['customer_id'];
        $token = $data['token'];
        $offerlist = json_decode('{
    "status": 1,
    "data": [
        {
            "offer_id": 1,
            "offer_title": "Lorem Ipsum is simply dummy dummy",
            "offer_description": "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy",
            "image": "https://www.patanjaliayurved.net/assets/home_slider/1560942249BannnerJuicesCombo.jpg"
        },
        {
            "offer_id": 2,
            "offer_title": "Lorem Ipsum is simply dummy dummy",
            "offer_description": "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy",
            "image": "https://www.patanjaliayurved.net/assets/home_slider/1560942249BannnerJuicesCombo.jpg"
        },
        {
            "offer_id": 3,
            "offer_title": "Lorem Ipsum is simply dummy dummy",
            "offer_description": "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy",
            "image": "https://www.patanjaliayurved.net/assets/home_slider/1560942249BannnerJuicesCombo.jpg"
        },
        {
            "offer_id": 4,
            "offer_title": "Lorem Ipsum is simply dummy dummy",
            "offer_description": "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy",
            "image": "https://www.patanjaliayurved.net/assets/home_slider/1560942249BannnerJuicesCombo.jpg"
        },
        {
            "offer_id": 5,
            "offer_title": "Lorem Ipsum is simply dummy dummy",
            "offer_description": "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy",
            "image": "https://www.patanjaliayurved.net/assets/home_slider/1560942249BannnerJuicesCombo.jpg"
        },
        {
            "offer_id": 6,
            "offer_title": "Lorem Ipsum is simply dummy dummy",
            "offer_description": "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy",
            "image": "https://www.patanjaliayurved.net/assets/home_slider/1560942249BannnerJuicesCombo.jpg"
        }
    ]
}');
        $this->response($offerlist, REST_Controller::HTTP_OK);
    }

    public function myReviewList_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $customer_id = $data['customer_id'];
        $token = $data['token'];
        $creditPointlist = json_decode('{
    "status": 1,
    "data": [
        {
            "review_id": 1,
            "review_rating": 4,
            "review_title": "Lorem Ipsum",
            "review_description": "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever s",
            "review_date": "19-06-209",
            "product_id": 10,
            "product_name": "Patanjali Ghee",
            "weight": 200,
            "unit": "gm",
            "product_image": "https://www.patanjaliayurved.net/assets/product_images/400x300/1514278053ghee200ml400x300.png"
        },
        {
            "review_id": 4,
            "review_rating": 4,
            "review_title": "Lorem Ipsum",
            "review_description": "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever s",
            "review_date": "19-06-209",
            "product_id": 10,
            "product_name": "Patanjali Ghee",
            "weight": 200,
            "unit": "gm",
            "product_image": "https://www.patanjaliayurved.net/assets/product_images/400x300/1514278053ghee200ml400x300.png"
        },
        {
            "review_id": 13,
            "review_rating": 4,
            "review_title": "Lorem Ipsum",
            "review_description": "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever s",
            "review_date": "19-06-209",
            "product_id": 10,
            "product_name": "Patanjali Ghee",
            "weight": 200,
            "unit": "gm",
            "product_image": "https://www.patanjaliayurved.net/assets/product_images/400x300/1514278053ghee200ml400x300.png"
        },
        {
            "review_id": 1112,
            "review_rating": 4,
            "review_title": "Lorem Ipsum",
            "review_description": "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever s",
            "review_date": "19-06-209",
            "product_id": 10,
            "product_name": "Patanjali Ghee",
            "weight": 200,
            "unit": "gm",
            "product_image": "https://www.patanjaliayurved.net/assets/product_images/400x300/1514278053ghee200ml400x300.png"
        }
    ]
}');

        $this->response($creditPointlist, REST_Controller::HTTP_OK);
    }
}
