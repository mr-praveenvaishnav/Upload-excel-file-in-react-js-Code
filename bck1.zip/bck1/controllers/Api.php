<?php

defined('BASEPATH') OR exit('No direct script access allowed');
// This can be removed if you use __autoload() in config.php OR use Modular Extensions
require APPPATH . '/libraries/REST_Controller.php';

/**
 * This is an example of a few basic user interaction methods you could use
 * all done with a hardcoded array
 *
 * @package         CodeIgniter
 * @subpackage      Rest Server
 * @category        Controller
 * @author          Phil Sturgeon, Chris Kacerguis
 * @license         MIT
 * @link            https://github.com/chriskacerguis/codeigniter-restserver
 */
class Api extends REST_Controller {

    var $profileimage = 'assets/uploads/profile/';

    function __construct() {
        header('Access-Control-Allow-Origin: *');
        header('Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE');
        parent::__construct();
        $this->load->model('App_model');
        $this->load->model('Order_model');
        $this->load->model('Admin_model');
    }

    public function index_get() {
        echo "test";
    }


    
    public function getAppSettings_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $type = $data['type'];
        $appsettings = $this->App_model->appSettings($type);
        $appsettingdetail = array(
            "id" => $appsettings->AppSettingId,
            "version" => $appsettings->Version,
            "message" => $appsettings->Message,
            "status" => $appsettings->Status
        );
        $response = array('status' => 1, 'data' => $appsettingdetail);
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function getHomeslider_post() {
        //$data = json_decode(file_get_contents('php://input'), true);
        $slider_images = $this->App_model->getSliderImages();
        if ($slider_images) {
            $sliderarray = array();
            foreach ($slider_images as $image) {
                $data = array('id' => $image->SliderId,
                    'image' => base_url() . 'assets/uploads/home_slider/' . $image->SliderImage,
                    'message' => "message"
                );
                array_push($sliderarray, $data);
            }
            $response = array("status" => 1, "data" => $sliderarray);
        } else {
            $response = array("status" => 0, "message" => "Not Available");
        }
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function getStates_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $customer_id = $data['customer_id'];
        $token = $data['token'];
        if (verifyToken($customer_id, $token)) {
            $all_states = $this->App_model->getStates();
            if ($all_states) {
                $response = array('status' => 1, 'data' => $all_states);
            } else {
                $response = array('status' => 0, 'message' => 'No Record found');
            }
        } else {
            $response = array('status' => 0, 'message' => 'Token mismatch');
        }
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function getCities_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $customer_id = $data['customer_id'];
        $token = $data['token'];
        $state_id = $data['state_id'];
        if (verifyToken($customer_id, $token)) {
            $cities = $this->App_model->getCities($state_id);
            if ($cities) {
                $response = array('status' => 1, 'data' => $cities);
            } else {
                $response = array('status' => 0, 'message' => 'No Record found');
            }
        } else {
            $response = array('status' => 0, 'message' => 'Token mismatch');
        }
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function blogCategoryList_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $category_id = $data['category_id'];
        if (!$category_id) {
            $category_id = 0;
        }
        $categorylist = $this->App_model->getBlogCategoryTree($category_id);
        if ($categorylist) {
            $response = array('status' => 1, 'data' => $categorylist);
        } else {
            $response = array('status' => 0, 'message' => 'Not Available');
        }
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function faqCategoryList_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $category_id = $data['category_id'];
        if (!$category_id) {
            $category_id = 0;
        }
        $categorylist = $this->App_model->getFAQCategoryTree($category_id);
        if ($categorylist) {
            $response = array('status' => 1, 'data' => $categorylist);
        } else {
            $response = array('status' => 0, 'message' => 'Not Available');
        }
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function faqList_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $faq_list = array();
        $category_id = $data['category_id'];
        $faq = $this->App_model->getFAQ($category_id);
        if ($faq) {
            foreach ($faq as $fq) {
                array_push($faq_list, array('faq_id' => $fq->FaqId,
                    'faq_question' => $fq->FaqQuestion,
                    'faq_answer' => $fq->FaqAnswer
                ));
            }
        }
        if ($faq_list) {
            $response = array('status' => 1, 'data' => $faq_list);
        } else {
            $response = array('status' => 0, 'message' => 'Not Available');
        }
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function faqListSearch_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $faq_list = array();
        $category_id = $data['category_id'];
        $search_text = $data['search_text'];
        $faq = $this->App_model->getFAQSearch($search_text, $category_id);
        if ($faq) {
            foreach ($faq as $fq) {
                array_push($faq_list, array('faq_id' => $fq->FaqId,
                    'faq_question' => $fq->FaqQuestion,
                    'faq_answer' => $fq->FaqAnswer
                ));
            }
        }
        if ($faq_list) {
            $response = array('status' => 1, 'data' => $faq_list);
        } else {
            $response = array('status' => 0, 'message' => 'Not Available');
        }
        $this->response($response, REST_Controller::HTTP_OK);
    }
    public function popularFaqList_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $faq_list = array();
        //$category_id = $data['category_id'];
        $faq = $this->App_model->getFAQ();
        if ($faq) {
            foreach ($faq as $fq) {
                array_push($faq_list, array('faq_id' => $fq->FaqId,
                    'faq_question' => $fq->FaqQuestion,
                    'faq_answer' => $fq->FaqAnswer
                ));
            }
        }
        if ($faq_list) {
            $response = array('status' => 1, 'data' => $faq_list);
        } else {
            $response = array('status' => 0, 'message' => 'Not Available');
        }
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function checkCoupon_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $customer_id = $data['customer_id'];
        $token = $data['token'];
        $coupon_code = $data['coupon_code'];
        if (verifyToken($customer_id, $token)) {
            $coupondetail = json_decode($this->App_model->applyCoupon($customer_id, $coupon_code));
            $response = $coupondetail;
        } else {
            $response = array('status' => 0, 'message' => 'Token mismatch');
        }
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function couponList_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $customer_id = $data['customer_id'];
        $token = $data['token'];
        $couponlist = array();
        if (verifyToken($customer_id, $token)) {
            $coupon_codes = $this->App_model->getCouponCode();
            if ($coupon_codes) {
                foreach ($coupon_codes as $coupon_code) {
                    array_push($couponlist, array("coupon_id" => $coupon_code->CouponId,
                        "coupon_code" => $coupon_code->CouponCode,
                        "discount_type" => $coupon_code->DiscountType,
                        "coupon_type" => $coupon_code->EvalType,
                        "expire_date" => $coupon_code->ToDate,
                        "coupon_remark" => $coupon_code->Description));
                }
                $response = array('status' => 1, 'data' => $couponlist, 'message' => 'Coupon List');
            } else {
                $response = array('status' => 0, 'message' => 'Not Available');
            }
        } else {
            $response = array('status' => 0, 'message' => 'Token mismatch');
        }
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function paymentModes_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $payment_type_list = array();
        $paymenttypes = $this->App_model->getPaymentTypes();
        if ($paymenttypes) {
            foreach ($paymenttypes as $paymenttype) {
                $payments = $this->App_model->getPaymentModes($paymenttype->PaymentTypeId);
                if ($payments) {
                    $payment_list = array();
                    foreach ($payments as $payment) {
                        array_push($payment_list, array('payment_mode_id' => $payment->PaymentModeId,
                            'payment_mode' => $payment->PaymentMode,
                            'payment_icon' => base_url() . 'assets/uploads/payment_icon/' . $payment->Image
                        ));
                    }
                }
                array_push($payment_type_list, array('payment_type_id' => $paymenttype->PaymentTypeId,
                    'payment_type' => $paymenttype->PaymentType,
                    'payment_mode' => $payment_list,
                ));
            }
        }
        if ($payment_type_list) {
            $response = array('status' => 1, 'data' => $payment_type_list);
        } else {
            $response = array('status' => 0, 'message' => 'Not Available');
        }
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function paymentOffers_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $payment_list = array();
        $payments = $this->App_model->getPaymentModes();
        if ($payments) {
            foreach ($payments as $payment) {
                array_push($payment_list, array(
                    'payment_mode_id' => $payment->PaymentModeId,
                    'offer_title' => $payment->OfferTitle,
                    'description' => $payment->Description
                ));
            }
        }
        if ($payment_list) {
            $response = array('status' => 1, 'data' => $payment_list);
        } else {
            $response = array('status' => 0, 'message' => 'Not Available');
        }
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function addSubscriber_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $customer_id = $data['customer_id'];
        $email = $data['email'];
        if ($email) {
            if ($this->App_model->checkSubscribedEmail($email)) {
                $emailarray = array('Email' => $email,
                    'CustomerId' => $customer_id,
                    'IsActive' => 1);
                $emailarraydata = $this->App_model->addSubscriber($emailarray);
                $response = array('status' => 1, 'message' => 'You are subscribed with our newsletter services');
            } else {
                $response = array('status' => 0, 'message' => 'You are already subscribed with this email address.');
            }
        } else {
            $response = array('status' => 0, 'message' => 'Please enter valid email');
        }
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function creditPointList_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $customer_id = $data['customer_id'];
        $token = $data['token'];
        $creditPointlist = json_decode('{
    "status": 1,
    "data": [
        {
            "creditpoint_id": 1,
            "credit_point": "+20",
            "remark": "Test"
        },
        {
            "creditpoint_id": 4,
            "credit_point": "-10",
            "remark": "Test"
        },
        {
            "creditpoint_id": 8,
            "credit_point": "+50",
            "remark": "Test"
        },
        {
            "creditpoint_id": 15,
            "credit_point": "-12",
            "remark": "Test"
        }
    ]
}');
        $this->response($creditPointlist, REST_Controller::HTTP_OK);
    }

    public function offerList_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $customer_id = $data['customer_id'];
        $token = $data['token'];
        $offerlist = json_decode('{
    "status": 1,
    "data": [
        {
            "offer_id": 1,
            "offer_title": "Lorem Ipsum is simply dummy dummy",
            "offer_description": "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy",
            "image": "https://www.patanjaliayurved.net/assets/home_slider/1560942249BannnerJuicesCombo.jpg"
        },
        {
            "offer_id": 2,
            "offer_title": "Lorem Ipsum is simply dummy dummy",
            "offer_description": "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy",
            "image": "https://www.patanjaliayurved.net/assets/home_slider/1560942249BannnerJuicesCombo.jpg"
        },
        {
            "offer_id": 3,
            "offer_title": "Lorem Ipsum is simply dummy dummy",
            "offer_description": "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy",
            "image": "https://www.patanjaliayurved.net/assets/home_slider/1560942249BannnerJuicesCombo.jpg"
        },
        {
            "offer_id": 4,
            "offer_title": "Lorem Ipsum is simply dummy dummy",
            "offer_description": "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy",
            "image": "https://www.patanjaliayurved.net/assets/home_slider/1560942249BannnerJuicesCombo.jpg"
        },
        {
            "offer_id": 5,
            "offer_title": "Lorem Ipsum is simply dummy dummy",
            "offer_description": "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy",
            "image": "https://www.patanjaliayurved.net/assets/home_slider/1560942249BannnerJuicesCombo.jpg"
        },
        {
            "offer_id": 6,
            "offer_title": "Lorem Ipsum is simply dummy dummy",
            "offer_description": "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy",
            "image": "https://www.patanjaliayurved.net/assets/home_slider/1560942249BannnerJuicesCombo.jpg"
        }
    ]
}');
        $this->response($offerlist, REST_Controller::HTTP_OK);
    }

}
