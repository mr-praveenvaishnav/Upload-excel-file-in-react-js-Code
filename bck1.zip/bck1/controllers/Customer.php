<?php

defined('BASEPATH') OR exit('No direct script access allowed');

require APPPATH . '/libraries/REST_Controller.php';

class Customer extends REST_Controller {

    var $productimage = 'assets/uploads/product_images/';
    var $profileimage = 'assets/uploads/profile/';

    function __construct() {
        header('Access-Control-Allow-Origin: *');
        header('Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE');
        parent::__construct();
        $this->load->model('Customer_model');
        $this->load->model('App_model');
    }

    public function index_get() {
        echo "test";
    }
    public function logins_post() {
        $data = json_decode(file_get_contents('php://input'), true);
      $customerdetailarray = array();
        $UserId = $data['UserName'];
        $password = $data['Password'];
               $check = $this->Customer_model->Adminlogin($UserId, $password);
            
                if ($check == 1) {
               $datas = $this->Customer_model->postLoginUser($UserId, $password);
            //   echo print_r($datas);
            //       echo print_r($check->IsActive);
            //       echo print_r($check['IsActive']);
            //   die;
                //    array.push( $customerdetailarray, array(
                //             'AdminId' => $datas->AdminId,
                //             'UserId' => $datas->UserId, 
                //             'AdminId' => $datas->AdminId ,
                //             'IsActive' => $datas->IsActive ,
                //             ));
                           $response = array('status' => 1,
                            'data' => $datas, 
                            "message" => "You have successfully logged in.");
                      }  
            
         else {
            $response = array('status' => 0, 
            "message" => "please check login details");
     }
     $this->response($response, REST_Controller::HTTP_OK);
}
    public function register_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $mobile = $data['mobile'];
        $checkMobile = $this->Customer_model->checkMobile($mobile);
        if (!$checkMobile) {
            $token = token();
            $otp = otp();
            $customerinfo = array(
                'Mobile' => $mobile,
                'IsAppRegistered' => 1,
                'OTP' => $otp
            );
            $customer_id = $this->Customer_model->tmpRegister($customerinfo);
            if ($customer_id) {
//                $sms_message = 'Your one time password for Patanjali is ' . $otp . '. Treat this as confidential and do not share with anyone.';
//                $this->sms->send_sms($mobilenumber, $sms_message);
                $customerdetailarray = array();
                array_push($customerdetailarray, array('customer_id' => $customer_id));
                $response = array('status' => 1, 'data' => $customerdetailarray, 'message' => 'OTP sent to registered number.');
            } else {
                $response = array('status' => 0, 'message' => 'Error in processing your request.');
            }
        } else {
            $response = array('status' => 0, 'message' => 'Mobile No. already exists');
        }
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function resendOtp_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $mobile = $data['mobile'];
        $checkmobile = $this->Customer_model->checkMobile($mobile);
        if ($checkmobile) {
            $otp = otp();
//          $sms_message = 'Your one time password for Patanjali is ' . $otp . '. Treat this as confidential and do not share with anyone.';
//          $this->sms->send_sms($mobile, $sms_message);
            $customerinfo = array(
                'OTP' => $otp,
                'LastModifiedBy' => $checkmobile->CustomerId
            );
            $this->Customer_model->updateCustomerInfo($checkmobile->CustomerId, $customerinfo);
            $customerdetailarray = array();
            array_push($customerdetailarray, array('customer_id' => $checkmobile->CustomerId));
            $response = array('status' => 1, 'data' => $customerdetailarray, 'message' => 'OTP sent to registered number.');
        } else {
            $checkmobile = $this->Customer_model->checkTmpMobile($mobile);
            if ($checkmobile) {
                $otp = otp();
//          $sms_message = 'Your one time password for Patanjali is ' . $otp . '. Treat this as confidential and do not share with anyone.';
//          $this->sms->send_sms($mobile, $sms_message);
                $customerinfo = array(
                    'OTP' => $otp
                );
                $this->Customer_model->updateTmpCustomerInfo($checkmobile->CustomerId, $customerinfo);
                $customerdetailarray = array();
                array_push($customerdetailarray, array('customer_id' => $checkmobile->CustomerId));
                $response = array('status' => 1, 'data' => $customerdetailarray, 'message' => 'OTP sent to registered number.');
            } else {
                $response = array('status' => 0, "message" => "This mobile number is not registered with us.");
            }
        }
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function verifyOtp_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $mobile = $data['mobile'];
        $otp = $data['otp'];
        $customer_id = $data['customer_id'];
        $checkmobile = $this->Customer_model->checkTmpMobile($mobile);
        if ($checkmobile) {
            if ($customer_id == $checkmobile->CustomerId) {
                if ($otp == $checkmobile->OTP) {
                    $customerdetailarray = array();
                    $token = token();
                    $otp = otp();
                    $customerinfo = array(
                        'Name' => $checkmobile->Name,
                        'Mobile' => $checkmobile->Mobile,
                        'Gender' => $checkmobile->Gender,
                        'SocialType' => $checkmobile->SocialType,
                        'SocialId' => $checkmobile->SocialId,
                        'CustomerGroupId' => 1,
                        'IsAppRegistered' => 1,
                        'IsActive' => 1,
                        'Token' => $token,
                        'IsMobileVerified' => 1
                    );
                    $customer_id = $this->Customer_model->register($customerinfo);
                    array_push($customerdetailarray, array('customer_id' => $customer_id, 'token' => $token));
                    $response = array('status' => 1, 'data' => $customerdetailarray, 'message' => 'You are registered successfully.');
                } else {
                    $response = array('status' => 0, "message" => "Invalid otp");
                }
            } else {
                $response = array('status' => 0, "message" => "Invalid mobile no. and customer id");
            }
        } else {
            $response = array('status' => 0, "message" => "This mobile number is not registered with us.");
        }
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function setPassword_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $customerdetailarray = array();
        $customer_id = $data['customer_id'];
        $token = $data['token'];
        $password = $data['password'];
        if (verifyToken($customer_id, $token)) {
            $changepasswordarray = array('Password' => sha1($password),
                'LastModifiedBy' => $customer_id);
            $updatepassword = $this->Customer_model->updateCustomerInfo($customer_id, $changepasswordarray);
            $customerdetail = $this->Customer_model->getCustomerDetails($customer_id);
            array_push($customerdetailarray, array('customer_id' => $customerdetail->CustomerId, 'name' => $customerdetail->Name, 'email' => $customerdetail->Email, 'mobile' => $customerdetail->Mobile, 'alternatemobile' => $customerdetail->AlternateMobileNo, "gender" => $customerdetail->Gender, 'profile_image' => base_url() . 'assets/uploads/profile/' . $customerdetail->ProfilePic, 'token' => $token));
            $response = array('status' => 1, 'data' => $customerdetailarray, 'message' => 'Password set successfully.');
        } else {
            $response = array('status' => 0, 'message' => 'Token mismatch');
        }
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function login_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $customerdetailarray = array();
        $mobile = $data['mobile'];
        $password = $data['password'];
        $checkmobile = $this->Customer_model->checkMobile($mobile);
        if ($checkmobile) {
            if ($checkmobile->IsActive == 0) {
                $response = array('status' => 0, 'message' => 'Your account has been deactivated');
            } else {
                $check = $this->Customer_model->checkLoginAttempt($checkmobile->CustomerId);
                if ($check == 0) {
                    $customerdetail = $this->Customer_model->login($mobile, $password);
                    if ($customerdetail) {
                        $token = token();
                        $customerinfo = array(
                            'Token' => $token,
                            'LastModifiedBy' => $customerdetail->CustomerId
                        );
                        $this->Customer_model->updateCustomerInfo($customerdetail->CustomerId, $customerinfo);
                        if ($customerdetail->IsMobileVerified == 1) {
                            array_push($customerdetailarray, array('customer_id' => $customerdetail->CustomerId, 'name' => $customerdetail->Name, 'email' => $customerdetail->Email, 'mobile' => $customerdetail->Mobile, 'alternatemobile' => $customerdetail->AlternateMobileNo, "gender" => $customerdetail->Gender, 'profile_image' => base_url() . 'assets/uploads/profile/' . $customerdetail->ProfilePic, 'token' => $token));
                            $response = array('status' => 1, 'data' => $customerdetailarray, "message" => "You have successfully logged in.");
                        } else {
                            array_push($customerdetailarray, array('customer_id' => $customerdetail->CustomerId, 'name' => $customerdetail->Name, 'email' => $customerdetail->Email, 'mobile' => $customerdetail->Mobile, 'alternatemobile' => $customerdetail->AlternateMobileNo, "gender" => $customerdetail->Gender, 'profile_image' => base_url() . 'assets/uploads/profile/' . $customerdetail->ProfilePic, 'token' => $token));
                            $otp = otp();
//                    $sms_message = 'Your one time password for Patanjali is ' . $otp . '. Treat this as confidential and do not share with anyone.';
//                    $this->sms->send_sms($customerdetail->mobile, $sms_message);
                            $customerinfo = array(
                                'OTP' => $otp,
                                'LastModifiedBy' => $customerdetail->CustomerId
                            );
                            $this->Customer_model->updateCustomerInfo($customerdetail->CustomerId, $customerinfo);
                            $response = array('status' => 2, 'data' => $customerdetailarray, "message" => "Otp has been sent to your mobile , verify your account.");
                        }
                    } else {
                        $this->Customer_model->addLoginAttempt($checkmobile->CustomerId);
                        $response = array('status' => 0, 'message' => 'Invalid Mobile or Password');
                    }
                } else {
                    $response = array('status' => 0, 'message' => 'Access Denied for 10 minutes');
                }
            }
        } else {
            $response = array('status' => 0, "message" => "This mobile number is not registered with us.");
        }
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function forgotPassword_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $mobile = $data['mobile'];
        $checkmobile = $this->Customer_model->checkMobile($mobile);
        if ($checkmobile) {
            $otp = otp();
//          $sms_message = 'Your one time password for Patanjali is ' . $otp . '. Treat this as confidential and do not share with anyone.';
//          $this->sms->send_sms($mobile, $sms_message);
            $customerinfo = array(
                'OTP' => $otp,
                'LastModifiedBy' => $checkmobile->CustomerId
            );
            $this->Customer_model->updateCustomerInfo($checkmobile->CustomerId, $customerinfo);
            $customerdetailarray = array();
            array_push($customerdetailarray, array('customer_id' => $checkmobile->CustomerId));
            $response = array('status' => 1, 'data' => $customerdetailarray, 'message' => 'OTP sent to registered number.');
        } else {
            $response = array('status' => 0, "message" => "This mobile number is not registered with us.");
        }
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function forgotPasswordVerifyOtp_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $mobile = $data['mobile'];
        $otp = $data['otp'];
        $customer_id = $data['customer_id'];
        $checkmobile = $this->Customer_model->checkMobile($mobile);
        if ($checkmobile && $customer_id == $checkmobile->CustomerId) {
            if ($otp == $checkmobile->OTP) {
                $customerdetailarray = array();
                $token = $checkmobile->Token;
                array_push($customerdetailarray, array('customer_id' => $checkmobile->CustomerId, "token" => $token));
                $response = array('status' => 1, 'data' => $customerdetailarray);
            } else {
                $response = array('status' => 0, "message" => "Invalid otp");
            }
        } else {
            $response = array('status' => 0, "message" => "This mobile number is not registered with us.");
        }
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function resetPassword_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $customer_id = $data['customer_id'];
        $token = $data['token'];
        $password = $data['password'];
        if (verifyToken($customer_id, $token)) {
            $changepasswordarray = array('Password' => sha1($password),
                'LastModifiedBy' => $customer_id);
            $updatepassword = $this->Customer_model->updateCustomerInfo($customer_id, $changepasswordarray);
            $response = array('status' => 1, 'message' => 'Password reset successfully.');
        } else {
            $response = array('status' => 0, 'message' => 'Token mismatch');
        }
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function changePassword_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $customer_id = $data['customer_id'];
        $token = $data['token'];
        $password = $data['password'];
        $current_password = $data['current_password'];
        if (verifyToken($customer_id, $token)) {
            $userDetail = $this->Customer_model->getCustomerDetails($customer_id);
            if ($userDetail->Password == sha1($current_password)) {
                $changepasswordarray = array('Password' => sha1($password),
                    'LastModifiedBy' => $customer_id);
                $updatepassword = $this->Customer_model->updateCustomerInfo($customer_id, $changepasswordarray);
                $response = array('status' => 1, 'message' => 'Your password has been changed successfully.');
            } else {
                $response = array('status' => 0, 'message' => 'Current password does not matched.');
            }
        } else {
            $response = array('status' => 0, 'message' => 'Token mismatch');
        }
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function checkMobile_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $mobile = $data['mobile'];
        $status = $this->Customer_model->checkMobile($mobile);
        if (!$status) {
            $response = array('status' => 1);
        } else {
            $response = array('status' => 0, 'message' => 'Mobile No. already exists');
        }
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function checkEmail_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $email = $data['email'];
        $status = $this->Customer_model->checkEmail($email);
        if (!$status) {
            $response = array('status' => 1);
        } else {
            $response = array('status' => 0, 'message' => 'Email address already exists');
        }
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function editProfile_post() {
        $data = $_POST; //json_decode(file_get_contents('php://input'), true);
        $customerdetailarray = array();
        $customer_id = $data['customer_id'];
        $token = $data['token'];
        $name = $data['name'];
        //$mobile = $data['mobile'];
        $alternatemobile = $data['alternatemobile'];
        $gender = $data['gender'];
        $email = $data['email'];
        $checkToken = $this->Customer_model->getCustomerDetails($customer_id);
        if ($checkToken->Token == $token && $token) {
            //$checkMobile = $this->Customer_model->checkMobile($mobile, $customer_id);
            //if (!$checkMobile) {
            $checkEmail = $this->Customer_model->checkEmail($email, $customer_id);
            if (!$checkEmail or $email == "") {
                $customerinfo = array(
                    'Name' => $name,
                    //'Mobile' => $mobile,
                    'Email' => $email,
                    'AlternateMobileNo' => $alternatemobile,
                    'Gender' => $gender,
                    'LastModifiedBy' => $customer_id
                );
                $profile_image = image_upload("profile_image", "assets/uploads/profile/");
                if ($profile_image) {
                    $customerinfo['ProfilePic'] = $profile_image;
                }
                $customer = $this->Customer_model->updateCustomerInfo($customer_id, $customerinfo);
                $customerdetail = $this->Customer_model->getCustomerDetails($customer_id);
                array_push($customerdetailarray, array('customer_id' => $customerdetail->CustomerId, 'name' => $customerdetail->Name, 'email' => $customerdetail->Email, 'mobile' => $customerdetail->Mobile, 'alternatemobile' => $customerdetail->AlternateMobileNo, "gender" => $customerdetail->Gender, 'profile_image' => base_url() . 'assets/uploads/profile/' . $customerdetail->ProfilePic));
                $response = array('status' => 1, 'data' => $customerdetailarray, "message" => "Profile updated successfully");
            } else {
                $response = array('status' => 0, 'message' => 'Email Address already exists');
            }
            //} else {
            //    $response = array('status' => 0, 'message' => 'Mobile No. already exists');
            //}
        } else {
            $response = array('status' => 0, 'message' => 'Token mismatch');
        }
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function getCustomerDetail_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $customerdetailarray = array();
        $customer_id = $data['customer_id'];
        $token = $data['token'];
        $customerdetail = $this->Customer_model->getCustomerDetails($customer_id);
        if ($customerdetail->Token == $token && $token) {
            array_push($customerdetailarray, array('customer_id' => $customerdetail->CustomerId, 'name' => $customerdetail->Name, 'email' => $customerdetail->Email, 'mobile' => $customerdetail->Mobile, 'alternatemobile' => $customerdetail->AlternateMobileNo, "gender" => $customerdetail->Gender, 'profile_image' => base_url() . 'assets/uploads/profile/' . $customerdetail->ProfilePic));
            $response = array('status' => 1, 'data' => $customerdetailarray);
        } else {
            $response = array('status' => 0, 'message' => 'Token mismatch');
        }
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function getWishlist_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $customer_id = $data['customer_id'];
        $token = $data['token'];
        $limit = @$data['limit'];
        $page = @$data['page'];
        if (verifyToken($customer_id, $token)) {
            $productarray = array();
            $sort_column = "w.CreatedDate";
            $sort_order = "desc";
            $limit_start = ($page * $limit) - $limit;
            if ($limit_start < 0) {
                $limit_start = 0;
            }
            $wishlistproducts = $this->Customer_model->getWishlistItems($customer_id, $limit, $limit_start, $sort_column, $sort_order);
            if ($wishlistproducts) {
                foreach ($wishlistproducts as $product) {
                    $getOfferPrice = getOfferPrice($product, $customer_id);
                    unset($getOfferPrice["product_varients"]);
                    array_push($productarray, $getOfferPrice);
                }
                $response = array('status' => 1, 'data' => $productarray);
            } else {
                $response = array('status' => 0, 'message' => 'There are no products in your wishlist.');
            }
        } else {
            $response = array('status' => 0, 'message' => 'Token mismatch');
        }
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function getNotifyProduct_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $customer_id = $data['customer_id'];
        $token = $data['token'];
        $limit = @$data['limit'];
        $page = @$data['page'];
        if (verifyToken($customer_id, $token)) {
            $productarray = array();
            $sort_column = "np.CreatedDate";
            $sort_order = "desc";
            $limit_start = ($page * $limit) - $limit;
            if ($limit_start < 0) {
                $limit_start = 0;
            }
            $notifyproducts = $this->Customer_model->getNotifyItems($customer_id, $limit, $limit_start, $sort_column, $sort_order);
            if ($notifyproducts) {
                foreach ($notifyproducts as $product) {
                    //$productarray1 =array();                
                    $getOfferPrice = getOfferPrice($product, $customer_id);
                    unset($getOfferPrice["product_varients"]);
                    array_push($productarray, $getOfferPrice);
                    //array_push($productarray, array_merge($getOfferPrice,$productarray1));
                }
                $response = array('status' => 1, 'data' => $productarray);
            } else {
                $response = array('status' => 0, 'message' => 'There are no products in your notify list.');
            }
            $this->response($response, REST_Controller::HTTP_OK);
        }
    }

    public function addAddress_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $customer_id = $data['customer_id'];
        $name = $data['name'];
        $address = $data['address'];
        $landmark = $data['landmark'];
        $city_id = $data['city_id'];
        $state_id = $data['state_id'];
        $country_id = 1;
        $pincode = $data['pincode'];
        $mobile = $data['mobile'];
        $AlternatMobileNo = $data['alternat_mobile_no'];
        $address_type = $data['address_type'];
        $IsDefault = $data['isdefault'];
        $token = $data['token'];
        if (verifyToken($customer_id, $token)) {
            $if_exist = $this->Customer_model->getAddresses($customer_id);
            if (!$if_exist) {
                $IsDefault = 1;
                $cust_addr = array(
                    "CustomerId" => $customer_id,
                    "Name" => $name,
                    "Address" => $address,
                    "Landmark" => $landmark,
                    "CityId" => $city_id,
                    "StateId" => $state_id,
                    "CountryId" => $country_id,
                    "PinCode" => $pincode,
                    "Mobile" => $mobile,
                    "AlternatMobileNo" => $AlternatMobileNo,
                    "AddressType" => $address_type,
                    "IsDefault" => 0,
                    "IsBillingAddress" => 1,
                    "IsActive" => 1
                );
                $result = $this->Customer_model->addAddress($cust_addr);
            } else {
                if ($IsDefault == 1) {
                    $update_isDefault = array(
                        "IsDefault" => 0
                    );
                    $this->Customer_model->editCustomerAddressByCustomerId($update_isDefault, $customer_id);
                }
            }
            $cust_addr = array(
                "CustomerId" => $customer_id,
                "Name" => $name,
                "Address" => $address,
                "Landmark" => $landmark,
                "CityId" => $city_id,
                "StateId" => $state_id,
                "CountryId" => $country_id,
                "PinCode" => $pincode,
                "Mobile" => $mobile,
                "AlternatMobileNo" => $AlternatMobileNo,
                "AddressType" => $address_type,
                "IsDefault" => $IsDefault,
                "IsBillingAddress" => 0,
                "IsActive" => 1,
            );
            $result = $this->Customer_model->addAddress($cust_addr);
            if ($result) {
                $response = array('status' => 1, 'message' => 'Successfully added');
            } else {
                $response = array('status' => 0, 'message' => 'Error occurred. Try again later');
            }
        } else {
            $response = array('status' => 0, 'message' => 'Token mismatch');
        }
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function getShippingAddresses_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $shippingaddresslist = array();
        $customer_id = $data['customer_id'];
        $token = $data['token'];
        if (verifyToken($customer_id, $token)) {
            $shipping_address = $this->Customer_model->getShippingAddresses($customer_id);
            if ($shipping_address) {
                foreach ($shipping_address as $address) {
                    $statedetail = $this->App_model->getStateById($address->StateId);
                    $citydetail = $this->App_model->getCityById($address->CityId);
                    if ($citydetail) {
                        $city_name = $citydetail->CityName;
                    } else {
                        $city_name = "";
                    }
                    if ($statedetail) {
                        $state_name = $statedetail->StateName;
                    } else {
                        $state_name = "";
                    }
                    array_push($shippingaddresslist, array(
                        'address_id' => $address->CustomerAddressId,
                        'name' => $address->Name,
                        'address' => $address->Address,
                        'landmark' => $address->Landmark,
                        'city_id' => $address->CityId,
                        'city_name' => $city_name,
                        'state_id' => $address->StateId,
                        'state_name' => $state_name,
                        'pincode' => $address->PinCode,
                        'mobile' => $address->Mobile,
                        'alternat_mobile_no' => $address->AlternatMobileNo,
                        'address_type' => $address->AddressType,
                        'isdefault' => $address->IsDefault
                    ));
                }
                $response = array('status' => 1, 'data' => $shippingaddresslist);
            } else {
                $response = array('status' => 0, 'message' => 'No Record found');
            }
        } else {
            $response = array('status' => 0, 'message' => 'Token mismatch');
        }
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function getShippingAddressById_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $shippingaddresslist = array();
        $customer_id = $data['customer_id'];
        $address_id = $data['address_id'];
        $token = $data['token'];
        if (verifyToken($customer_id, $token)) {
            $address = $this->Customer_model->getAddressesById($address_id);
            if ($address) {
                $statedetail = $this->App_model->getStateById($address->StateId);
                $citydetail = $this->App_model->getCityById($address->CityId);
                if ($citydetail) {
                    $city_name = $citydetail->CityName;
                } else {
                    $city_name = "";
                }
                if ($statedetail) {
                    $state_name = $statedetail->StateName;
                } else {
                    $state_name = "";
                }
                array_push($shippingaddresslist, array(
                    'address_id' => $address->CustomerAddressId,
                    'name' => $address->Name,
                    'address' => $address->Address,
                    'landmark' => $address->Landmark,
                    'city_id' => $address->CityId,
                    'city_name' => $city_name,
                    'state_id' => $address->StateId,
                    'state_name' => $state_name,
                    'pincode' => $address->PinCode,
                    'mobile' => $address->Mobile,
                    'alternat_mobile_no' => $address->AlternatMobileNo,
                    'address_type' => $address->AddressType,
                    'isdefault' => $address->IsDefault
                ));
                $response = array('status' => 1, 'data' => $shippingaddresslist);
            } else {
                $response = array('status' => 0, 'message' => 'No Record found');
            }
        } else {
            $response = array('status' => 0, 'message' => 'Token mismatch');
        }
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function getBillingAddress_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $shippingaddresslist = array();
        $customer_id = $data['customer_id'];
        $token = $data['token'];
        if (verifyToken($customer_id, $token)) {
            $address = $this->Customer_model->getBillingAddress($customer_id);
            if ($address) {
                $statedetail = $this->App_model->getStateById($address->StateId);
                $citydetail = $this->App_model->getCityById($address->CityId);
                if ($citydetail) {
                    $city_name = $citydetail->CityName;
                } else {
                    $city_name = "";
                }
                if ($statedetail) {
                    $state_name = $statedetail->StateName;
                } else {
                    $state_name = "";
                }
                array_push($shippingaddresslist, array(
                    'address_id' => $address->CustomerAddressId,
                    'name' => $address->Name,
                    'address' => $address->Address,
                    'landmark' => $address->Landmark,
                    'city_id' => $address->CityId,
                    'city_name' => $city_name,
                    'state_id' => $address->StateId,
                    'state_name' => $state_name,
                    'pincode' => $address->PinCode,
                    'mobile' => $address->Mobile,
                    'alternat_mobile_no' => $address->AlternatMobileNo,
                    'address_type' => $address->AddressType
                ));
                $response = array('status' => 1, 'data' => $shippingaddresslist);
            } else {
                $response = array('status' => 0, 'message' => 'No Record found');
            }
        } else {
            $response = array('status' => 0, 'message' => 'Token mismatch');
        }
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function makeDefaultAddress_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $customer_id = $data['customer_id'];
        $token = $data['token'];
        $address_id = $data['address_id'];
        if (verifyToken($customer_id, $token)) {
            $update_isDefault = array(
                "IsDefault" => 0
            );
            $update = $this->Customer_model->editCustomerAddressByCustomerId($update_isDefault, $customer_id);
            if ($update) {
                $default = array(
                    "IsDefault" => 1
                );
                $update = $this->Customer_model->editCustomerAddress($default, $address_id);
                if ($update) {
                    $response = array('status' => 1, 'message' => 'successfully changed');
                }else {
                $response = array('status' => 0, 'message' => 'Error occurred. Try again later');
            }
            } else {
                $response = array('status' => 0, 'message' => 'Error occurred. Try again later');
            }
        } else {
            $response = array('status' => 0, 'message' => 'Token mismatch');
        }
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function updateShippingAddress_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $customer_id = $data['customer_id'];
        $name = $data['name'];
        $address = $data['address'];
        $landmark = $data['landmark'];
        $city_id = $data['city_id'];
        $state_id = $data['state_id'];
        $country_id = 1;
        $pincode = $data['pincode'];
        $mobile = $data['mobile'];
        $AlternatMobileNo = $data['alternat_mobile_no'];
        $address_type = $data['address_type'];
        $IsDefault = $data['Isdefault'];
        $token = $data['token'];
        $address_id = $data['address_id'];
        if (verifyToken($customer_id, $token)) {
            if ($IsDefault == 1) {
                $update_isDefault = array(
                    "IsDefault" => 0
                );
                $this->Customer_model->editCustomerAddressByCustomerId($update_isDefault, $customer_id);
            }
            $cust_addr = array(
                "Name" => $name,
                "Address" => $address,
                "Landmark" => $landmark,
                "CityId" => $city_id,
                "StateId" => $state_id,
                "CountryId" => $country_id,
                "PinCode" => $pincode,
                "Mobile" => $mobile,
                "AlternatMobileNo" => $AlternatMobileNo,
                "AddressType" => $address_type,
                "IsDefault" => $IsDefault,
            );
            $result = $this->Customer_model->editCustomerAddress($cust_addr, $address_id);
            if ($result) {
                $response = array('status' => 1, 'message' => 'Successfully updated');
            } else {
                $response = array('status' => 0, 'message' => 'Error occurred. Try again later');
            }
        } else {
            $response = array('status' => 0, 'message' => 'Token mismatch');
        }
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function updateBillingAddress_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $customer_id = $data['customer_id'];
        $name = $data['name'];
        $address = $data['address'];
        $landmark = $data['landmark'];
        $city_id = $data['city_id'];
        $state_id = $data['state_id'];
        $country_id = 1;
        $pincode = $data['pincode'];
        $mobile = $data['mobile'];
        $AlternatMobileNo = $data['alternat_mobile_no'];
        $address_type = $data['address_type'];
        $token = $data['token'];
        $address_id = $data['address_id'];
        if (verifyToken($customer_id, $token)) {
            $cust_addr = array(
                "Name" => $name,
                "Address" => $address,
                "Landmark" => $landmark,
                "CityId" => $city_id,
                "StateId" => $state_id,
                "CountryId" => $country_id,
                "PinCode" => $pincode,
                "Mobile" => $mobile,
                "AlternatMobileNo" => $AlternatMobileNo,
                "AddressType" => $address_type
            );
            $result = $this->Customer_model->editCustomerAddress($cust_addr, $address_id);
            if ($result) {
                $response = array('status' => 1, 'message' => 'Successfully updated');
            } else {
                $response = array('status' => 0, 'message' => 'Error occurred. Try again later');
            }
        } else {
            $response = array('status' => 0, 'message' => 'Token mismatch');
        }

        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function deleteAddress_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $customer_id = $data['customer_id'];
        $token = $data['token'];
        $address_id = $data['address_id'];
        if (verifyToken($customer_id, $token)) {
            $cust_addr = array(
                "IsActive" => 0,
            );
            $result = $this->Customer_model->editCustomerAddress($cust_addr, $address_id);
            if ($result) {
                $response = array('status' => 1, 'message' => 'Successfully deleted');
            } else {
                $response = array('status' => 0, 'message' => 'Error occurred. Try again later');
            }
        } else {
            $response = array('status' => 0, 'message' => 'Token mismatch');
        }
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function myReview_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $customer_id = $data['customer_id'];
        $token = $data['token'];
        $limit = @$data['limit'];
        $page = @$data['page'];
        if (verifyToken($customer_id, $token)) {
            $reviewlist = array();
            $sort_column = "pr.CreatedDate";
            $sort_order = "desc";
            $limit_start = ($page * $limit) - $limit;
            if ($limit_start < 0) {
                $limit_start = 0;
            }
            $reviewdetails = $this->Customer_model->getCustomerReviews($customer_id, $limit, $limit_start, $sort_column, $sort_order);
            if ($reviewdetails) {
                foreach ($reviewdetails as $review) {
                    $review_image = "";
                    $product_image = "";
                    if ($review->ReviewImage) {
                        $review_image = base_url() . 'assets/uploads/product_review/' . $review->ReviewImage;
                    }
                    if ($review->ProductImageName) {
                        $product_image = base_url() . 'assets/uploads/product_images/' . $review->ProductImageName;
                    }
                    array_push($reviewlist, array('review_id' => $review->ReviewId, 'review_product_id' => $review->ProductId, 'product_name' => $review->ProductName, 'review_title' => $review->ReviewTitle, 'review_description' => $review->ReviewDescription, 'rating_star' => $review->Rating, 'review_image' => $review_image, 'is_verified' => $review->IsVerified, 'product_image' => $product_image, 'date' => $review->rdate));
                }
                $response = array('status' => 1, 'data' => $reviewlist);
            } else {
                $response = array('status' => 0, 'message' => 'Not Available');
            }
        } else {
            $response = array('status' => 0, 'message' => 'Token mismatch');
        }
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function notificationList_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $notificationlist = array();
        $customer_id = $data['customer_id'];
        $token = $data['token'];
        $limit = @$data['limit'];
        $page = @$data['page'];
        if (verifyToken($customer_id, $token)) {
            $sort_column = "CreatedDate";
            $sort_order = "desc";
            $limit_start = ($page * $limit) - $limit;
            if ($limit_start < 0) {
                $limit_start = 0;
            }
            $notifications = $this->Customer_model->getNotifications($customer_id, $limit, $limit_start, $sort_column, $sort_order);
            if ($notifications) {
                foreach ($notifications as $notification) {
                    array_push($notificationlist, array('notification_id' => $notification->NotificationId,
                        'notification' => $notification->Description,
                        'date' => formatDate($notification->CreatedDate),
                        'is_read' => $notification->IsRead
                    ));
                }
            }
            if ($notificationlist) {
                $response = array('status' => 1, 'data' => $notificationlist);
            } else {
                $response = array('status' => 0, 'message' => 'Not Available');
            }
        } else {
            $response = array('status' => 0, 'message' => 'Token mismatch');
        }
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function readNotification_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $customer_id = $data['customer_id'];
        $token = $data['token'];
        if (verifyToken($customer_id, $token)) {
            $notification_id = $data['notification_id'];
            $value = array("IsRead" => 1);
            $this->Customer_model->updateNotification($notification_id, $value);
            $response = array("status" => 1, 'message' => "success");
        } else {
            $response = array('status' => 0, 'message' => 'Token mismatch');
        }
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function socialLogin_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $customerdetailarray = array();
        $social_id = $data['social_id'];
        $social_type = $data['social_type'];
        $customerdetail = $this->Customer_model->checkSocialLogin($social_type, $social_id);
        if ($customerdetail) {
            if ($customerdetail->IsActive == 0) {
                $response = array('status' => 0, 'message' => 'Your account has been deactivated');
            } else {
                $token = token();
                $customerinfo = array(
                    'Token' => $token,
                    'LastModifiedBy' => $customerdetail->CustomerId
                );
                $this->Customer_model->updateCustomerInfo($customerdetail->CustomerId, $customerinfo);
                if ($customerdetail->IsMobileVerified == 1) {
                    array_push($customerdetailarray, array('customer_id' => $customerdetail->CustomerId, 'name' => $customerdetail->Name, 'email' => $customerdetail->Email, 'mobile' => $customerdetail->Mobile, 'alternatemobile' => $customerdetail->AlternateMobileNo, "gender" => $customerdetail->Gender, 'profile_image' => base_url() . 'assets/uploads/profile/' . $customerdetail->ProfilePic, 'token' => $token));
                    $response = array('status' => 1, 'data' => $customerdetailarray, "message" => "You have successfully logged in.");
                } else {
                    array_push($customerdetailarray, array('customer_id' => $customerdetail->CustomerId, 'name' => $customerdetail->Name, 'email' => $customerdetail->Email, 'mobile' => $customerdetail->Mobile, 'alternatemobile' => $customerdetail->AlternateMobileNo, "gender" => $customerdetail->Gender, 'profile_image' => base_url() . 'assets/uploads/profile/' . $customerdetail->ProfilePic, 'token' => $token));
                    $otp = otp();
//                    $sms_message = 'Your one time password for Patanjali is ' . $otp . '. Treat this as confidential and do not share with anyone.';
//                    $this->sms->send_sms($customerdetail->mobile, $sms_message);
                    $customerinfo = array(
                        'OTP' => $otp,
                        'LastModifiedBy' => $customerdetail->CustomerId
                    );
                    $this->Customer_model->updateCustomerInfo($customerdetail->CustomerId, $customerinfo);
                    $response = array('status' => 2, 'data' => $customerdetailarray, "message" => "Otp has been sent to your mobile , verify your account.");
                }
            }
        } else {
             $response = array('status' => 0, 'message' => 'Invalid User');
        }
        $this->response($response, REST_Controller::HTTP_OK);
    }
    public function socialRegister_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $customerdetailarray = array();
        $name = $data['name'];
        $gender = $data['gender'];
        $mobile = $data['mobile'];
        $social_id = $data['social_id'];
        $social_type = $data['social_type'];
        $customerdetail = $this->Customer_model->checkSocialLogin($social_type, $social_id);
        if ($customerdetail) {
            if ($customerdetail->IsActive == 0) {
                $response = array('status' => 0, 'message' => 'Your account has been deactivated');
            } else {
                $token = token();
                $customerinfo = array(
                    'Token' => $token,
                    'LastModifiedBy' => $customerdetail->CustomerId
                );
                $this->Customer_model->updateCustomerInfo($customerdetail->CustomerId, $customerinfo);
                if ($customerdetail->IsMobileVerified == 1) {
                    array_push($customerdetailarray, array('customer_id' => $customerdetail->CustomerId, 'name' => $customerdetail->Name, 'email' => $customerdetail->Email, 'mobile' => $customerdetail->Mobile, 'alternatemobile' => $customerdetail->AlternateMobileNo, "gender" => $customerdetail->Gender, 'profile_image' => base_url() . 'assets/uploads/profile/' . $customerdetail->ProfilePic, 'token' => $token));
                    $response = array('status' => 1, 'data' => $customerdetailarray, "message" => "You have successfully logged in.");
                } else {
                    array_push($customerdetailarray, array('customer_id' => $customerdetail->CustomerId, 'name' => $customerdetail->Name, 'email' => $customerdetail->Email, 'mobile' => $customerdetail->Mobile, 'alternatemobile' => $customerdetail->AlternateMobileNo, "gender" => $customerdetail->Gender, 'profile_image' => base_url() . 'assets/uploads/profile/' . $customerdetail->ProfilePic, 'token' => $token));
                    $otp = otp();
//                    $sms_message = 'Your one time password for Patanjali is ' . $otp . '. Treat this as confidential and do not share with anyone.';
//                    $this->sms->send_sms($customerdetail->mobile, $sms_message);
                    $customerinfo = array(
                        'OTP' => $otp,
                        'LastModifiedBy' => $customerdetail->CustomerId
                    );
                    $this->Customer_model->updateCustomerInfo($customerdetail->CustomerId, $customerinfo);
                    $response = array('status' => 2, 'data' => $customerdetailarray, "message" => "Otp has been sent to your mobile , verify your account.");
                }
            }
        } else {
            $checkmobile = $this->Customer_model->checkMobile($mobile);
            if ($checkmobile) {
                $token = token();
                $customerinfo = array(
                    'Token' => $token,
                    'SocialType' => $social_type,
                    'SocialId' => $social_id,
                    'LastModifiedBy' => $checkmobile->CustomerId
                );
                $this->Customer_model->updateCustomerInfo($checkmobile->CustomerId, $customerinfo);
                if ($checkmobile->IsActive == 0) {
                    $response = array('status' => 0, 'message' => 'Your account has been deactivated');
                } else {
                    if ($checkmobile->IsMobileVerified == 1) {
                        array_push($customerdetailarray, array('customer_id' => $checkmobile->CustomerId, 'name' => $checkmobile->Name, 'email' => $checkmobile->Email, 'mobile' => $checkmobile->Mobile, 'alternatemobile' => $checkmobile->AlternateMobileNo, "gender" => $checkmobile->Gender, 'profile_image' => base_url() . 'assets/uploads/profile/' . $checkmobile->ProfilePic, 'token' => $token));
                        $response = array('status' => 1, 'data' => $customerdetailarray, "message" => "You have successfully logged in.");
                    } else {
                        array_push($customerdetailarray, array('customer_id' => $checkmobile->CustomerId, 'name' => $checkmobile->Name, 'email' => $checkmobile->Email, 'mobile' => $checkmobile->Mobile, 'alternatemobile' => $checkmobile->AlternateMobileNo, "gender" => $checkmobile->Gender, 'profile_image' => base_url() . 'assets/uploads/profile/' . $checkmobile->ProfilePic, 'token' => $token));
                        $otp = otp();
//                    $sms_message = 'Your one time password for Patanjali is ' . $otp . '. Treat this as confidential and do not share with anyone.';
//                    $this->sms->send_sms($checkmobile->mobile, $sms_message);
                        $customerinfo = array(
                            'OTP' => $otp,
                            'LastModifiedBy' => $checkmobile->CustomerId
                        );
                        $this->Customer_model->updateCustomerInfo($checkmobile->CustomerId, $customerinfo);
                        $response = array('status' => 2, 'data' => $customerdetailarray, "message" => "Otp has been sent to your mobile , verify your account.");
                    }
                }
            } else {
                $token = token();
                $otp = otp();
                $customerinfo = array(
                    'Name' => $name,
                    'Gender' => $gender,
                    'Mobile' => $mobile,
                    'IsAppRegistered' => 1,
                    'SocialType' => $social_type,
                    'SocialId' => $social_id,
                    'OTP' => $otp
                );
                $customer_id = $this->Customer_model->tmpRegister($customerinfo);
                if ($customer_id) {
//                $sms_message = 'Your one time password for Patanjali is ' . $otp . '. Treat this as confidential and do not share with anyone.';
//                $this->sms->send_sms($mobilenumber, $sms_message);
                    $customerdetailarray = array();
                    array_push($customerdetailarray, array('customer_id' => $customer_id, 'name' => $name, 'email' => "", 'mobile' => $mobile, 'alternatemobile' => "", "gender" => $gender, 'profile_image' => base_url() . 'assets/uploads/profile/profile.png', 'token' => $token));
                    $response = array('status' => 2, 'data' => $customerdetailarray, 'message' => 'Otp has been sent to your mobile , verify your account.');
                } else {
                    $response = array('status' => 0, 'message' => 'Error in processing your request.');
                }
            }
        }
        $this->response($response, REST_Controller::HTTP_OK);
    }

}
