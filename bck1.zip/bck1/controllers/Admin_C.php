<?php

defined('BASEPATH') OR exit('No direct script access allowed');

require APPPATH . '/libraries/REST_Controller.php';

class Admin_Controller extends REST_Controller {
    //var $profileimage = 'assets/uploads/profile/';

    function __construct() {
        header('Access-Control-Allow-Origin: *');
        header('Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE');
        parent::__construct();
     
        $this->load->model('App_model');
        $this->load->model('Admin_model');
        $this->load->model('Customer_model');
    }

    public function index_get() {
        echo "test";
    }

    public function login_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $customerdetailarray = array();
        $UserId = $data['UserId'];
        $password = $data['password'];
                $check = $this->Customer_model->Adminlogin($UserId, $password);
                if ($check == 0) {
                            array_push($check, array('Name' => $check->Name, 'name' => $check->UserId, 'AdminId' => $check->AdminId ));
                            $response = array('status' => 1, 'data' => $customerdetailarray, "message" => "You have successfully logged in.");
                        }  
            
         else {
            $response = array('status' => 0, "message" => "This mobile number is not registered with us.");
        }
        $this->response($response, REST_Controller::HTTP_OK);
}

public function login_posts() {
   // $data = json_decode(file_get_contents('php://input'), true);
  //  $customerdetailarray = array();
    // $UserId = $data['UserId'];
    // $password = $data['password'];
 
        // $appsettingdetail = array(
        //     $UserId = $data['UserId'],
        //     $password = $data['password'],
        //     "id" => "dds",
        //     "version" => "sds",
        // );
        $response = array('status' => 1, 'data' => "tset");
     
    $this->response($response, REST_Controller::HTTP_OK);
}
    
   


}
