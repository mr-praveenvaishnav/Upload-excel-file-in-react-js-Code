<?php

defined('BASEPATH') OR exit('No direct script access allowed');

require APPPATH . '/libraries/REST_Controller.php';

class Admin extends REST_Controller {
    //var $profileimage = 'assets/uploads/profile/';

    function __construct() {
        header('Access-Control-Allow-Origin: http://localhost:3000');
        header('Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE');
        parent::__construct();
        $this->load->model('App_model');
        $this->load->model('Admin_model');
    }

    public function index_get() {
        echo "test";
    }

    public function logins_post() {
        $data = json_decode(file_get_contents('php://input'), true);
      $customerdetailarray = array();
        $UserId = $data['UserName'];
        $password = $data['Password'];
               $check = $this->Admin_model->Adminlogin($UserId, $password);
                if ($check == 1) {
               $datas = $this->Admin_model->postLoginUser($UserId, $password);
            //   echo print_r($datas);
            //       echo print_r($check->IsActive);
            //       echo print_r($check['IsActive']);
            //   die;
                           $response = array('status' => 1,
                            'data' => $datas, 
                            "message" => "You have successfully logged in.");
                      }  
            
         else {
            $response = array('status' => 0, 
            "message" => "please check login details");
     }
     $this->response($response, REST_Controller::HTTP_OK);
}

// public function login_posts() {
//    // $data = json_decode(file_get_contents('php://input'), true);
//   //  $customerdetailarray = array();
//     // $UserId = $data['UserId'];
//     // $password = $data['password'];
 
//         // $appsettingdetail = array(
//         //     $UserId = $data['UserId'],
//         //     $password = $data['password'],
//         //     "id" => "dds",
//         //     "version" => "sds",
//         // );
//         $response = array('status' => 1, 'data' => "tset");
     
//     $this->response($response, REST_Controller::HTTP_OK);
// }
    
   


}
