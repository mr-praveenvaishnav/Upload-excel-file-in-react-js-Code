<?php

defined('BASEPATH') OR exit('No direct script access allowed');

require APPPATH . '/libraries/REST_Controller.php';

class Product extends REST_Controller {

    var $productimage = 'assets/uploads/product_images/';
    var $productthumbsimage = 'assets/uploads/product_images/thumbs/';

    function __construct() {
        header('Access-Control-Allow-Origin: *');
        header('Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE');
        parent::__construct();
        $this->load->model('Product_model');
        $this->load->model('Category_model');
        $this->load->model('Customer_model');
        $this->load->model('Order_model');
    }

    public function index_get() {
        echo "test";
    }

    public function searchProducts_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $searcharray = array();
        $searchkey = $data['searchkey'];
        $products = $this->Product_model->searchProducts($searchkey);
        if ($products) {
            foreach ($products as $product) {
                array_push($searcharray, array('product_id' => $product->ProductId, 'product_name' => $product->ProductName));
                $response = array('status' => 1, 'data' => $searcharray);
            }
        } else {
            $response = array('status' => 0, 'message' => 'No matching results found.');
        }
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function categoryList_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $category_id = $data['category_id'];
        if (!$category_id) {
            $category_id = 0;
        }
        $categorylist = $this->Category_model->getCategoryTree($category_id);
        if ($categorylist) {
            $response = array('status' => 1, 'data' => $categorylist);
        } else {
            $response = array('status' => 0, 'message' => 'Not Available');
        }
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function getCategoryDetails_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $category_id = $data['category_id'];
        $CategoryDetail = $this->Category_model->getCategoryDetails($category_id);
        if ($CategoryDetail) {
            $category = array();
            $category['category_id'] = $CategoryDetail->CategoryId;
            $category['category_name'] = $CategoryDetail->CategoryName;
            $category['description'] = $CategoryDetail->Description;
            $category['parent_id'] = $CategoryDetail->ParentId;
            $category['category_image'] = base_url() . 'assets/uploads/category_image/' . $CategoryDetail->CategoryImage;
            $category['app_icon'] = base_url() . 'assets/uploads/category_app_icon/' . $CategoryDetail->AppIcon;
            $category['web_icon'] = base_url() . 'assets/uploads/category_web_icon/' . $CategoryDetail->WebIcon;
            $response = array('status' => 1, 'data' => $category);
        } else {
            $response = array('status' => 0, 'message' => 'Not Available');
        }
        $this->response($response, REST_Controller::HTTP_OK);
    }


    public function InsertCategoryDetails_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $categorys = array();
        $category_name  = $data['category_name'];
        $description   = $data['description'];
        $category_image= $data['category_image'];
        // // $category['app_icon']  = $data['app_icon'];
        // $category['web_icon'] = $data['web_icon'];
        $customerinfo = array(
            'CategoryName' => $category_name,
            'Description' => $description ,
            'ParentId' => 0,
            'CategoryImage' =>  $category_image,
            'AppIcon' => $category_image,
            'WebIcon' =>   $category_image,
            'IsActive' =>1,
            'MetaKeywords' => $description,
            'MetaDescription' => $description,
            'SortOrder' => 100,
            'CreatedDate' => 5,
            'CreatedBy' => "Admin",
            'LastModifiedDate' =>5,
            'LastModifiedBy' => "admin",
        );
      
        $CategoryDetail = $this->Category_model->InsertCategoryDetails($customerinfo);
        if ($CategoryDetail) {
        //     $category = array();
        //     $category['category_id']   = $CategoryDetail->CategoryId;
        //     $category['category_name'] = $CategoryDetail->CategoryName;
        //     $category['description']   = $CategoryDetail->Description;
        //     $category['parent_id']      = $CategoryDetail->ParentId;
        //     $category['category_image']  = base_url() . 'assets/uploads/category_image/' . $CategoryDetail->CategoryImage;
        //     // $category['app_icon'] = base_url() . 'assets/uploads/category_app_icon/' . $CategoryDetail->AppIcon;
        //  $category['web_icon'] = base_url() . 'assets/uploads/category_web_icon/' . $CategoryDetail->WebIcon;

            $response = array('status' => 1, 'data' => $CategoryDetail);
        } else {
            $response = array('status' => 0, 'message' => 'Not Available');
        }
        $this->response($response, REST_Controller::HTTP_OK);
    }


    public function getHomeProducts_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $homeproducts = array();
        $productarray = array();
        $wishlist = 0;
        $customer_id = $data['customer_id'];
        $products = $this->Product_model->getProductByType(4, 6);
        if ($products) {
            foreach ($products as $product) {
                $getOfferPrice = getOfferPrice($product, $customer_id);
                $productarray1 = array();
                array_push($productarray, array_merge($getOfferPrice, $productarray1));
            }
        }
        $data1 = array('id' => 1,
            'title' => "Offers",
            'products' => $productarray
        );
        array_push($homeproducts, $data1);
        $products = $this->Product_model->getProductByType(2, 6);
        if ($products) {
            foreach ($products as $product) {
                $getOfferPrice = getOfferPrice($product, $customer_id);
                $productarray1 = array();
                array_push($productarray, array_merge($getOfferPrice, $productarray1));
            }
        }
        $data2 = array('id' => 2,
            'title' => "Latest Products",
            'products' => $productarray
        );
        array_push($homeproducts, $data2);
        if ($customer_id > 0) {
            $wishproductarray = array();
            $notifyproductarray = array();
            $wishlistproducts = $this->Customer_model->getWishlistItems($customer_id, 6);
            if ($wishlistproducts) {
                foreach ($wishlistproducts as $product) {
                    $getOfferPrice = getOfferPrice($product, $customer_id);
                    $productarray1 = array();
                    array_push($wishproductarray, array_merge($getOfferPrice, $productarray1));
                }
                $data3 = array('id' => 3,
                    'title' => "Wishlist",
                    'products' => $wishproductarray
                );
                array_push($homeproducts, $data3);
            }
            $notifyproducts = $this->Product_model->getNowInStock($customer_id, 6);
            if ($notifyproducts) {
                foreach ($notifyproducts as $product) {
                    $getOfferPrice = getOfferPrice($product, $customer_id);
                    $productarray1 = array();
                    array_push($notifyproductarray, array_merge($getOfferPrice, $productarray1));
                }
                $data4 = array('id' => 4,
                    'title' => "Now in Stock",
                    'products' => $notifyproductarray
                );
                array_push($homeproducts, $data4);
            }
        }
        $products = $this->Product_model->getProductByType(3, 6);
        if ($products) {
            foreach ($products as $product) {
                $getOfferPrice = getOfferPrice($product, $customer_id);
                $productarray1 = array();
                array_push($productarray, array_merge($getOfferPrice, $productarray1));
            }
        }
        $data5 = array('id' => 5,
            'title' => "Most Popular Items",
            'products' => $productarray
        );
        array_push($homeproducts, $data5);
        $products = $this->Product_model->getProductByType(5, 6);
        if ($products) {
            foreach ($products as $product) {
                $getOfferPrice = getOfferPrice($product, $customer_id);
                $productarray1 = array();
                array_push($productarray, array_merge($getOfferPrice, $productarray1));
            }
        }
        $data6 = array('id' => 6,
            'title' => "Popular Combos",
            'products' => $productarray
        );
        array_push($homeproducts, $data6);
        $response = array("status" => 1, "data" => $homeproducts);
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function getOffers_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $productarray = array();
        $wishlist = 0;
        $customer_id = $data['customer_id'];
        $limit = @$data['limit'];
        $page = @$data['page'];
        $sort_by = @$data['sort_by'];
        $sort_column = "i.AverageSaleQuantity";
        $sort_order = "desc";
        if ($sort_by == "popularity") {
            $sort_column = "i.AverageSaleQuantity";
            $sort_order = "desc";
        }
        if ($sort_by == "newest_first") {
            $sort_column = "p.CreatedDate";
            $sort_order = "desc";
        }
        if ($sort_by == "price_asc") {
            $sort_column = "IF(p.SpecialPriceToDate>=CURRENT_DATE and p.SpecialPriceFromDate<=CURRENT_DATE, CAST(p.SpecialPrice as SIGNED INTEGER),CAST(p.ProductPrice as SIGNED INTEGER)) ASC";
            $sort_order = "1";
        }
        if ($sort_by == "price_desc") {
            $sort_column = "IF(p.SpecialPriceToDate>=CURRENT_DATE and p.SpecialPriceFromDate<=CURRENT_DATE, CAST(p.SpecialPrice as SIGNED INTEGER),CAST(p.ProductPrice as SIGNED INTEGER)) DESC";
            $sort_order = "1";
        }

        $limit_start = ($page * $limit) - $limit;
        if ($limit_start < 0) {
            $limit_start = 0;
        }
        $products = $this->Product_model->getProductByType(4, $limit, $limit_start, $sort_column, $sort_order);
        if ($products) {
            foreach ($products as $product) {
                $getOfferPrice = getOfferPrice($product, $customer_id);
                $productarray1 = array();
                array_push($productarray, array_merge($getOfferPrice, $productarray1));
            }
        }
        if ($productarray) {
            $response = array('status' => 1, 'data' => $productarray);
        } else {
            $response = array('status' => 0, 'message' => 'Not Available');
        }
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function getLatestProducts_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $productarray = array();
        $wishlist = 0;
        $customer_id = $data['customer_id'];
        $limit = @$data['limit'];
        $page = @$data['page'];
        $sort_by = @$data['sort_by'];
        $sort_column = "i.AverageSaleQuantity";
        $sort_order = "desc";
        if ($sort_by == "popularity") {
            $sort_column = "i.AverageSaleQuantity";
            $sort_order = "desc";
        }
        if ($sort_by == "newest_first") {
            $sort_column = "p.CreatedDate";
            $sort_order = "desc";
        }
        if ($sort_by == "price_asc") {
            $sort_column = "IF(p.SpecialPriceToDate>=CURRENT_DATE and p.SpecialPriceFromDate<=CURRENT_DATE, CAST(p.SpecialPrice as SIGNED INTEGER),CAST(p.ProductPrice as SIGNED INTEGER)) ASC";
            $sort_order = "1";
        }
        if ($sort_by == "price_desc") {
            $sort_column = "IF(p.SpecialPriceToDate>=CURRENT_DATE and p.SpecialPriceFromDate<=CURRENT_DATE, CAST(p.SpecialPrice as SIGNED INTEGER),CAST(p.ProductPrice as SIGNED INTEGER)) DESC";
            $sort_order = "1";
        }

        $limit_start = ($page * $limit) - $limit;
        if ($limit_start < 0) {
            $limit_start = 0;
        }
        $products = $this->Product_model->getProductByType(2, $limit, $limit_start, $sort_column, $sort_order);
        if ($products) {
            foreach ($products as $product) {
                $getOfferPrice = getOfferPrice($product, $customer_id);
                $productarray1 = array();
                array_push($productarray, array_merge($getOfferPrice, $productarray1));
            }
        }
        if ($productarray) {
            $response = array('status' => 1, 'data' => $productarray);
        } else {
            $response = array('status' => 0, 'message' => 'Not Available');
        }
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function getPopularProduct_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $productarray = array();
        $wishlist = 0;
        $customer_id = $data['customer_id'];
        $limit = @$data['limit'];
        $page = @$data['page'];
        $sort_by = @$data['sort_by'];
        $sort_column = "i.AverageSaleQuantity";
        $sort_order = "desc";
        if ($sort_by == "popularity") {
            $sort_column = "i.AverageSaleQuantity";
            $sort_order = "desc";
        }
        if ($sort_by == "newest_first") {
            $sort_column = "p.CreatedDate";
            $sort_order = "desc";
        }
        if ($sort_by == "price_asc") {
            $sort_column = "IF(p.SpecialPriceToDate>=CURRENT_DATE and p.SpecialPriceFromDate<=CURRENT_DATE, CAST(p.SpecialPrice as SIGNED INTEGER),CAST(p.ProductPrice as SIGNED INTEGER)) ASC";
            $sort_order = "1";
        }
        if ($sort_by == "price_desc") {
            $sort_column = "IF(p.SpecialPriceToDate>=CURRENT_DATE and p.SpecialPriceFromDate<=CURRENT_DATE, CAST(p.SpecialPrice as SIGNED INTEGER),CAST(p.ProductPrice as SIGNED INTEGER)) DESC";
            $sort_order = "1";
        }

        $limit_start = ($page * $limit) - $limit;
        if ($limit_start < 0) {
            $limit_start = 0;
        }
        $products = $this->Product_model->getProductByType(3, $limit, $limit_start, $sort_column, $sort_order);
        if ($products) {
            foreach ($products as $product) {
                $getOfferPrice = getOfferPrice($product, $customer_id);
                $productarray1 = array();
                array_push($productarray, array_merge($getOfferPrice, $productarray1));
            }
        }
        if ($productarray) {
            $response = array('status' => 1, 'data' => $productarray);
        } else {
            $response = array('status' => 0, 'message' => 'Not Available');
        }
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function getPopularComboProduct_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $productarray = array();
        $wishlist = 0;
        $customer_id = $data['customer_id'];
        $limit = @$data['limit'];
        $page = @$data['page'];
        $sort_by = @$data['sort_by'];
        $sort_column = "i.AverageSaleQuantity";
        $sort_order = "desc";
        if ($sort_by == "popularity") {
            $sort_column = "i.AverageSaleQuantity";
            $sort_order = "desc";
        }
        if ($sort_by == "newest_first") {
            $sort_column = "p.CreatedDate";
            $sort_order = "desc";
        }
        if ($sort_by == "price_asc") {
            $sort_column = "IF(p.SpecialPriceToDate>=CURRENT_DATE and p.SpecialPriceFromDate<=CURRENT_DATE, CAST(p.SpecialPrice as SIGNED INTEGER),CAST(p.ProductPrice as SIGNED INTEGER)) ASC";
            $sort_order = "1";
        }
        if ($sort_by == "price_desc") {
            $sort_column = "IF(p.SpecialPriceToDate>=CURRENT_DATE and p.SpecialPriceFromDate<=CURRENT_DATE, CAST(p.SpecialPrice as SIGNED INTEGER),CAST(p.ProductPrice as SIGNED INTEGER)) DESC";
            $sort_order = "1";
        }

        $limit_start = ($page * $limit) - $limit;
        if ($limit_start < 0) {
            $limit_start = 0;
        }
        $products = $this->Product_model->getProductByType(5, $limit, $limit_start, $sort_column, $sort_order);
        if ($products) {
            foreach ($products as $product) {
                $getOfferPrice = getOfferPrice($product, $customer_id);
                $productarray1 = array();
                array_push($productarray, array_merge($getOfferPrice, $productarray1));
            }
        }
        if ($productarray) {
            $response = array('status' => 1, 'data' => $productarray);
        } else {
            $response = array('status' => 0, 'message' => 'Not Available');
        }
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function getNowInStock_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $customer_id = $data['customer_id'];
        $notifyproductarray = array();
        $limit = @$data['limit'];
        $page = @$data['page'];
        $sort_by = @$data['sort_by'];
        $sort_column = "i.AverageSaleQuantity";
        $sort_order = "desc";
        if ($sort_by == "popularity") {
            $sort_column = "i.AverageSaleQuantity";
            $sort_order = "desc";
        }
        if ($sort_by == "newest_first") {
            $sort_column = "p.CreatedDate";
            $sort_order = "desc";
        }
        if ($sort_by == "price_asc") {
            $sort_column = "IF(p.SpecialPriceToDate>=CURRENT_DATE and p.SpecialPriceFromDate<=CURRENT_DATE, CAST(p.SpecialPrice as SIGNED INTEGER),CAST(p.ProductPrice as SIGNED INTEGER)) ASC";
            $sort_order = "1";
        }
        if ($sort_by == "price_desc") {
            $sort_column = "IF(p.SpecialPriceToDate>=CURRENT_DATE and p.SpecialPriceFromDate<=CURRENT_DATE, CAST(p.SpecialPrice as SIGNED INTEGER),CAST(p.ProductPrice as SIGNED INTEGER)) DESC";
            $sort_order = "1";
        }

        $limit_start = ($page * $limit) - $limit;
        if ($limit_start < 0) {
            $limit_start = 0;
        }
        $notifyproducts = $this->Product_model->getNowInStock($customer_id, $limit, $limit_start, $sort_column, $sort_order);
        if ($notifyproducts) {
            foreach ($notifyproducts as $product) {
                $getOfferPrice = getOfferPrice($product, $customer_id);
                $productarray1 = array();
                array_push($notifyproductarray, array_merge($getOfferPrice, $productarray1));
            }
            $response = array('status' => 1, 'data' => $notifyproductarray);
        } else {
            $response = array('status' => 0, 'message' => 'There are no products in your notifylist.');
        }
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function productByCategory_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $wishlist = 0;
        $productarray = array();
        $customer_id = $data['customer_id'];
        $category_id = $data['category_id'];
        $limit = @$data['limit'];
        $page = @$data['page'];
        $sort_by = @$data['sort_by'];
        $sort_column = "i.AverageSaleQuantity";
        $sort_order = "desc";
        if ($sort_by == "popularity") {
            $sort_column = "i.AverageSaleQuantity";
            $sort_order = "desc";
        }
        if ($sort_by == "newest_first") {
            $sort_column = "p.CreatedDate";
            $sort_order = "desc";
        }
        if ($sort_by == "price_asc") {
            $sort_column = "IF(p.SpecialPriceToDate>=CURRENT_DATE and p.SpecialPriceFromDate<=CURRENT_DATE, CAST(p.SpecialPrice as SIGNED INTEGER),CAST(p.ProductPrice as SIGNED INTEGER)) ASC";
            $sort_order = "1";
        }
        if ($sort_by == "price_desc") {
            $sort_column = "IF(p.SpecialPriceToDate>=CURRENT_DATE and p.SpecialPriceFromDate<=CURRENT_DATE, CAST(p.SpecialPrice as SIGNED INTEGER),CAST(p.ProductPrice as SIGNED INTEGER)) DESC";
            $sort_order = "1";
        }

        $limit_start = ($page * $limit) - $limit;
        if ($limit_start < 0) {
            $limit_start = 0;
        }
        $sub_categories = $this->Category_model->getAllChildCategory($category_id);
        $products = $this->Product_model->getCategoryProducts($sub_categories, $limit, $limit_start, $sort_column, $sort_order);
        if ($products) {
            foreach ($products as $product) {
                $getOfferPrice = getOfferPrice($product, $customer_id);
                $productarray1 = array();
//                // Array containing search string  
//                $searchVal = array("/thumbs/");
//// Array containing replace string from  search string 
//                $replaceVal = array("/thumbs/45x56/");
//// Function to replace string 
//                $res = str_replace($searchVal, $replaceVal, $getOfferPrice['thumbnail_image']);
//                $getOfferPrice['thumbnail_image'] = $res;
                array_push($productarray, array_merge($getOfferPrice, $productarray1));
            }
        }
        if ($productarray) {
            $response = array('status' => 1, 'data' => $productarray);
        } else {
            $response = array('status' => 0, 'message' => 'Not Available');
        }
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function productDetails_post() {
        $details_array = array();
        $productImages = array();
        $relativeproductsarray = array();
        $recentlyproductsarray = array();
        $data = json_decode(file_get_contents('php://input'), true);
        $wishlist = 0;
        $totalratings = 0;
        $totalreviews = 0;
        $customer_id = $data['customer_id'];
        $product_id = $data['product_id'];
        $product_details = $this->Product_model->getProductDetails($product_id);
        if ($product_details) {
            $reviews = $this->Product_model->getProductRating($product_id);
            $productImagelist = $this->Product_model->getProductImages($product_id);
            $productattributes = $this->Product_model->getProductAttributes($product_id);
            if ($productImagelist) {
                foreach ($productImagelist as $product_image) {
                    //$productImage['product_image'] = base_url() . $this->productimage . rawurlencode($product_image->ProductImageName);
                     $productImage['product_image'] = base_url() . $this->productimage ."250x250.png";
                    // $productImage['thumbnail_image'] = base_url() . $this->productthumbsimage . rawurlencode($product_image->ProductThumbnailImageName); 
                     $productImage['thumbnail_image'] = base_url() . $this->productthumbsimage."250x250.png"; //. rawurlencode($product_image->ProductThumbnailImageName);
                    array_push($productImages, $productImage);
                }
            }
            $reviewlist = array();
            if ($reviews) {
                $totalratings = round($reviews->rating,1);
                $totalreviews = $reviews->total;
                $reviewdetails = $this->Product_model->getProductReviews($product_id, 5);
                if ($reviewdetails) {
                    foreach ($reviewdetails as $review) {
                        $review_image = "";
                        if ($review->ReviewImage) {
                            $review_image = base_url() . 'assets/uploads/product_review/' . $review->ReviewImage;
                        }
                        $like_count = $this->Product_model->getReviewLikeDislikecount($review->ReviewId, 1);
                        $dislike_count = $this->Product_model->getReviewLikeDislikecount($review->ReviewId, 2);
                        array_push($reviewlist, array('review_id' => $review->ReviewId, 'review_user_id' => $review->CustomerId, 'customer_name' => $review->Name, 'review_title' => $review->ReviewTitle, 'review_description' => $review->ReviewDescription, 'rating_star' => $review->Rating, 'review_image' => $review_image, 'is_verified' => $review->IsVerified, 'like_count' => $like_count, 'dislike_count' => $dislike_count));
                    }
                }
            }
            if ($customer_id > 0) {
                $recentlyproducts = $this->Product_model->getRecentlyViewedProduct($customer_id, 5);
                if ($recentlyproducts) {
                    foreach ($recentlyproducts as $product) {
                        $getOfferPrice = getOfferPrice($product, $customer_id);
                        array_push($recentlyproductsarray, $getOfferPrice);
                    }
                }
                $RecentlyViewedProduct = array('CustomerId' => $customer_id,
                    'CreatedBy' => $customer_id,
                    'ProductId' => $product_id,
                    'IsActive' => 1
                );
                $this->Product_model->addRecentlyViewedProduct($RecentlyViewedProduct);
            }
            $relativeproducts = $this->Product_model->getRelatedProducts($product_details->CategoryId, 5);
            if ($relativeproducts) {
                foreach ($relativeproducts as $product) {
                    $getOfferPrice = getOfferPrice($product, $customer_id);
                    array_push($relativeproductsarray, $getOfferPrice);
                }
            }
            $getOfferPrice = getOfferPrice($product_details, $customer_id);
            $Category = $this->Category_model->getCategoryDetails($product_details->CategoryId);
            $productarray1 = array('category_id' => $product_details->CategoryId, 'category_name' => $Category->CategoryName, 'product_description' => $product_details->ProductDescription, 'product_images' => $productImages, 'product_attributes' => $productattributes, 'average_rating' => $totalratings, 'totalreviews' => $totalreviews, 'is_veg' => $product_details->IsVeg, 'reviews' => $reviewlist, 'relative_products' => $relativeproductsarray, 'recently_viewed_Product' => $recentlyproductsarray);
            array_push($details_array, array_merge($getOfferPrice, $productarray1));
            // array_push($details_array, array('product_id' => $product_details->ProductId,  'product_name' => $product_details->ProductName,  'weight' => $product_details->ProductMeasureTypeValue, 'unit' => $product_details->ProductMeasureTypeUnit, 'product_image' => $productImage, 'available_qty' => $product_details->AvailableQuantity, 'product_price' => $product_price, 'product_offer' => $product_offer, 'product_mrp' => $product_mrp,  'in_wishlist' => $wishlist, ));
            $response = array('status' => 1, 'data' => $details_array);
        } else {
            $response = array('status' => 0, 'message' => 'Not Available');
        }
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function addReview_post() {
        $data = $_POST;
        $customer_id = $data['customer_id'];
        $token = $data['token'];
        if (verifyToken($customer_id, $token)) {
            $product_id = $data['product_id'];
            $title = $data['title'];
            $description = $data['description'];
            $rating = $data['rating'];
            $order_id = $data['order_id'];
            $review_image = "";
            $config = array('upload_path' => "assets/uploads/product_review/", 'allowed_types' => "gif|jpg|png|jpeg", 'overwrite' => false);
            $this->load->library('upload', $config);
            if ($this->upload->do_upload('review_image')) {
                $uploadimg = $this->upload->data();
                $review_image = $uploadimg['file_name'];
            }
            $reviewarray = array('CustomerId' => $customer_id,
                'CreatedBy' => $customer_id,
                'ProductId' => $product_id,
                'ReviewTitle' => $title,
                'ReviewDescription' => $description,
                'ReviewImage' => $review_image,
                'Rating' => $rating,
                'OrderId' => $order_id,
                'IsVerified' => 0,
                'Status' => 1);
            $reviewval = $this->Product_model->addReview($reviewarray);
            if ($reviewval) {
                $response = array('status' => 1, 'message' => 'Review has been added successfully');
            } else {
                $response = array('status' => 0, 'message' => 'Error in processing your request.');
            }
        } else {
            $response = array('status' => 0, 'message' => 'Token mismatch');
        }
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function productReview_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $product_id = $data['product_id'];
        $limit = @$data['limit'];
        $page = @$data['page'];
        $reviewlist = array();
        $sort_column = "pr.CreatedDate";
        $sort_order = "desc";
        $limit_start = ($page * $limit) - $limit;
        if ($limit_start < 0) {
            $limit_start = 0;
        }
        $reviewdetails = $this->Product_model->getProductReviews($product_id, $limit, $limit_start, $sort_column, $sort_order);
        if ($reviewdetails) {
            foreach ($reviewdetails as $review) {
                $review_image = "";
                if ($review->ReviewImage) {
                    $review_image = base_url() . 'assets/uploads/product_review/' . $review->ReviewImage;
                }
                $like_count = $this->Product_model->getReviewLikeDislikecount($review->ReviewId, 1);
                $dislike_count = $this->Product_model->getReviewLikeDislikecount($review->ReviewId, 2);
                array_push($reviewlist, array('review_id' => $review->ReviewId, 'review_user_id' => $review->CustomerId, 'customer_name' => $review->Name, 'review_title' => $review->ReviewTitle, 'review_description' => $review->ReviewDescription, 'rating_star' => $review->Rating, 'review_image' => $review_image, 'is_verified' => $review->IsVerified, 'like_count' => $like_count, 'dislike_count' => $dislike_count));
            }
            $response = array('status' => 1, 'data' => $reviewlist);
        } else {
            $response = array('status' => 0, 'message' => 'Not Available');
        }
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function relatedProducts_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $wishlist = 0;
        $productarray = array();
        $customer_id = $data['customer_id'];
        $product_id = $data['product_id'];
        $limit = @$data['limit'];
        $page = @$data['page'];
        $product_details = $this->Product_model->getProductDetails($product_id);
        if ($product_details) {
            $sort_column = "p.CreatedDate";
            $sort_order = "desc";
            $limit_start = ($page * $limit) - $limit;
            if ($limit_start < 0) {
                $limit_start = 0;
            }
            $products = $this->Product_model->getRelatedProducts($product_details->CategoryId, $limit, $limit_start, $sort_column, $sort_order);
            if ($products) {
                foreach ($products as $product) {
                    $getOfferPrice = getOfferPrice($product, $customer_id);
                    $productarray1 = array();
                    array_push($productarray, array_merge($getOfferPrice, $productarray1));
                }
            }
            if ($productarray) {
                $response = array('status' => 1, 'data' => $productarray);
            } else {
                $response = array('status' => 0, 'message' => 'Not Available');
            }
        } else {
            $response = array('status' => 0, 'message' => 'Not Available');
        }
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function recentlyViewed_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $wishlist = 0;
        $productarray = array();
        $customer_id = $data['customer_id'];
        $limit = @$data['limit'];
        $page = @$data['page'];
        $sort_column = "rvp.CreatedDate";
        $sort_order = "desc";
        $limit_start = ($page * $limit) - $limit;
        if ($limit_start < 0) {
            $limit_start = 0;
        }
        $products = $this->Product_model->getRecentlyViewedProduct($customer_id, $limit, $limit_start, $sort_column, $sort_order);
        if ($products) {
            foreach ($products as $product) {
                $getOfferPrice = getOfferPrice($product, $customer_id);
                $productarray1 = array();
                array_push($productarray, array_merge($getOfferPrice, $productarray1));
            }
        }
        if ($productarray) {
            $response = array('status' => 1, 'data' => $productarray);
        } else {
            $response = array('status' => 0, 'message' => 'Not Available');
        }
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function issueType_post() {
        //$data = json_decode(file_get_contents('php://input'), true);
        //$product_id = $data['product_id'];
        $issuelist = array();
        array_push($issuelist, array('issue_id' => 1, 'title' => "Price issue"));
        array_push($issuelist, array('issue_id' => 2, 'title' => "Shipping availability issue"));
        array_push($issuelist, array('issue_id' => 3, 'title' => "Incorrect information"));
        array_push($issuelist, array('issue_id' => 4, 'title' => "Other"));
        $response = array('status' => 1, 'data' => $issuelist);
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function addProductIssue_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $customer_id = $data['customer_id'];
        $token = $data['token'];
        if (verifyToken($customer_id, $token)) {
            $product_id = $data['product_id'];
            $issue_id = $data['issue_id'];
            $description = $data['description'];

//            $reviewarray = array('CustomerId' => $customer_id,
//                'CreatedBy' => $customer_id,
//                'ProductId' => $product_id,
//                'ReviewTitle' => $title,
//                'ReviewDescription' => $description,
//                'ReviewImage' => $review_image,
//                'Rating' => $ratings,
//                'OrderId' => $order_id,
//                'IsVerified' => 0);
//            $reviewval = $this->Product_model->addReview($reviewarray);
//            if ($reviewval) {
            $response = array('status' => 1, 'message' => 'Issue has been added successfully');
//            } else {
//                $response = array('status' => 0, 'message' => 'Error in processing your request.');
//            }
        } else {
            $response = array('status' => 0, 'message' => 'Token mismatch');
        }
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function addToNotify_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $customer_id = $data['customer_id'];
        $token = $data['token'];
        if (verifyToken($customer_id, $token)) {
            $product_id = $data['product_id'];
            $check = $this->Product_model->checkNotifyItem($product_id, $customer_id);
            if ($check && count($check) > 0) {
                $notifydata = array(
                    'ProductId' => $product_id,
                    'IsActive' => 1,
                    'CustomerId' => $customer_id,
                    'CreatedBy' => $customer_id
                );
                $addtonotify = $this->Product_model->addToNotify($notifydata);
                if ($addtonotify) {
                    $response = array('status' => 1, 'message' => 'Product has been added to your notify list.');
                } else {
                    $response = array('status' => 0, 'message' => 'Error in processing your request.');
                }
            } else {
                $response = array('status' => 1, 'message' => 'Product has been added to your notify list.');
            }
        } else {
            $response = array('status' => 0, 'message' => 'Token mismatch');
        }
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function removeNotifyProduct_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $customer_id = $data['customer_id'];
        $token = $data['token'];
        if (verifyToken($customer_id, $token)) {
            $product_id = $data['product_id'];
            $notifystatus = $this->Product_model->removeNotifyProduct($customer_id, $product_id);
            if ($notifystatus) {
                $response = array('status' => 1, 'message' => 'Product has been removed from your notification list.');
            } else {
                $response = array('status' => 0, 'message' => 'Error in processing your request.');
            }
        } else {
            $response = array('status' => 0, 'message' => 'Token mismatch');
        }
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function addToWishlist_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $customer_id = $data['customer_id'];
        $token = $data['token'];
        if (verifyToken($customer_id, $token)) {
            $product_id = $data['product_id'];
            $checkwishlistitem = $this->Customer_model->checkWishlistItem($product_id, $customer_id);
            if ($checkwishlistitem && count($checkwishlistitem) > 0) {
                $response = array('status' => 1, 'message' => 'Product has been already added in your wishlist.');
            } else {
                $wishdata = array(
                    'ProductId' => $product_id,
                    'IsActive' => 1,
                    'CustomerId' => $customer_id,
                    'CreatedBy' => $customer_id
                );
                $this->Customer_model->addToWishlist($wishdata);
                $response = array('status' => 1, 'message' => 'Product has been added to your wishlist.');
            }
        } else {
            $response = array('status' => 0, 'message' => 'Token mismatch');
        }
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function removeWishlist_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $customer_id = $data['customer_id'];
        $token = $data['token'];
        if (verifyToken($customer_id, $token)) {
            $product_id = $data['product_id'];
            $wishliststatus = $this->Customer_model->removeFromWishlist($customer_id, $product_id);
            if ($wishliststatus) {
                $response = array('status' => 1, 'message' => 'Product has been removed from your wishlist.');
            } else {
                $response = array('status' => 0, 'message' => 'Error in processing your request.');
            }
        } else {
            $response = array('status' => 0, 'message' => 'Token mismatch');
        }
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function addToCart_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $cartarray = array();
        $cart_price = 0;
        $customer_id = $data['customer_id'];
        $token = $data['token'];
        if (verifyToken($customer_id, $token)) {
            $product_id = $data['product_id'];
            $quantity = $data['quantity'];
            $addtocart = $this->Product_model->addToCart($customer_id, $product_id, $quantity);
            if ($addtocart) {
                $products = $this->Product_model->getCartItemsByCid($customer_id);
                if ($products) {
                    foreach ($products as $product) {
                        $getOfferPrice = getOfferPrice($product, $customer_id);
                        $cart_price += $getOfferPrice['product_price'] * $product->Quantity;
                    }
                }
                array_push($cartarray, array('cart_id' => $addtocart->CartId, 'cart_items' => $addtocart->CartItem, 'cart_qty' => $addtocart->CartQty, 'cart_price' => $cart_price));
                $response = array('status' => 1, 'data' => $cartarray, 'message' => 'Product has been added to your cart.');
            } else {
                $response = array('status' => 0, 'message' => 'Error in processing your request.');
            }
        } else {
            $response = array('status' => 0, 'message' => 'Token mismatch');
        }
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function removeFromCart_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $cartarray = array();
        $productarray = array();
        $cart_price = 0;
        $cart_mrp = 0;
        $cart_items = 0;
        $shipping_charges = 0;
        $weight = 0;
        $cart_id = 0;
        $customer_id = $data['customer_id'];
        $token = $data['token'];
        if (verifyToken($customer_id, $token)) {
            $product_id = $data['product_id'];
            $this->Product_model->removeCartItem($customer_id, $product_id);
            $products = $this->Product_model->getCartItemsByCid($customer_id);
            if ($products) {
                foreach ($products as $product) {
                    $getOfferPrice = getOfferPrice($product, $customer_id);
                    $productarray1 = array("cart_detail_id" => $product->CartDetailId, "product_quantity" => $product->Quantity, "total_price" => $getOfferPrice['product_price'] * $product->Quantity, "min_qty" => $product->MinSaleQuantity, "max_qty" => $product->MaxSaleQuantity);
                    $cart_price += $getOfferPrice['product_price'] * $product->Quantity;
                    $cart_mrp += $getOfferPrice['product_mrp'] * $product->Quantity;
                    $weight += $product->PhysicalWeight * $product->Quantity;
                    $cart_items++;
                    $cart_id = $product->CartId;
                    array_push($productarray, array_merge($getOfferPrice, $productarray1));
                }
                $avail_wallet_amount = $this->Customer_model->getWalletAmount($customer_id);
                $shipping_charges = $this->Order_model->getShippingCharge($weight, $cart_price);
                $cod_charges_limit = $this->config->item('cod_charges_limit');
                if ($cart_price >= $cod_charges_limit) {
                    $cod_charges = 0;
                } else {
                    $cod_charges = $this->config->item('cod_charges');
                }
                $cartarray = array("cart_id" => $cart_id,
                    "cart_items" => $cart_items,
                    "total_cart_mrp" => $cart_mrp,
                    "total_discount" => $cart_mrp - $cart_price,
                    "shipping_charges" => $shipping_charges,
                    "cod_charges" => $cod_charges,
                    "total_cart_price" => $cart_price,
                    "product_list" => $productarray,
                    "patanjali_credit" => $avail_wallet_amount);
                $response = array('status' => 1, 'data' => $cartarray);
            } else {
                $response = array('status' => 0, 'message' => 'Not Available');
            }
        } else {
            $response = array('status' => 0, 'message' => 'Token mismatch');
        }
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function getCartItems_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $cartarray = array();
        $productarray = array();
        $cart_price = 0;
        $cart_mrp = 0;
        $cart_items = 0;
        $shipping_charges = 0;
        $weight = 0;
        $cart_id = 0;
        $customer_id = $data['customer_id'];
        $token = $data['token'];
        if (verifyToken($customer_id, $token)) {
            $products = $this->Product_model->getCartItemsByCid($customer_id);
            if ($products) {
                foreach ($products as $product) {
                    $getOfferPrice = getOfferPrice($product, $customer_id);
                    unset($getOfferPrice["product_varients"]);
                    $productarray1 = array("cart_detail_id" => $product->CartDetailId, "product_quantity" => $product->Quantity, "total_price" => $getOfferPrice['product_price'] * $product->Quantity, "min_qty" => $product->MinSaleQuantity, "max_qty" => $product->MaxSaleQuantity);
                    $cart_price += $getOfferPrice['product_price'] * $product->Quantity;
                    $cart_mrp += $getOfferPrice['product_mrp'] * $product->Quantity;
                    $weight += $product->PhysicalWeight * $product->Quantity;
                    $cart_items++;
                    $cart_id = $product->CartId;
                    array_push($productarray, array_merge($getOfferPrice, $productarray1));
                }
                $avail_wallet_amount = $this->Customer_model->getWalletAmount($customer_id);
                $shipping_charges = $this->Order_model->getShippingCharge($weight, $cart_price);
                $cod_charges_limit = $this->config->item('cod_charges_limit');
                if ($cart_price >= $cod_charges_limit) {
                    $cod_charges = 0;
                } else {
                    $cod_charges = $this->config->item('cod_charges');
                }
                $cartarray = array("cart_id" => $cart_id,
                    "cart_items" => $cart_items,
                    "total_cart_mrp" => $cart_mrp,
                    "total_discount" => $cart_mrp - $cart_price,
                    "shipping_charges" => $shipping_charges,
                    "cod_charges" => $cod_charges,
                    "total_cart_price" => $cart_price,
                    "patanjali_credit" => $avail_wallet_amount,
                    "free_delivery" => 1000,
                    "product_list" => $productarray
                );
                $response = array('status' => 1, 'data' => $cartarray);
            } else {
                $response = array('status' => 0, 'message' => 'Not Available');
            }
        } else {
            $response = array('status' => 0, 'message' => 'Token mismatch');
        }
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function moveToWishlist_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $cartarray = array();
        $productarray = array();
        $cart_price = 0;
        $cart_mrp = 0;
        $cart_items = 0;
        $shipping_charges = 0;
        $weight = 0;
        $cart_id = 0;
        $customer_id = $data['customer_id'];
        $token = $data['token'];
        if (verifyToken($customer_id, $token)) {
            $product_id = $data['product_id'];
            $checkwishlistitem = $this->Customer_model->checkWishlistItem($product_id, $customer_id);
            if ($checkwishlistitem && count($checkwishlistitem) > 0) {
                
            } else {
                $wishdata = array(
                    'ProductId' => $product_id,
                    'IsActive' => 1,
                    'CustomerId' => $customer_id,
                    'CreatedBy' => $customer_id
                );
                $this->Customer_model->addToWishlist($wishdata);
            }
            $this->Product_model->removeCartItem($customer_id, $product_id);
            $products = $this->Product_model->getCartItemsByCid($customer_id);
            if ($products) {
                foreach ($products as $product) {
                    $getOfferPrice = getOfferPrice($product, $customer_id);
                    $productarray1 = array("cart_detail_id" => $product->CartDetailId, "product_quantity" => $product->Quantity, "total_price" => $getOfferPrice['product_price'] * $product->Quantity, "min_qty" => $product->MinSaleQuantity, "max_qty" => $product->MaxSaleQuantity);
                    $cart_price += $getOfferPrice['product_price'] * $product->Quantity;
                    $cart_mrp += $getOfferPrice['product_mrp'] * $product->Quantity;
                    $weight += $product->PhysicalWeight * $product->Quantity;
                    $cart_items++;
                    $cart_id = $product->CartId;
                    array_push($productarray, array_merge($getOfferPrice, $productarray1));
                }
                $shipping_charges = $this->Order_model->getShippingCharge($weight, $cart_price);
                $cod_charges_limit = $this->config->item('cod_charges_limit');
                if ($cart_price >= $cod_charges_limit) {
                    $cod_charges = 0;
                } else {
                    $cod_charges = $this->config->item('cod_charges');
                }
                $cartarray = array("cart_id" => $cart_id,
                    "cart_items" => $cart_items,
                    "total_cart_mrp" => $cart_mrp,
                    "total_discount" => $cart_mrp - $cart_price,
                    "shipping_charges" => $shipping_charges,
                    "cod_charges" => $cod_charges,
                    "total_cart_price" => $cart_price,
                    "product_list" => $productarray);
                $response = array('status' => 1, 'data' => $cartarray, 'message' => 'Product has been moved to your wishlist.');
            } else {
                $response = array('status' => 0, 'message' => 'Not Available');
            }
        } else {
            $response = array('status' => 0, 'message' => 'Token mismatch');
        }
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function addReviewLikeDislike_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $ReviewId = $data['review_id'];
        $CustomerId = $data['customer_id'];
        $Status = $data['status'];
        $token = $data['token'];
        if (verifyToken($CustomerId, $token)) {
            $if_exist = $this->Product_model->getReviewLikeDislike($ReviewId, $CustomerId);
            if (!$if_exist) {
                $review = array(
                    "ReviewId" => $ReviewId,
                    "CustomerId" => $CustomerId,
                    "Status" => $Status
                );
                $result = $this->Product_model->addReviewLikeDislike($review);
                if ($result) {
                    $response = array('status' => 1, 'message' => 'Successfully done');
                } else {
                    $response = array('status' => 0, 'message' => 'Error occurred. Try again later');
                }
            } else {
                $response = array('status' => 0, 'message' => 'Already given');
            }
        } else {
            $response = array('status' => 0, 'message' => 'Token mismatch');
        }
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function addAllToCart_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $cartarray = array();
        $cart_price = 0;
        $customer_id = $data['customer_id'];
        $token = $data['token'];
        if (verifyToken($customer_id, $token)) {
            $cart_products = $data['cart_products'];
            if ($cart_products) {
                $this->Product_model->clearCart($customer_id);
                foreach ($cart_products as $products) {
                    $product_id = $products['product_id'];
                    $quantity = $products['quantity'];
                    $addtocart = $this->Product_model->addToCart($customer_id, $product_id, $quantity);
                }
                if ($addtocart) {
                    $products = $this->Product_model->getCartItemsByCid($customer_id);
                    if ($products) {
                        foreach ($products as $product) {
                            $getOfferPrice = getOfferPrice($product, $customer_id);
                            $cart_price += $getOfferPrice['product_price'] * $product->Quantity;
                        }
                    }
                    array_push($cartarray, array('cart_id' => $addtocart->CartId, 'cart_items' => $addtocart->CartItem, 'cart_qty' => $addtocart->CartQty, 'cart_price' => $cart_price));
                    $response = array('status' => 1, 'data' => $cartarray, 'message' => 'Products have been added to your cart.');
                } else {
                    $response = array('status' => 0, 'message' => 'Error in processing your request.');
                }
            } else {
                $response = array('status' => 0, 'message' => 'Error in processing your request.');
            }
        } else {
            $response = array('status' => 0, 'message' => 'Token mismatch');
        }
        $this->response($response, REST_Controller::HTTP_OK);
    }
	public function addAllToCartWeb_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $cartarray = array();
        $cart_price = 0;
        $customer_id = $data['customer_id'];
        $token = $data['token'];
        if (verifyToken($customer_id, $token)) {
            $cart_products = $data['cart_products'];
            if ($cart_products) {
                //$this->Product_model->clearCart($customer_id);
                foreach ($cart_products as $product) {
                    $product_id = $product['product_id'];
                    $quantity = $product['quantity'];
                    $addtocart = $this->Product_model->addToCart($customer_id, $product_id, $quantity);
                }
                if ($addtocart) {
                    $products = $this->Product_model->getCartItemsByCid($customer_id);
                    if ($products) {
                        foreach ($products as $product) {
                            $getOfferPrice = getOfferPrice($product, $customer_id);
                            $cart_price += $getOfferPrice['product_price'] * $product->Quantity;
                        }
                    }
                    array_push($cartarray, array('cart_id' => $addtocart->CartId, 'cart_items' => $addtocart->CartItem, 'cart_qty' => $addtocart->CartQty, 'cart_price' => $cart_price));
                    $response = array('status' => 1, 'data' => $cartarray, 'message' => 'Products have been added to your cart.');
                } else {
                    $response = array('status' => 0, 'message' => 'Error in processing your request.');
                }
            } else {
                $response = array('status' => 0, 'message' => 'Error in processing your request.');
            }
        } else {
            $response = array('status' => 0, 'message' => 'Token mismatch');
        }
        $this->response($response, REST_Controller::HTTP_OK);
    }

}
