<?php

defined('BASEPATH') OR exit('No direct script access allowed');

require APPPATH . '/libraries/REST_Controller.php';

class Order extends REST_Controller {

    function __construct() {
        header('Access-Control-Allow-Origin: *');
        header('Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE');
        parent::__construct();
        $this->load->model('Order_model');
        $this->load->model('Customer_model');
        $this->load->model('Product_model');
        $this->load->model('App_model');
    }

    public function index_get() {
        echo "test";
    }

    public function addRecurringOrders_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $customer_id = $data['customer_id'];
        $token = $data['token'];
        if (verifyToken($customer_id, $token)) {
            $frequency_type = $data['frequency_type'];
            $frequency_value = $data['frequency_value'];
            $day_value = $data['day_value'];
            $orderinfo = array(
                'CustomerId' => $customer_id,
                'CreatedBy' => $customer_id,
                'FrequencyType' => $frequency_type,
                'FrequencyValue' => $frequency_value,
                'Value' => $day_value,
                'IsActive' => 1
            );
            $recurringorder_id = $this->Order_model->addRecurringOrder($orderinfo);
            if ($recurringorder_id) {
                $products = $this->Product_model->getCartItemsByCid($customer_id);
                if ($products) {
                    foreach ($products as $product) {
                        $orderdetails = array(
                            'RecurringOrderId' => $recurringorder_id,
                            'CreatedBy' => $customer_id,
                            'ProductId' => $product->ProductId,
                            'Quantity' => $product->Quantity,
                            'IsActive' => 1
                        );
                        $this->Order_model->addRecurringOrderDetail($orderdetails);
                    }
                }
                $response = array('status' => 1, "message" => "Recurring Order has been added successfully");
            } else {
                $response = array('status' => 0, 'message' => 'Error in processing your request.');
            }
        } else {
            $response = array('status' => 0, 'message' => 'Token mismatch');
        }
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function getRecurringOrders_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $orderarray = array();
        $productarray = array();
        $customer_id = $data['customer_id'];
        $token = $data['token'];
        if (verifyToken($customer_id, $token)) {
            $recurringorders = $this->Order_model->getRecurringOrders($customer_id);
            if ($recurringorders) {
                foreach ($recurringorders as $order) {
                    $productarray = array();
                    $products = $this->Order_model->getRecurringOrderDetails($order->RecurringOrderId);
                    if ($products) {
                        foreach ($products as $product) {
                            $getOfferPrice = getOfferPrice($product, $customer_id);
                            $productarray1 = array('product_quantity' => $product->Quantity, 'total_price' => $product->Quantity * $getOfferPrice['product_price']);
                            array_push($productarray, array_merge($getOfferPrice, $productarray1));
                        }
                    }
                    array_push($orderarray, array("recurringorder_id" => $order->RecurringOrderId,
                        "last_modified_date" => formatDate($order->LastModifiedDate),
                        "schedual" => "every 2nd week on monday",
                        "status" => $order->IsActive,
                        "product_detail" => $productarray));
                }
                $response = array('status' => 1, 'data' => $orderarray);
            } else {
                $response = array('status' => 0, 'message' => 'Not Available');
            }
        } else {
            $response = array('status' => 0, 'message' => 'Token mismatch');
        }
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function updateRecurringOrderStatus_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $customer_id = $data['customer_id'];
        $token = $data['token'];
        if (verifyToken($customer_id, $token)) {
            $recurringorder_id = $data['recurringorder_id'];
            $recurringorders = $this->Order_model->getRecurringOrderById($recurringorder_id);
            if ($recurringorders->IsActive == 0) {
                $status = 1;
            } else {
                $status = 0;
            }
            $this->Order_model->updateRecurringOrder($recurringorder_id, array('IsActive' => $status));
            $response = array('status' => 1, "message" => "Order has been updated successfully");
        } else {
            $response = array('status' => 0, 'message' => 'Token mismatch');
        }
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function deleteRecurringOrder_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $customer_id = $data['customer_id'];
        $token = $data['token'];
        if (verifyToken($customer_id, $token)) {
            $recurringorder_id = $data['recurringorder_id'];
            $this->Order_model->deleteRecurringOrder($recurringorder_id);
            $response = array('status' => 1, "message" => "Order has been deleted successfully");
        } else {
            $response = array('status' => 0, 'message' => 'Token mismatch');
        }
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function deleteRecurringOrderProduct_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $customer_id = $data['customer_id'];
        $token = $data['token'];
        if (verifyToken($customer_id, $token)) {
            $recurringorder_id = $data['recurringorder_id'];
            $product_id = $data['product_id'];
            $this->Order_model->deleteRecurringOrderProduct($recurringorder_id, $product_id);
            $response = array('status' => 1, "message" => "Product has been deleted successfully");
        } else {
            $response = array('status' => 0, 'message' => 'Token mismatch');
        }
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function getOrders_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $orderarray = array();
        $productarray = array();
        $customer_id = $data['customer_id'];
        $token = $data['token'];
        $limit = @$data['limit'];
        $page = @$data['page'];
        if (verifyToken($customer_id, $token)) {
            $sort_column = "CreatedDate";
            $sort_order = "desc";
            $limit_start = ($page * $limit) - $limit;
            if ($limit_start < 0) {
                $limit_start = 0;
            }
            $orders = $this->Order_model->getOrders($customer_id, $limit, $limit_start, $sort_column, $sort_order);
            if ($orders) {
                foreach ($orders as $order) {
                    array_push($orderarray, array("order_id" => $order->OrderId,
                        "order_number" => $order->OrderNumber,
                        "order_date" => formatDate($order->CreatedDate),
                        "items" => $order->OrderItems,
                        "amount" => $order->FinalAmount,
                        "Status" => "Pending"
                    ));
                }
                $response = array('status' => 1, 'data' => $orderarray);
            } else {
                $response = array('status' => 0, 'message' => 'Not Available');
            }
        } else {
            $response = array('status' => 0, 'message' => 'Token mismatch');
        }
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function orderDetails_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $orderarray = array();
        $productarray = array();
        $total_mrp = 0;
        $total_price = 0;
        $customer_id = $data['customer_id'];
        $token = $data['token'];
        $order_id = $data['order_id'];
        if (verifyToken($customer_id, $token)) {
            $orderdetails = $this->Order_model->getOrderDetails($order_id, $customer_id);
            if ($orderdetails) {
                $ship_address = $this->Order_model->getOrderAddress($orderdetails->ShippingAddressId);
                $shipping_address = array(
                    "name" => $ship_address->Name,
                    "mobile" => $ship_address->Mobile,
                    "alternatemobile" => $ship_address->AlternatMobileNo,
                    "address" => $ship_address->Address,
                    "landmark" => $ship_address->Landmark,
                    "city_name" => $ship_address->CityName,
                    "state_name" => $ship_address->StateName,
                    "zipcode" => $ship_address->PinCode,
                    "type" => $ship_address->AddressType
                );
                $bill_address = $this->Order_model->getOrderAddress($orderdetails->BillingAddressId);
                $billing_address = array(
                    "name" => $bill_address->Name,
                    "mobile" => $bill_address->Mobile,
                    "alternatemobile" => $bill_address->AlternatMobileNo,
                    "address" => $bill_address->Address,
                    "landmark" => $bill_address->Landmark,
                    "city_name" => $bill_address->CityName,
                    "state_name" => $bill_address->StateName,
                    "zipcode" => $bill_address->PinCode,
                    "type" => $bill_address->AddressType
                );
                $order_items = $this->Order_model->getOrderItems($orderdetails->OrderId);
                if ($order_items) {
                    foreach ($order_items as $product) {
                        $productarray1 = array(
                            "product_name" => $product->ProductName,
                            "weight" => $product->ProductMeasureTypeValue,
                            "unit" => $product->ProductMeasureTypeUnit,
                            "quantity" => $product->Quantity,
                            "product_price" => $product->Quantity * $product->Price,
                            "product_image" => base_url() . 'assets/uploads/product_images/' . rawurlencode($product->ProductImage),
                            "review_id" => $product->ReviewId,
                            "review_rating" => $product->Rating,
                            "review_title" => $product->ReviewTitle,
                            "review_description" => $product->ReviewDescription
                        );
                        array_push($productarray, $productarray1);
                        $total_mrp += $product->Quantity * $product->Mrp;
                        $total_price += $product->Quantity * $product->Price;
                    }
                }
                $coupon_code = '';
                $coupon_detail = $this->Order_model->getCouponCodeById($orderdetails->Couponid);
                if ($coupon_detail) {
                    $coupon_code = $coupon_detail->CouponCode;
                }
                array_push($orderarray, array("order_id" => $orderdetails->OrderId,
                    "order_number" => $orderdetails->OrderNumber,
                    "order_items" => $orderdetails->OrderItems,
                    "order_qty" => $orderdetails->OrderQuantity,
                    "total_mrp" => $total_mrp,
                    "total_discount" => $total_mrp - $total_price,
                    "cod_charges" => $orderdetails->CODCharge,
                    "shipping_charges" => $orderdetails->ShippingCharge,
                    "coupon_code" => $coupon_code,
                    "coupon_discount" => $orderdetails->CouponDiscount,
                    "patanjali_credit" => 60,
                    "final_amount" => $orderdetails->FinalAmount,
                    "order_date" => formatDate($orderdetails->CreatedDate),
                    "payment_mode" => getpaymenttype($orderdetails->PaymentMode),
                    "credit_points" => 15,
                    "products" => $productarray,
                    "billing_address" => $billing_address,
                    "shipping_address" => $shipping_address
                ));
                $response = array('status' => 1, 'data' => $orderarray);
            } else {
                $response = array('status' => 0, 'message' => 'Error in processing your request.');
            }
        } else {
            $response = array('status' => 0, 'message' => 'Token mismatch');
        }
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function moveRecurringOrderToCart_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $customer_id = $data['customer_id'];
        $recurringorder_id = $data['recurringorder_id'];
        $token = $data['token'];
        if (verifyToken($customer_id, $token)) {
            $this->Product_model->clearCart($customer_id);
            $products = $this->Order_model->getRecurringOrderDetails($recurringorder_id);
            if ($products) {
                foreach ($products as $product) {
                    $addtocart = $this->Product_model->addToCart($customer_id, $product->ProductId, $product->Quantity);
                }
            }
            $response = array('status' => 1, 'data' => "");
        } else {
            $response = array('status' => 0, 'message' => 'Token mismatch');
        }
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function cancelOrder_post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $customer_id = $data['customer_id'];
        $token = $data['token'];
        if (verifyToken($customer_id, $token)) {
            $reason = $data['reason'];
            $order_id = $data['order_id'];
            $orderdetails = $this->Order_model->getOrderDetails($order_id, $customer_id);
            if ($orderdetails) {
                if ($orderdetails->status < 5) {
//            $itemvalue = $this->Orders_model->getFinalorderDetails($order_id);
//            foreach ($itemvalue as $id) {
//                $itemarray = array('status' => 10);
//                $value1 = $this->Orders_model->updateorderitem($id->orderdetail_id, $itemarray);
//                $getOrderItem = $this->Orders_model->getOrderItemsbyid($id->orderdetail_id);
//                $this->Products_model->updateQuantity($getOrderItem->product_id, $getOrderItem->quantity, 'add');
//                $this->Products_model->updatePackageQuantity($getOrderItem->product_id, $getOrderItem->quantity, 'add');
//            }
//
//            $user_detail = $this->Customer_model->getCustomerDetails($customer_id);
                    $dataarray = array('IsCanceled' => 1, 'CancelReason' => $reason, "CancelDate" => time(),
                        'RefundAmount' => $orderdetails->TotalAmount, 'LastModifiedBy' => $customer_id);
                    $value = $this->Order_model->updateorder($order_id, $dataarray);
//            $mobile_number = $user_detail->mobile;
//            $sms_message = 'Hello , your order ' . $order_no . ' is cancelled.';
//            $this->sms->send_sms($mobile_number, $sms_message);
//
//            $to = $user_detail->email;
//            $subject = 'Order Cancelled';
//            $message = 'Hello ' . $user_detail->firstname . ',<br><br> your order with reference to ' . $order_no . ' has been cancelled.';
//            //send email
//            sendEmail($to, $subject, $message);            
                    $response = array('status' => 1, 'message' => 'Order has been cancelled successfully');
                } else {
                    if ($orderdetails->IsCanceled==1) {
                        $response = array('status' => 1, 'message' => 'Order has been cancelled successfully');
                    } else {
                        $response = array('status' => 1, 'message' => 'Order already dispatched you can not cancel this order');
                    }
                }
            } else {
                $response = array('status' => 0, 'message' => '');
            }
        } else {
            $response = array('status' => 0, 'message' => 'Token mismatch');
        }
        $this->response($response, REST_Controller::HTTP_OK);
    }

}
