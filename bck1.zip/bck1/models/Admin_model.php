<?php

class Admin_model extends CI_Model {

    // public function register($data) {
    //     $this->db->insert('customers', $data);
    //     return $this->db->insert_id();
    // }

    public function Adminlogin($UserId, $Password) {
        $this->db->select('*');
        $this->db->where('UserId', $UserId);
        $this->db->where('Password', sha1($Password));
        $this->db->from('admin');
        $query = $this->db->get();
        if ($query->num_rows() == 0) {
            return false;
        } else {
            return true;
        }   
    }
    public function postLoginUser($UserId, $Password) {
        $this->db->select('*');
        $this->db->where('UserId', $UserId);
        $this->db->where('Password', sha1($Password));
        $this->db->from('admin');
        $query = $this->db->get();
            return $query->result();
    }
    


    // public function getCategoryTree($parent = 0) {
    //     $categories = array();
    //     $this->db->from('product_categories');
    //     $this->db->where('ParentId', $parent);
    //     $this->db->where('IsActive', 1);
    //     $result = $this->db->get()->result();
    //     foreach ($result as $mainCategory) {
    //         $category = array();
    //         $category['category_id'] = $mainCategory->CategoryId;
    //         $category['category_name'] = $mainCategory->CategoryName;
    //         $category['description'] = $mainCategory->Description;
    //         $category['parent_id'] = $mainCategory->ParentId;
    //         $category['category_image'] = base_url() . 'assets/uploads/category_image/' . $mainCategory->CategoryImage;
    //         $category['app_icon'] = base_url() . 'assets/uploads/category_app_icon/' . $mainCategory->AppIcon;
    //         $category['web_icon'] = base_url() . 'assets/uploads/category_web_icon/' . $mainCategory->WebIcon;
    //         $category['sub_category'] = $this->getCategoryTree($category['category_id']);
    //         $categories[] = $category;
    //     }
    //     return $categories;
    // }

    // function getCategoryDetails($id) {
    //     $this->db->select('*');
    //     $this->db->from('product_categories');
    //     $this->db->where('CategoryId', $id);
    //     $query = $this->db->get();
    //     /* echo $this->db->last_query(); */
    //     return $query->row();
    // }



}

?>