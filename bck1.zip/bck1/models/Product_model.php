<?php

class Product_model extends CI_Model {

    public function searchProducts($search_txt) {
        $this->db->select('*');
        $this->db->from('products');
        $this->db->where('IsActive', 1);
        $this->db->where('ProductName like \'%' . str_replace('-', ' ', $search_txt) . '%\'');
        $this->db->limit(5);
        $query = $this->db->get();
        //echo $this->db->last_query();
        return $query->result();
    }
 // $limit_start = null
    public function getProducts($limit_start = null) {
        if ($limit || $limit_start) {
            $this->db->limit($limit, $limit_start);
        }
        $this->db->select('*');
        $this->db->from('products p');
        $this->db->join('product_inventory i', 'i.ProductId = p.ProductId');
        $this->db->join('product_images pi', 'pi.ProductId = p.ProductId');
        $this->db->where('pi.IsDefault', 1);
        $this->db->where('p.IsActive', 1);
        $this->db->order_by('p.ProductId', 'desc');
        $query = $this->db->get();
        return $query->result();
    }

    public function getProductByType($product_type_id = 0, $limit = 0, $limit_start = 0, $sort_column = 0, $sort_order = "desc") {
        $this->db->select('*');
        $this->db->from('products p');
        $this->db->join('product_inventory i', 'i.ProductId = p.ProductId');
        $this->db->join('product_images pi', 'pi.ProductId = p.ProductId');
        $this->db->join('producttypeattr pta', 'pta.ProductId = p.ProductId');
        $this->db->where('pi.IsDefault', 1);
        $this->db->where('p.IsActive', 1);
        $this->db->where('pta.ProductTypeId', $product_type_id);
        if ($limit || $limit_start) {
            $this->db->limit($limit, $limit_start);
        }
        if ($sort_column) {
            $this->db->order_by($sort_column, $sort_order);
        }
        //$this->db->order_by('p.ProductId', 'desc');
        $query = $this->db->get();
        return $query->result();
    }

    public function getNowInStock($customer_id, $limit = 0, $limit_start = 0, $sort_column = 0, $sort_order = "desc") {
        $this->db->select('*');
        $this->db->from('products p');
        $this->db->join('product_inventory i', 'i.ProductId = p.ProductId');
        $this->db->join('product_images pi', 'pi.ProductId = p.ProductId');
        $this->db->join('notify_products np', 'np.ProductId = p.ProductId');
        $this->db->where('pi.IsDefault', 1);
        $this->db->where('i.AvailableQuantity >', 0);
        $this->db->where('p.IsActive', 1);
        $this->db->where('np.CustomerId', $customer_id);
        if ($limit || $limit_start) {
            $this->db->limit($limit, $limit_start);
        }
        if ($sort_column) {
            $this->db->order_by($sort_column, $sort_order);
        }
        //$this->db->order_by('p.ProductId', 'desc');
        $query = $this->db->get();
        return $query->result();
    }

    public function getCategoryProducts($category_id = 0, $limit = 0, $limit_start = 0, $sort_column = 0, $sort_order = "desc") {
        $this->db->select('*');
        $this->db->from('products p');
        $this->db->join('product_inventory i', 'i.ProductId = p.ProductId');
        $this->db->join('product_images pi', 'pi.ProductId = p.ProductId');
        $this->db->where('pi.IsDefault', 1);
        $this->db->where('p.IsActive', 1);
        $this->db->where_in('p.CategoryId', $category_id);
        if ($limit) {
            $this->db->limit($limit, $limit_start);
        }
        if ($sort_column) {
            $this->db->order_by($sort_column, $sort_order);
        }
        $query = $this->db->get();
        //echo $this->db->last_query();
        return $query->result();
    }

    public function getProductDetails($product_id) {
        $this->db->select('*');
        $this->db->from('products p');
        $this->db->join('product_inventory i', 'i.ProductId = p.ProductId');
        $this->db->join('product_images pi', 'pi.ProductId = p.ProductId');
        $this->db->where('p.ProductId', $product_id);
        $details = $this->db->get();
        return $details->row();
    }

    public function getProductImages($product_id = 0) {
        $this->db->select('*');
        $this->db->from('products p');
        $this->db->join('product_images pi', 'pi.ProductId = p.ProductId');
        $this->db->where('p.ProductId', $product_id);
        $this->db->where('pi.IsActive', 1);
        $this->db->order_by('pi.SortOrder', 'asc');
        $query = $this->db->get();
        return $query->result();
    }

    public function getProductRating($product_id) {
        $this->db->select('AVG(Rating) as rating ,count(ReviewId) as total');
        $this->db->from('product_reviews');
        $this->db->where('ProductId', $product_id);
        $this->db->where('Status', 1);
        $this->db->group_by('ProductId');
        $reviews = $this->db->get();
        return $reviews->row();
    }

    public function getProductReviews($product_id, $limit = 0, $limit_start = 0, $sort_column = 0, $sort_order = "desc") {
        $this->db->select('*');
        $this->db->from('product_reviews pr');
        $this->db->join('customers c', 'c.CustomerId = pr.CustomerId');
        $this->db->where('pr.ProductId', $product_id);
        $this->db->where('pr.Status', 1);
        if ($limit || $limit_start) {
            $this->db->limit($limit, $limit_start);
        }
        if ($sort_column) {
            $this->db->order_by($sort_column, $sort_order);
        }
        $reviews = $this->db->get();
        return $reviews->result();
    }

    public function getProductAttributes($product_id) {
        $this->db->select('a.AttributeId,a.AttributeName,pa.AttributeValue');
        $this->db->from('product_attributes pa');
        $this->db->join('attributes a', 'a.AttributeId = pa.AttributeId');
        $this->db->where('pa.ProductId', $product_id);
        $this->db->where('pa.IsActive', 1);
        $this->db->order_by('pa.SortOrder', 'asc');
        $reviews = $this->db->get();
        return $reviews->result();
    }

    public function addReview($reviewarray) {
        $this->db->insert('product_reviews', $reviewarray);
        return $this->db->insert_id();
    }

    public function addRecentlyViewedProduct($data) {
        $this->db->insert('recently_viewed_products', $data);
        return $this->db->insert_id();
    }

    public function getRelatedProducts($category_id = 0, $limit = 0, $limit_start = 0, $sort_column = 0, $sort_order = "desc") {
        $this->db->select('*');
        $this->db->from('products p');
        $this->db->join('product_inventory i', 'i.ProductId = p.ProductId');
        $this->db->join('product_images pi', 'pi.ProductId = p.ProductId');
        $this->db->where('pi.IsDefault', 1);
        $this->db->where('p.IsActive', 1);
        //$this->db->where_in('p.CategoryId', $category_id);
        if ($limit || $limit_start) {
            $this->db->limit($limit, $limit_start);
        }
        if ($sort_column) {
            $this->db->order_by($sort_column, $sort_order);
        }
        //$this->db->order_by('p.ProductId', 'desc');
        $query = $this->db->get();
        return $query->result();
    }

    public function getRecentlyViewedProduct($customer_id, $limit = 0, $limit_start = 0, $sort_column = 0, $sort_order = "desc") {
        $this->db->select('*');
        $this->db->from('products p');
        $this->db->join('product_inventory i', 'i.ProductId = p.ProductId');
        $this->db->join('product_images pi', 'pi.ProductId = p.ProductId');
        $this->db->join('recently_viewed_products rvp', 'rvp.ProductId = p.ProductId');
        $this->db->where('pi.IsDefault', 1);
        $this->db->where('p.IsActive', 1);
        $this->db->where('rvp.CustomerId', $customer_id);
        if ($limit || $limit_start) {
            $this->db->limit($limit, $limit_start);
        }
        if ($sort_column) {
            $this->db->order_by($sort_column, $sort_order);
        }
        $this->db->order_by('rvp.CreatedDate', 'desc');
        $query = $this->db->get();
        return $query->result();
    }

    public function addToNotify($data) {
        $this->db->insert('notify_products', $data);
        return $this->db->insert_id();
    }

    public function removeNotifyProduct($customer_id, $product_id) {
        $this->db->where('CustomerId', $customer_id);
        $this->db->where('ProductId', $product_id);
        $this->db->where('IsActive', 1);
        $this->db->delete('notify_products');
        return true;
    }

    public function checkNotifyItem($product_id, $customer_id) {
        $this->db->where('ProductId', $product_id);
        $this->db->where('CustomerId', $customer_id);
        $this->db->where('IsActive', 1);
        $query = $this->db->get('notify_products');
        if ($query->num_rows() > 0) {
            return "1";
        } else {
            return "0";
        }
    }

    public function addToCart($customer_id, $product_id, $quantity) {
        $checkCart = $this->getCart($customer_id);
        if ($quantity > 0) {
            if ($checkCart) {
                $cart_id = $checkCart->CartId;
            } else {
                $this->db->insert('carts', array('CustomerId' => $customer_id, 'IsActive' => 1));
                $cart_id = $this->db->insert_id();
            }
            $checkCartItem = $this->checkCartItem($cart_id, $product_id);
            if ($checkCartItem) {
                $this->db->where('CartDetailId', $checkCartItem->CartDetailId);
                $this->db->update('cart_details', array('Quantity' => $quantity));
            } else {
                $this->db->insert('cart_details', array('CartId' => $cart_id, 'ProductId' => $product_id, 'Quantity' => $quantity));
                $this->db->insert_id();
            }
        } else {
            if ($checkCart) {
                $cart_id = $checkCart->CartId;
                $this->db->where('CartId', $cart_id);
                $this->db->where('ProductId', $product_id);
                $this->db->delete('cart_details');
            }
        }
        $this->autoUpdateCart($customer_id);
        $cart = $this->getCart($customer_id);
        return $cart;
    }

    public function countCartItems($cart_id) {
        $this->db->select('count(CartDetailId) as total_item ,sum(Quantity) as total_quantity');
        $this->db->where('CartId', $cart_id);
        $query = $this->db->get('cart_details');
        return $query->row();
    }

    public function autoUpdateCart($customer_id) {
        $checkCart = $this->getCart($customer_id);
        if ($checkCart) {
        $cart_id = $checkCart->CartId;
        $CartItems = $this->countCartItems($cart_id);
        $this->db->where('CartId', $cart_id);
        $this->db->update('carts', array('CartItem' => $CartItems->total_item, 'CartQty' => $CartItems->total_quantity));
        }
        return true;
    }

    public function getCart($customer_id) {
        $this->db->where('CustomerId', $customer_id);
        $query = $this->db->get('carts');
        $cart_detail = $query->row();
        return $cart_detail;
    }

    public function checkCartItem($cart_id, $product_id) {
        $this->db->where('ProductId', $product_id);
        $this->db->where('CartId', $cart_id);
        $query = $this->db->get('cart_details');
        return $query->row();
    }

    public function getCartItemsByCid($customer_id) {
        $cart = $this->getCart($customer_id);
        if ($cart) {
            $this->db->select('*');
            $this->db->from('products p');
            $this->db->join('product_inventory i', 'i.ProductId = p.ProductId');
            $this->db->join('product_images pi', 'pi.ProductId = p.ProductId');
            $this->db->join('cart_details cd', 'cd.ProductId = p.ProductId');
            $this->db->where('pi.IsDefault', 1);
            $this->db->where('p.IsActive', 1);
            $this->db->where('cd.CartId', $cart->CartId);
            $query = $this->db->get();
            return $query->result();
        } else {
            return false;
        }
    }

    public function removeCartItem($customer_id, $product_id) {
        $checkCart = $this->getCart($customer_id);
        $cart_id = $checkCart->CartId;
        $this->db->where('CartId', $cart_id);
        $this->db->where('ProductId', $product_id);
        $this->db->delete('cart_details');
        $this->autoUpdateCart($customer_id);
        $cart = $this->getCart($customer_id);
        return $cart;
    }
    public function clearCart($customer_id) {
        $checkCart = $this->getCart($customer_id);
        $cart_id = $checkCart->CartId;
        $this->db->where('CartId', $cart_id);
        $this->db->delete('cart_details');       
        $this->db->where('CartId', $cart_id);
        $this->db->delete('carts');
    }

    public function getProductVariants($name, $id) {
        $product_name = addslashes($name);
        $this->db->select('*');
        $this->db->from('products p');
        $this->db->join('product_inventory i', 'i.ProductId = p.ProductId');
        $this->db->where('p.IsActive', 1);
        $this->db->where('p.ProductName', $product_name);
        //$this->db->where('p.ProductId !=', $id);
        $this->db->order_by('p.ProductId', 'desc');
        $query = $this->db->get();
        return $query->result();
    }

    public function addReviewLikeDislike($data) {
        $this->db->insert('review_like_dislike', $data);
        return $this->db->insert_id();
    }

    public function getReviewLikeDislike($review_id, $customer_id) {
        $this->db->select('*');
        $this->db->from('review_like_dislike');
        $this->db->where('ReviewId', $review_id);
        $this->db->where('CustomerId', $customer_id);
        $query = $this->db->get();
        return $query->result();
    }

    public function getReviewLikeDislikecount($review_id, $type) {
        $this->db->select('*');
        $this->db->from('review_like_dislike');
        $this->db->where('ReviewId', $review_id);
        $this->db->where('Status', $type);
        $query = $this->db->get();
        return $query->num_rows();
    }

    function getCartDetail($customer_id) {
        $this->db->select('*');
        $this->db->from('carts c');
        $this->db->join('cart_details cd', 'c.CartId = cd.CartId');
        $this->db->join('products p', 'cd.ProductId = p.ProductId');
        $this->db->join('product_inventory i', 'i.ProductId = p.ProductId');
        $this->db->join('product_images pi', 'pi.ProductId = p.ProductId');
        $this->db->where('pi.IsDefault', 1);
        $this->db->where('c.CustomerId', $customer_id);
        $product = $this->db->get();
        $amount = 0;
        $itemcount = 0;
        $quantity = 0;
        $getcartDetail = $product->result();
        if ($getcartDetail) {
            foreach ($getcartDetail as $cart) {
                $getOfferPrice = getOfferPrice($cart);
                $amount = $amount + $cart->Quantity * $getOfferPrice['product_price'];
                $quantity = $quantity + $cart->Quantity;
            }
        }
        $result = array('amount' => round($amount), 'itemcount' => count($getcartDetail), 'itemquantity' => $quantity);
        return $result;
    }

    public function checkCouponCode($code) {
        $this->db->select('*');
        $this->db->from('coupons');
        $this->db->where('CouponCode', $code);
        $this->db->where('FromDate <=', date("Y-m-d"));
        $this->db->where('ToDate >=', date("Y-m-d"));
        $this->db->where('IsActive', 1);
        $query = $this->db->get();
        return $query->row();
    }

    public function getComboProducts($id) {
        $this->db->select('*');
        $this->db->from('combo_products c');
        $this->db->join('products p', 'c.ProductId = p.ProductId');
        $this->db->join('product_images pi', 'pi.ProductId = p.ProductId');
        $this->db->where('pi.IsDefault', 1);
        $this->db->where('c.ComboProductId', $id);
        //$this->db->order_by('c.id', 'asc');
        $query = $this->db->get();
        return $query->result();
    }

    public function updateQuantity($product_id, $qty, $type = 'less') {
        if ($type == 'less') {
            $this->db->query("Update product_inventory set AvailableQuantity=AvailableQuantity-$qty where ProductId=$product_id");
        }
        if ($type == 'add') {
            $this->db->query("Update product_inventory set AvailableQuantity=AvailableQuantity+$qty where ProductId=$product_id");
        }
    }

}

?>
