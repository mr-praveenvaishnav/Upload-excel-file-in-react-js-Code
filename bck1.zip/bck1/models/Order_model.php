<?php

class Order_model extends CI_Model {

    public function getOrderNumber($order_no) {
        $this->db->select('*');
        $this->db->from('orders');
        $this->db->where('orderNumber', $order_no);
        $order = $this->db->get();
        return $order->row();
    }

    public function addRecurringOrder($data) {
        $this->db->insert('recurring_orders', $data);
        return $this->db->insert_id();
    }

    public function addRecurringOrderDetail($data) {
        $this->db->insert('recurring_order_details', $data);
        return $this->db->insert_id();
    }

    public function getRecurringOrders($customer_id) {
        $this->db->select('*');
        $this->db->from('recurring_orders');
        $this->db->where('CustomerId', $customer_id);
        $query = $this->db->get();
        return $query->result();
    }

    public function getRecurringOrderById($order_id) {
        $this->db->select('*');
        $this->db->from('recurring_orders');
        $this->db->where('RecurringOrderId', $order_id);
        $query = $this->db->get();
        return $query->row();
    }

    public function getRecurringOrderDetails($order_id) {
        $this->db->select('*');
        $this->db->from('recurring_order_details rdd');
        $this->db->join('products p', 'p.ProductId = rdd.ProductId');
        $this->db->join('product_inventory i', 'i.ProductId = p.ProductId');
        $this->db->join('product_images pi', 'pi.ProductId = p.ProductId');
        $this->db->where('rdd.RecurringOrderId', $order_id);
        $this->db->where('pi.IsDefault', 1);
        $query = $this->db->get();
        //echo $this->db->last_query();
        return $query->result();
    }

    public function updateRecurringOrder($order_id, $data) {
        $this->db->where('RecurringOrderId', $order_id);
        $this->db->update('recurring_orders', $data);
        return true;
    }

    public function deleteRecurringOrder($order_id) {
        $this->db->where('RecurringOrderId', $order_id);
        $this->db->delete('recurring_orders');
        return true;
    }

    public function deleteRecurringOrderProduct($order_id, $product_id) {
        $this->db->where('RecurringOrderId', $order_id);
        $this->db->where('ProductId', $product_id);
        $this->db->delete('recurring_order_details');
        return true;
    }

    public function getOrders($customer_id, $limit = 0, $limit_start = 0, $sort_column = 0, $sort_order = "desc") {
        $this->db->select('*');
        $this->db->from('orders');
        $this->db->where('CustomerId', $customer_id);
        if ($limit || $limit_start) {
            $this->db->limit($limit, $limit_start);
        }
        if ($sort_column) {
            $this->db->order_by($sort_column, $sort_order);
        }
        $query = $this->db->get();
        return $query->result();
    }

    public function getOrderDetails($order_id, $customer_id = 0) {
        $this->db->select('*');
        $this->db->from('orders');
        $this->db->where('OrderId', $order_id);
        if ($customer_id) {
            $this->db->where('CustomerId', $customer_id);
        }
        $query = $this->db->get();
        return $query->row();
    }

    public function getOrderAddress($address_id) {
        $this->db->select('*');
        $this->db->from('order_addresses oa');
        $this->db->join('cities c', 'c.CityId = oa.CityId');
        $this->db->join('states s', 's.StateId = oa.StateId');
        $this->db->where('oa.OrderAddressId', $address_id);
        $query = $this->db->get();
        return $query->row();
    }

    public function getOrderItems($order_id) {
        $this->db->select('*, od.ProductId as ProductId,od.OrderId as OrderId');
        $this->db->from('order_details od');
        $this->db->join('order_products op', 'op.OrderDetailId = od.OrderDetailId');
        $this->db->join('product_reviews pr', 'pr.ProductId = od.ProductId and pr.OrderId = od.OrderId', 'left');
        $this->db->where('od.OrderId', $order_id);
        $this->db->where('op.ComboProductId', 0);
        $query = $this->db->get();
        return $query->result();
    }

    public function getOrderAllItems($order_id) {
        $this->db->select('*, op.ProductId as ProductId,od.OrderId as OrderId');
        $this->db->from('order_details od');
        $this->db->join('order_products op', 'op.OrderDetailId = od.OrderDetailId');
        $this->db->join('product_reviews pr', 'pr.ProductId = od.ProductId and pr.OrderId = od.OrderId', 'left');
        $this->db->where('od.OrderId', $order_id);
        //$this->db->where('op.ComboProductId', 0);
        $query = $this->db->get();
        return $query->result();
    }

    public function getOrderbyCoupon($coupon_id = 0, $customer_id = 0) {
        $this->db->select('*');
        $this->db->from('orders');
        if ($customer_id) {
            $this->db->where('CustomerId', $customer_id);
        }
        if ($coupon_id) {
            $this->db->where('CouponId', $coupon_id);
        }
        // $this->db->where('is_confirmed', 1);
        $order_no = $this->db->get();
        return $order_no->result();
    }

    public function getCouponbyCId($coupon_id = 0, $customer_id = 0) {
        $this->db->select('*');
        $this->db->from('customer_coupons');
        if ($customer_id) {
            $this->db->where('CustomerId', $customer_id);
        }
        if ($coupon_id) {
            $this->db->where('CouponId', $coupon_id);
        }
        $this->db->where('IsActive', 1);
        $order_no = $this->db->get();
        return $order_no->row();
    }

    public function addOrder($customer_id, $payment_mode, $finalamount, $shipping_charges, $cod_charges, $wallet_amount, $shipping_address_id, $billing_address_id, $app_order, $status, $cartprice, $cartitems, $cartqty, $coupon_id, $coupon_discount) {
        $order_no = getorderno();
        $cart_items = $this->Product_model->getCartItemsByCid($customer_id);
        if (count($cart_items) == 0) {
            return array('status' => 0, 'message' => 'Desired quantity is not available in stock.');
        }
        foreach ($cart_items as $item12) {
            $pro1 = $this->Product_model->getProductDetails($item12->ProductId);
            if ($item12->Quantity == 0) {
                return array('status' => 0, 'message' => 'Desired quantity is not available in stock.');
            }
            if ($pro1->MaxSaleQuantity < $item12->Quantity) {
                return array('status' => 0, 'message' => 'Desired quantity is not available in stock.');
            }
            if ($pro1->MinSaleQuantity > $item12->Quantity) {
                return array('status' => 0, 'message' => 'Desired quantity is not available in stock.');
            }
            if ($pro1->AvailableQuantity - $item12->Quantity < 0) {
                return array('status' => 0, 'message' => 'Desired quantity is not available in stock.');
            }
        }
        $shipping_addresses = $this->Customer_model->getAddressesById($shipping_address_id);
        $shippingaddressdata = array(
            "CustomerId" => $customer_id,
            "Name" => $shipping_addresses->Name,
            "Address" => $shipping_addresses->Address,
            "Landmark" => $shipping_addresses->Landmark,
            "CityId" => $shipping_addresses->CityId,
            "StateId" => $shipping_addresses->StateId,
            "CountryId" => $shipping_addresses->CountryId,
            "PinCode" => $shipping_addresses->PinCode,
            "Mobile" => $shipping_addresses->Mobile,
            "AlternatMobileNo" => $shipping_addresses->AlternatMobileNo,
            "AddressType" => $shipping_addresses->AddressType,
            "IsShippingAddress" => 1,
            "IsBillingAddress" => 0,
            "IsActive" => 1
        );
        $shippingaddressid = $this->Order_model->addOrderAddress($shippingaddressdata);
        $billing_addresses = $this->Customer_model->getAddressesById($billing_address_id);
        $billingaddressdata = array(
            "CustomerId" => $customer_id,
            "Name" => $billing_addresses->Name,
            "Address" => $billing_addresses->Address,
            "Landmark" => $billing_addresses->Landmark,
            "CityId" => $billing_addresses->CityId,
            "StateId" => $billing_addresses->StateId,
            "CountryId" => $billing_addresses->CountryId,
            "PinCode" => $billing_addresses->PinCode,
            "Mobile" => $billing_addresses->Mobile,
            "AlternatMobileNo" => $billing_addresses->AlternatMobileNo,
            "AddressType" => $billing_addresses->AddressType,
            "IsShippingAddress" => 0,
            "IsBillingAddress" => 1,
            "IsActive" => 1
        );
        $billingaddressid = $this->Order_model->addOrderAddress($billingaddressdata);
        $dataorder = array('orderNumber' => $order_no,
            'CustomerId' => $customer_id,
            'OrderItems' => $cartitems,
            'OrderQuantity' => $cartqty,
            'OrderPrice' => $cartprice,
            'PaymentMode' => $payment_mode,
            'ShippingCharge' => $shipping_charges,
            'CODCharge' => $cod_charges,
            'CouponId' => $coupon_id,
            'CouponDiscount' => $coupon_discount,
            'WalletAmount' => $wallet_amount,
            'FinalAmount' => $finalamount,
            'ShippingAddressId' => $shippingaddressid,
            'BillingAddressId' => $billingaddressid,
            'IsAppOrder' => $app_order,
            'Status' => $status
        );
        $this->db->insert('orders', $dataorder);
        $order_id = $this->db->insert_id();
        if ($order_id && $order_id > 0) {
            foreach ($cart_items as $item) {
                $product = $this->Product_model->getProductDetails($item->ProductId);
                $getOfferPrice = getOfferPrice($product, $customer_id);
                $dataorderitems = array('OrderId' => $order_id,
                    'ProductId' => $item->ProductId,
                    'Quantity' => $item->Quantity,
                    'Mrp' => $getOfferPrice['product_mrp'],
                    'Price' => $getOfferPrice['product_price'],
                    'Tax' => $product->GSTRate);
                $this->db->insert('order_details', $dataorderitems);
                $order_detail_id = $this->db->insert_id();
                $orderproduct = array('OrderDetailId' => $order_detail_id,
                    'ComboProductId' => 0,
                    'ItemQuantity' => 1,
                    'ProductId' => $product->ProductId,
                    'CategoryId' => $product->CategoryId,
                    'ProductSKU' => $product->ProductSKU,
                    'ProductName' => $product->ProductName,
                    'ProductDescription' => $product->ProductDescription,
                    'PhysicalWeight' => $product->PhysicalWeight,
                    'ProductMeasureTypeId' => $product->ProductMeasureTypeId,
                    'ProductMeasureTypeValue' => $product->ProductMeasureTypeValue,
                    'ProductMeasureTypeUnit' => $product->ProductMeasureTypeUnit,
                    'ProductPrice' => $product->ProductPrice,
                    'SpecialPrice' => $product->SpecialPrice,
                    'SpecialPriceFromDate' => $product->SpecialPriceFromDate,
                    'SpecialPriceToDate' => $product->SpecialPriceToDate,
                    'ProductImage' => $product->ProductImageName,
                    'ProductMetaTitle' => $product->ProductMetaTitle,
                    'ProductMetaKeywords' => $product->ProductMetaKeywords,
                    'ProductMetaDescription' => $product->ProductMetaDescription,
                    'ManufacturerId' => $product->ManufacturerId,
                    'SapCode' => $product->SapCode,
                    'HSN' => $product->HSN,
                    'GSTRate' => $product->GSTRate,
                    'BarCode' => $product->BarCode,
                    'PlantCode' => $product->PlantCode,
                    'PlantName' => $product->PlantName,
                    'PackSize' => $product->PackSize,
                    'IsVeg' => $product->IsVeg,
                    'IsActive' => $product->IsActive);
                $this->Order_model->addOrderProduct($orderproduct);
                if ($product->IsCombo == 1) {
                    $combo_products = $this->Product_model->getComboProducts($product->ProductId);
                    if ($combo_products) {
                        foreach ($combo_products as $combo_product) {
                            $ordercomboproduct = array('OrderDetailId' => $order_detail_id,
                                'ComboProductId' => $product->ProductId,
                                'ItemQuantity' => $combo_product->Quantity,
                                'ProductId' => $combo_product->ProductId,
                                'CategoryId' => $combo_product->CategoryId,
                                'ProductSKU' => $combo_product->ProductSKU,
                                'ProductName' => $combo_product->ProductName,
                                'ProductDescription' => $combo_product->ProductDescription,
                                'PhysicalWeight' => $combo_product->PhysicalWeight,
                                'ProductMeasureTypeId' => $combo_product->ProductMeasureTypeId,
                                'ProductMeasureTypeValue' => $combo_product->ProductMeasureTypeValue,
                                'ProductMeasureTypeUnit' => $combo_product->ProductMeasureTypeUnit,
                                'ProductPrice' => $combo_product->ProductPrice,
                                'SpecialPrice' => $combo_product->SpecialPrice,
                                'SpecialPriceFromDate' => $combo_product->SpecialPriceFromDate,
                                'SpecialPriceToDate' => $combo_product->SpecialPriceToDate,
                                'ProductImage' => $combo_product->ProductImageName,
                                'ProductMetaTitle' => $combo_product->ProductMetaTitle,
                                'ProductMetaKeywords' => $combo_product->ProductMetaKeywords,
                                'ProductMetaDescription' => $combo_product->ProductMetaDescription,
                                'ManufacturerId' => $combo_product->ManufacturerId,
                                'SapCode' => $combo_product->SapCode,
                                'HSN' => $combo_product->HSN,
                                'GSTRate' => $combo_product->GSTRate,
                                'BarCode' => $combo_product->BarCode,
                                'PlantCode' => $combo_product->PlantCode,
                                'PlantName' => $combo_product->PlantName,
                                'PackSize' => $combo_product->PackSize,
                                'IsVeg' => $combo_product->IsVeg,
                                'IsActive' => $combo_product->IsActive);
                            $this->Order_model->addOrderProduct($ordercomboproduct);
                        }
                    }
                }
            }
            return array('status' => 1, 'order_id' => $order_id, 'order_no' => $order_no);
        } else {
            return array('status' => 0, 'message' => 'Desired quantity is not available in stock.');
        }
    }

    public function addOrderProduct($data) {
        $this->db->insert('order_products', $data);
        return $this->db->insert_id();
    }

    public function addOrderAddress($data) {
        $this->db->insert('order_addresses', $data);
        return $this->db->insert_id();
    }

    public function getCouponCodeById($coupon_id) {
        $this->db->select('*');
        $this->db->from('coupons');
        $this->db->where('CouponId', $coupon_id);
        $query = $this->db->get();
        return $query->row();
    }

    public function updateOrder($id, $dataarray) {
        $this->db->where('OrderId', $id);
        $this->db->update('orders', $dataarray);
    }

    public function getShippingCharge($weight,$cart_price=0) {
        if($cart_price<$this->config->item('shipping_charges_limit')){
        $this->db->select('*');
        $this->db->from('shipping_charges');
        $this->db->where('ShipWeightFrom<=', $weight);
        $this->db->where('ShipWeightTo>=', $weight);
        $query = $this->db->get();
        //echo $this->db->last_query();
        return $query->row()->Charges;
        } else{
            return 0;
        }
    }
}

?>