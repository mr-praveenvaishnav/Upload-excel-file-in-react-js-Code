<?php

class Customer_model extends CI_Model {

    public function register($data) {
        $this->db->insert('customers', $data);
        return $this->db->insert_id();
    }


  
    public function Adminlogin($UserId, $Password) {
        $this->db->select('*');
        $this->db->where('UserId', $UserId);
        $this->db->where('Password', sha1($Password));
        $this->db->from('admin');
        $query = $this->db->get();
        if ($query->num_rows() == 0) {
            return false;
        } else {
            return true;
        }   
    }
    public function postLoginUser($UserId, $Password) {
        $this->db->select('*');
        $this->db->where('UserId', $UserId);
        $this->db->where('Password', sha1($Password));
        $this->db->from('admin');
        $query = $this->db->get();
            return $query->result();
    }
    


    public function tmpRegister($data) {
        $check = $this->checkTmpMobile($data['Mobile']);
        if ($check) {
            $this->db->where('Mobile', $data['Mobile']);
            $this->db->update('tmp_customers', array('OTP' => $data['OTP']));
            return $check->CustomerId;
        } else {
            $this->db->insert('tmp_customers', $data);
            return $this->db->insert_id();
        }
    }

    public function login($mobile, $password) {
        $this->db->select('*');
        $this->db->where('Mobile', $mobile);
        $this->db->where('Password', sha1($password));
        $this->db->from('customers');
        $result = $this->db->get();
        if ($result->num_rows() == 0) {
            return false;
        } else {
            return $result->row();
        }
    }

    public function checkMobile($mobile, $customer_id = 0) {
        $this->db->select('*');
        $this->db->from('customers');
        $this->db->where('Mobile', $mobile);
        if ($customer_id) {
            $this->db->where('CustomerId!=', $customer_id);
        }
        $result = $this->db->get();
        if ($result->num_rows() == 0) {
            return false;
        } else {
            return $result->row();
        }
    }

    public function checkTmpMobile($mobile, $customer_id = 0) {
        $this->db->select('*');
        $this->db->from('tmp_customers');
        $this->db->where('Mobile', $mobile);
        if ($customer_id) {
            $this->db->where('CustomerId!=', $customer_id);
        }
        $result = $this->db->get();
        if ($result->num_rows() == 0) {
            return false;
        } else {
            return $result->row();
        }
    }

    function addLoginAttempt($customer_id) {
        //Increase number of attempts. Set last login attempt if required.      
        $this->db->select('*');
        $this->db->from('login_attempts');
        $this->db->where('CustomerId', $customer_id);
        $this->db->where('Status', 0);
        $result = $this->db->get();
        $data = $result->row();
        if ($data) {
            $attempts = $data->Attempts + 1;
            if ($attempts == 3) {
                $userdata = array('Attempts' => $attempts, 'LastLogin' => date('Y-m-d H:i:s'));
            } else {
                $userdata = array('Attempts' => $attempts);
            }
            $this->db->where('CustomerId', $customer_id);
            $this->db->where('Status', 0);
            $this->db->update('login_attempts', $userdata);
        } else {
            $this->db->insert('login_attempts', array('CustomerId' => $customer_id, 'Attempts' => 1, 'LastLogin' => date('Y-m-d H:i:s')));
            return $this->db->insert_id();
        }
    }

    function checkLoginAttempt($customer_id) {
        $this->db->select('Attempts,LastLogin, (CASE when LastLogin is not NULL and DATE_ADD(LastLogin, INTERVAL -740 MINUTE)>NOW() then 1 else 0 end) as Denied');
        $this->db->from('login_attempts');
        $this->db->where('CustomerId', $customer_id);
        $this->db->where('Status', 0);
        $query = $this->db->get();
        $result = $query->row();
        //Verify that at least one login attempt is in database
        if (!$result) {
            return 0;
        }
        if ($result->Attempts >= 3 or $result->LastLogin <= date('Y-m-d H:i:s', strtotime('-10 minute'))) {
            if ($result->Denied == 1) {
                return 1;
            } else {
                $this->db->where('CustomerId', $customer_id);
                $this->db->where('Status', 0);
                $this->db->update('login_attempts', array('Status' => 1));
                return 0;
            }
        }
        return 0;
    }

    public function checkEmail($email, $customer_id = 0) {
        $this->db->select('*');
        $this->db->from('customers');
        $this->db->where('Email', $email);
        if ($customer_id) {
            $this->db->where('CustomerId!=', $customer_id);
        }
        $result = $this->db->get();
        if ($result->num_rows() == 0) {
            return false;
        } else {
            return $result->row();
        }
    }

    public function forgotPassword($mobile, $updatepassword) {
        $this->db->where('Mobile', $mobile);
        $this->db->update('customers', $updatepassword);
    }

    public function addAddress($data) {
        $this->db->insert('customer_addresses', $data);
        return $this->db->insert_id();
    }

    public function editCustomerAddress($addressdata, $address_id) {
        $this->db->where('CustomerAddressId', $address_id);
        $this->db->update('customer_addresses', $addressdata);
        return true;
    }

    public function getCustomerDetails($customer_id) {
        $this->db->select('*');
        $this->db->from('customers');
        $this->db->where('CustomerId', $customer_id);
        $query = $this->db->get();
        return $query->row();
    }

    public function getAddresses($customer_id) {
        $this->db->select('*');
        $this->db->from('customer_addresses');
        $this->db->where('CustomerId', $customer_id);
        $query = $this->db->get();
        return $query->result();
    }

    public function getAddressesById($address_id) {
        $this->db->select('*');
        $this->db->from('customer_addresses');
        $this->db->where('CustomerAddressId', $address_id);
        $this->db->where('IsActive', 1);
        $query = $this->db->get();
        return $query->row();
    }

    public function getShippingAddresses($customer_id) {
        $this->db->select('*');
        $this->db->from('customer_addresses');
        $this->db->where('CustomerId', $customer_id);
        $this->db->where('IsActive', 1);
        $this->db->where('IsBillingAddress', 0);
        $query = $this->db->get();
        return $query->result();
    }

    public function getBillingAddress($customer_id) {
        $this->db->select('*');
        $this->db->from('customer_addresses');
        $this->db->where('CustomerId', $customer_id);
        $this->db->where('IsActive', 1);
        $this->db->where('IsBillingAddress', 1);
        $query = $this->db->get();
        return $query->row();
    }

    function checkWishlistItem($product_id, $customer_id) {
        $this->db->where('ProductId', $product_id);
        $this->db->where('CustomerId', $customer_id);
        $this->db->where('IsActive', 1);
        $query = $this->db->get('wishlist');
        return $query->row();
    }

    public function checkWishlist($product_id, $customer_id) {
        $this->db->select('WishlistId');
        $this->db->from('wishlist');
        $this->db->where('CustomerId', $customer_id);
        $this->db->where('ProductId', $product_id);
        $this->db->where('IsActive', 1);
        $product_wishlist = $this->db->get();
        if ($product_wishlist->num_rows() > 0) {
            return "1";
        } else {
            return "0";
        }
    }

    public function addToWishlist($data) {
        $this->db->insert('wishlist', $data);
        return $this->db->insert_id();
    }

    public function removeFromWishlist($customer_id, $product_id) {
        $this->db->where('CustomerId', $customer_id);
        $this->db->where('ProductId', $product_id);
        $this->db->where('IsActive', 1);
        $this->db->delete('wishlist');
        return true;
    }

    public function getWishlistItems($customer_id, $limit = 0, $limit_start = 0, $sort_column = 0, $sort_order = "desc") {
        $this->db->select('*');
        $this->db->from('products p');
        $this->db->join('product_inventory i', 'i.ProductId = p.ProductId');
        $this->db->join('product_images pi', 'pi.ProductId = p.ProductId');
        $this->db->join('wishlist w', 'w.ProductId = p.ProductId');
        $this->db->where('pi.IsDefault', 1);
        $this->db->where('p.IsActive', 1);
        $this->db->where('w.CustomerId', $customer_id);
        if ($limit || $limit_start) {
            $this->db->limit($limit, $limit_start);
        }
        if ($sort_column) {
            $this->db->order_by($sort_column, $sort_order);
        }
        $this->db->order_by('p.ProductId', 'desc');
        $query = $this->db->get();
        return $query->result();
    }

    public function getNotifyItems($customer_id, $limit = 0, $limit_start = 0, $sort_column = 0, $sort_order = "desc") {
        $this->db->select('*');
        $this->db->from('products p');
        $this->db->join('product_inventory i', 'i.ProductId = p.ProductId');
        $this->db->join('product_images pi', 'pi.ProductId = p.ProductId');
        $this->db->join('notify_products np', 'np.ProductId = p.ProductId');
        $this->db->where('pi.IsDefault', 1);
        $this->db->where('p.IsActive', 1);
        $this->db->where('np.CustomerId', $customer_id);
        if ($limit || $limit_start) {
            $this->db->limit($limit, $limit_start);
        }
        if ($sort_column) {
            $this->db->order_by($sort_column, $sort_order);
        }
        $this->db->order_by('p.ProductId', 'desc');
        $query = $this->db->get();
        return $query->result();
    }

    public function updateCustomerInfo($customer_id, $userdata) {
        $this->db->where('CustomerId', $customer_id);
        $this->db->update('customers', $userdata);
        return true;
    }

    public function updateTmpCustomerInfo($customer_id, $userdata) {
        $this->db->where('CustomerId', $customer_id);
        $this->db->update('tmp_customers', $userdata);
        return true;
    }

    public function editCustomerAddressByCustomerId($addressdata, $customer_id) {
        $this->db->where('CustomerId', $customer_id);
        $this->db->update('customer_addresses', $addressdata);
        return true;
    }

    public function getCustomerReviews($customer_id, $limit = 0, $limit_start = 0, $sort_column = 0, $sort_order = "desc") {
        $this->db->select('*,pr.CreatedDate as rdate');
        $this->db->from('product_reviews pr');
        $this->db->join('products p', 'p.ProductId = pr.ProductId');
        $this->db->join('product_images pi', 'pi.ProductId = p.ProductId');
        $this->db->where('pi.IsDefault', 1);
        $this->db->where('pr.CustomerId', $customer_id);
        $this->db->where('pr.Status', 1);
        if ($limit || $limit_start) {
            $this->db->limit($limit, $limit_start);
        }
        if ($sort_column) {
            $this->db->order_by($sort_column, $sort_order);
        }
        $reviews = $this->db->get();
        return $reviews->result();
    }

    public function getNotifications($customer_id, $limit = 0, $limit_start = 0, $sort_column = 0, $sort_order = "desc") {
        $this->db->select('*');
        $this->db->from('notifications');
        $this->db->where('CustomerId', $customer_id);
        $this->db->where('IsActive', 1);
        $this->db->where('IsSended', 1);
        if ($limit || $limit_start) {
            $this->db->limit($limit, $limit_start);
        }
        if ($sort_column) {
            $this->db->order_by($sort_column, $sort_order);
        }
        $query = $this->db->get();
        return $query->result();
    }

    public function updateNotification($notification_id, $value) {
        $this->db->where('NotificationId', $notification_id);
        $this->db->update('notifications', $value);
    }

    function addWalletAmount($wallet_date) {
        $this->db->insert('wallet', $wallet_date);
        return $this->db->insert_id();
    }

    function getWalletAmount($customer_id) {
        $this->db->select_sum('Amount');
        $this->db->where('CustomerId', $customer_id);
        $this->db->where('AmountType', 'debit');
        $this->db->where('Status', 1);
        $this->db->from('wallet');
        $query = $this->db->get();
        $this->db->select_sum('Amount');
        $this->db->where('CustomerId', $customer_id);
        $this->db->where('AmountType', 'credit');
        $this->db->where('Status', 1);
        $this->db->from('wallet');
        $query1 = $this->db->get();
        return $query1->row()->Amount - $query->row()->Amount;
    }
    function checkSocialLogin($social_type,$social_id) {
        $this->db->select('*');
        $this->db->from('customers');
        $this->db->where('SocialType', $social_type);
        $this->db->where('SocialId', $social_id);
        $query = $this->db->get();
        return $query->row();
    }

}

?>