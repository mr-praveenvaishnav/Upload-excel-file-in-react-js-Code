<?php

class Category_model extends CI_Model {

    public function getCategoryTree($parent = 0) {
        $categories = array();
        $this->db->from('product_categories');
        $this->db->where('ParentId', $parent);
        $this->db->where('IsActive', 1);
        $result = $this->db->get()->result();
        foreach ($result as $mainCategory) {
            $category = array();
            $category['category_id'] = $mainCategory->CategoryId;
            $category['category_name'] = $mainCategory->CategoryName;
            $category['description'] = $mainCategory->Description;
            $category['parent_id'] = $mainCategory->ParentId;
            $category['category_image'] = base_url() . 'assets/uploads/category_image/' . $mainCategory->CategoryImage;
            $category['app_icon'] = base_url() . 'assets/uploads/category_app_icon/' . $mainCategory->AppIcon;
            $category['web_icon'] = base_url() . 'assets/uploads/category_web_icon/' . $mainCategory->WebIcon;
            $category['sub_category'] = $this->getCategoryTree($category['category_id']);
            $categories[] = $category;
        }
        return $categories;
    }


     function InsertCategoryDetails($data) {
        $this->db->insert('product_categories', $data);
        return $this->db->insert_id();
    }
    function getCategoryDetails($id) {
        $this->db->select('*');
        $this->db->from('product_categories');
        $this->db->where('CategoryId', $id);
        $query = $this->db->get();
        /* echo $this->db->last_query(); */
        return $query->row();
    }

    public function getAllChildCategory($parent = 0, $cat = array()) {
        $categories = array();
        $this->db->from('product_categories');
        $this->db->where('ParentId', $parent);
        $this->db->where('IsActive', 1);
        $result = $this->db->get()->result();
        $cat[] = $parent;
        if ($result) {
            foreach ($result as $mainCategory) {
                $cat = $this->getAllChildCategory($mainCategory->CategoryId, $cat);
            }
        }
        return $cat;
    }

}

?>