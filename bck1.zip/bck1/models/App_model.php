<?php

class App_model extends CI_Model {

    public function appSettings($type) {
        $this->db->select('*');
        $this->db->where('Type', $type);
        $query = $this->db->get('app_settings');
        return $query->row();
    }

    function getSliderImages() {
        $this->db->select('*');
        $this->db->from('slider_images');
        $this->db->order_by('SortOrder');
        $query = $this->db->get();
        return $query->result();
    }

    public function getStates($country_id = 0) {
        $this->db->select('*');
        $this->db->from('states');
        if ($country_id) {
            $this->db->where('CountryId', $country_id);
        }
        $this->db->order_by('StateName', 'asc');
        $location = $this->db->get();
        return $location->result();
    }

    public function getCities($state_id) {
        $this->db->select('*');
        $this->db->from('cities');
        $this->db->where('StateId', $state_id);
        $this->db->order_by('CityName', 'asc');
        $query = $this->db->get();
        return $query->result();
    }

    public function getStateById($state_id) {
        $this->db->select('*');
        $this->db->from('states');
        $this->db->where('StateId', $state_id);
        $location = $this->db->get();
        return $location->row();
    }

    public function getCityById($city_id) {
        $this->db->select('*');
        $this->db->from('cities');
        $this->db->where('CityId', $city_id);
        $query = $this->db->get();
        return $query->row();
    }

    public function getBlogCategoryTree($parent = 0) {
        $categories = array();
        $this->db->from('blog_categories');
        $this->db->where('ParentId', $parent);
        $this->db->where('IsActive', 1);
        $result = $this->db->get()->result();
        foreach ($result as $mainCategory) {
            $category = array();
            $category['category_id'] = $mainCategory->BlogCategoryId;
            $category['category_name'] = $mainCategory->BlogCategoryName;
            $category['description'] = $mainCategory->Description;
            $category['parent_id'] = $mainCategory->ParentId;
            $category['sub_category'] = $this->getBlogCategoryTree($category['category_id']);
            $categories[] = $category;
        }
        return $categories;
    }

    public function getFAQCategoryTree($parent = 0) {
        $categories = array();
        $this->db->from('faq_categories');
        $this->db->where('ParentId', $parent);
        $this->db->where('IsActive', 1);
        $result = $this->db->get()->result();
        foreach ($result as $mainCategory) {
            $category = array();
            $category['category_id'] = $mainCategory->FaqCategoryId;
            $category['category_name'] = $mainCategory->FaqCategoryName;
            $category['parent_id'] = $mainCategory->ParentId;
            $category['sub_category'] = $this->getFAQCategoryTree($category['category_id']);
            $categories[] = $category;
        }
        return $categories;
    }

    public function getFAQ($Category_id = 0) {
        $this->db->select('*');
        $this->db->from('faqs');
        if ($Category_id) {
            $this->db->where('FaqCategoryId', $Category_id);
        }
        $this->db->where('IsActive', 1);
        $query = $this->db->get();
        return $query->result();
    }

    public function getFAQSearch($search_text, $Category_id = 0) {
        $this->db->select('*');
        $this->db->from('faqs');
        if ($Category_id) {
            $this->db->where('FaqCategoryId', $Category_id);
        }
        $this->db->like('FaqQuestion', $search_text);
        $this->db->where('IsActive', 1);
        $query = $this->db->get();
        return $query->result();
    }

    public function getCouponCode() {
        $this->db->select('*');
        $this->db->from('coupons');
        $this->db->where('FromDate <=', date("Y-m-d"));
        $this->db->where('ToDate >=', date("Y-m-d"));
        $this->db->where('IsActive', 1);
        $query = $this->db->get();
        return $query->result();
    }

    public function applyCoupon($customer_id, $coupon) {
        $getcartDetail = $this->Product_model->getCartDetail($customer_id);
        $total = $getcartDetail['amount'];
        $coupon_detail = $this->Product_model->checkCouponCode($coupon);
        if ($coupon_detail) {
            if ($coupon_detail->ValidFor == 'all' or $this->Order_model->getCouponbyCId($coupon_detail->CouponId, $customer_id)) {
                if ($total >= $coupon_detail->MinOrderAmount) {
                    $check_allcustomer = $this->Order_model->getOrderbyCoupon($coupon_detail->CouponId);
                    if (count($check_allcustomer) < $coupon_detail->MaxCustomerCount) {
                        $check_customer = $this->Order_model->getOrderbyCoupon($coupon_detail->CouponId, $customer_id);
                        if (count($check_customer) < $coupon_detail->MaxCustomerIndiCount) {
                            if ($coupon_detail->DiscountType == 'flat') {
                                $coupon_amount = $coupon_detail->Discount;
                            } else {
                                $coupon_amount = $coupon_detail->Discount * $total / 100;
                            }
                            if ($coupon_amount > $coupon_detail->MaxAvailDiscount) {
                                $coupon_amount = $coupon_detail->MaxAvailDiscount;
                            }
                            if($coupon_detail->EvalType=="instant_discount"){
                              $total=  $total - $coupon_amount;
                            }                           
                            $discount = array('discount_amount' => $coupon_amount,
                                'coupon_id' => $coupon_detail->CouponId,
                                'coupon_code' => $coupon_detail->CouponCode,
                                'coupon_type' => $coupon_detail->EvalType,
                                'total' => $total
                            );
                            $response = array('status' => 1, 'data' => $discount, 'message' => 'Successfully Applied');
                        } else {
                            $response = array('status' => 0, 'message' => 'Sorry coupon ' . $coupon_detail->CouponCode . ' has exceeded the number of times it can be used per customer.');
                        }
                    } else {
                        $response = array('status' => 0, 'message' => 'Sorry coupon ' . $coupon_detail->CouponCode . ' has exceeded the number of times it can be used.');
                    }
                } else {
                    $response = array('status' => 0, 'message' => 'The minimum amount required to avail the offer is Rs.' . $coupon_detail->MinOrderAmount . '/- or more.');
                }
            } else {
                $response = array('status' => 0, 'message' => 'Invalid Coupon Code');
            }
        } else {
            $response = array('status' => 0, 'message' => 'Invalid Coupon Code');
        }
        return json_encode($response);
    }

    function getPaymentModes($id = 0) {
        $this->db->select('*');
        $this->db->from('payment_modes');
        $this->db->order_by('SortOrder');
        if ($id) {
            $this->db->like('PaymentTypeId', '"' . $id . '"');
        }
        $this->db->where('IsActive', 1);
        $query = $this->db->get();
        return $query->result();
    }

    function getPaymentTypes() {
        $this->db->select('*');
        $this->db->from('payment_types');
        $this->db->order_by('SortOrder');
        $this->db->where('IsActive', 1);
        $query = $this->db->get();
        return $query->result();
    }

    public function addSubscriber($emailarray) {
        $this->db->insert('subscribers', $emailarray);
        return $this->db->insert_id();
    }

    public function checkSubscribedEmail($email) {
        $this->db->select('*');
        $this->db->from('subscribers');
        $this->db->where('Email', $email);
        $result = $this->db->get();
        if ($result->num_rows() == 0) {
            return true;
        } else {
            return false;
        }
    }

}

?>
